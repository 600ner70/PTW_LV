# PTW_LV Checklist Refactor — Full Suite

Everything produced across this session, current as of the Page 1/5/10/16/17/50/51
sweep. This file is the index — start here.

## Contents

| File | What it is |
|---|---|
| `sql/05_new_tables_ddl.sql` | New tables: checklist metadata/responses, signatures, monitoring checks — sequences, FKs, indexes, VPD policies |
| `sql/06_seed_checklist_items.sql` | Seeds `PTW_TYPES` (`GENERAL`) + checklist questions for `LV ISOLATION` and `GENERAL` |
| `sql/07_migrate_existing_data.sql` | One-time backfill of existing permit data into the new tables (idempotent) |
| `sql/08_update_views.sql` | Updated `PTW_LV_ANALYTICS_V` and `PTW_LV_CANCELLATION_REASON_V` |
| `sql/09_update_generate_ptw_lv_pdf.sql` | Updated PDF function — same visual output, now type-agnostic and sourced from the new tables |
| `packages/ptw_checklist_pkg.pks/pkb.sql` | JSON load/save for the permit-type-driven checklist (the one piece that's genuinely dynamic) |
| `packages/ptw_signature_pkg.pks/pkb.sql` | Save/load for AUTH/ACCEPT/CLEAR/CANCEL signatures — plain `MERGE`, no JSON |
| `packages/ptw_monitoring_pkg.pks/pkb.sql` | Save for monitoring checks — plain `MERGE`, no JSON |
| `js/ptw-checklist.js` | Reusable checklist renderer — same badge markup/CSS as today, driven by loaded metadata instead of a hardcoded item array |
| `PAGE_PROCESS_UPDATES.md` | Every Page Designer process that needs updating (Pages 1, 2, 4, 5, 10, 16, 17, 50 — Page 51 needs nothing) |

## Run order

1. `05_new_tables_ddl.sql`
2. `06_seed_checklist_items.sql` (check the Step 0 lookup query first — already
   confirmed as `'LV ISOLATION'` from your `PTW_TYPES` data)
3. `07_migrate_existing_data.sql`
4. `08_update_views.sql`
5. Compile all three packages, spec before body — do this **before** step 6,
   since the PDF function and several page processes call them
6. `09_update_generate_ptw_lv_pdf.sql`
7. Apply the Page Designer changes in `PAGE_PROCESS_UPDATES.md`

## Builder steps for the new General/LV checklist UI (Page 3)

These can't be scripted — they're Page Designer changes:

1. **Upload `ptw-checklist.js`** to Shared Components → Static Application
   Files, and add `#APP_FILES#ptw-checklist#MIN#.js` to Page 0's File URLs,
   same as `ptw-utils.js` already is.

2. **On Page 3**, replace the 16 `P3_CM_*` items and 10 `P3_PPE_*` items with
   two empty **Static Content** regions with Static IDs, e.g.
   `cm-checklist-region` and `ppe-checklist-region`.

3. **One new Hidden item**: `P3_CHECKLIST_JSON` — carries the collected
   answers to the save process.

4. **Execute When Page Loads** (Page 3, Page Attributes):
   ```javascript
   PTW.checklist.load(
       $v('P3_PERMIT_ID'),
       { controlMeasures: 'cm-checklist-region', ppe: 'ppe-checklist-region' },
       apex.item('P3_WORKFLOW_STATUS').getValue() !== 'DRAFT'
   );
   ```

5. **AJAX Callback process** named `GET_CHECKLIST`:
   ```plsql
   BEGIN
       htp.prn('{"items":' || ptw_pro.ptw_checklist_pkg.get_checklist_json(apex_application.g_x01) || '}');
   END;
   ```

6. **Before the existing Save/Next Step DAs submit** (same pattern as the
   `captureLocationThenSubmit` geolocation DA already does), add:
   ```javascript
   apex.item('P3_CHECKLIST_JSON').setValue(JSON.stringify(PTW.checklist.collect()));
   ```

7. **Replace the old 16-column DML** in the Save process with:
   ```plsql
   ptw_pro.ptw_checklist_pkg.save_checklist_responses(:P3_PERMIT_ID, :P3_CHECKLIST_JSON);
   ```

Nothing here requires IG, Tabular Forms, or `APEX_ITEM` arrays — the
placeholder regions just host plain HTML the JS builds, same as the badge
rows already do today.

## Known open items

- **General permit's question set is a starting point, not confirmed** —
  the source PDF text was mostly the closure page. Check `06`'s `GENERAL`
  items against the real form.
- Pages 16's "prefill clear-mobile from accept-mobile" was already dead code
  before this refactor (documented in `PAGE_PROCESS_UPDATES.md`) — preserved
  as-is, not fixed, since that's a separate decision.
- `CHK_PERMIT_ON_DISPLAY` / `CHK_ACCESS_EGRESS` / `CHK_WARNING_SIGNS` on
  `PTW_LV_MONITORING` were deliberately left as fixed columns — generic,
  not permit-type-variable, not part of this refactor's scope.

