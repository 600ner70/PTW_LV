# Page Process Updates

Full sweep of every page referencing the migrated columns. 9 pages total:
3 small permission-check fixes, 4 real DML rewrites, 1 report-query fix,
and 1 that needs nothing (already fixed via the view).

Run `05`–`08` and compile all three packages before applying any of these
(Page 5 and 10 call `ptw_signature_pkg`/`ptw_monitoring_pkg` directly).

---

## Page 1 — Dashboard

Two regions share an identical visibility-filter block that checks
`UPPER(p.auth_person_name) = UPPER(V('APP_USER'))`. Both occurrences need
the same fix — find each and replace:

**Find:**
```sql
UPPER(p.auth_person_name) = UPPER(V('APP_USER'))
```

**Replace with:**
```sql
EXISTS (
    SELECT 1 FROM ptw_pro.ptw_signatures sig
    WHERE  sig.permit_id = p.permit_id
    AND    sig.stage     = 'AUTH'
    AND    UPPER(sig.person_name) = UPPER(V('APP_USER'))
)
```

---

## Page 2 — Site & Work Details

**Process** with the `v_is_auth` check. Find:
```sql
SELECT COUNT(*) INTO v_is_auth
FROM   ptw_pro.ptw_lv_permits
WHERE  permit_id = :P2_PERMIT_ID
AND    NVL(UPPER(auth_person_name),'XXX') = UPPER(V('APP_USER'));  -- check if the engineer is the auth_person
```

**Replace with:**
```sql
SELECT COUNT(*) INTO v_is_auth
FROM   ptw_pro.ptw_signatures
WHERE  permit_id = :P2_PERMIT_ID
AND    stage     = 'AUTH'
AND    UPPER(person_name) = UPPER(V('APP_USER'));  -- check if the engineer is the auth_person
```

---

## Page 4 — Equipment Isolation

Identical pattern to Page 2, just `:P4_PERMIT_ID`:
```sql
SELECT COUNT(*) INTO v_is_auth
FROM   ptw_pro.ptw_signatures
WHERE  permit_id = :P4_PERMIT_ID
AND    stage     = 'AUTH'
AND    UPPER(person_name) = UPPER(V('APP_USER'));  -- check if the engineer is the auth_person
```

---

## Page 5 — Authorisation & Acceptance

Two processes. Page items, buttons, and layout are all unchanged.

### Process: "Load Authorisation and Acceptance Data"

```plsql
BEGIN
    :P5_CURRENT_STEP := 'AUTHORISATION';

    BEGIN
        SELECT permit_number, workflow_status
        INTO   :P5_PERMIT_NUMBER, :P5_WORKFLOW_STATUS
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = :P5_PERMIT_ID;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            :P5_WORKFLOW_STATUS := 'DRAFT';
    END;

    DECLARE
        v_auth_sig   BLOB;
        v_accept_sig BLOB;
        v_na_company ptw_pro.ptw_signatures.company_name%TYPE;
        v_auth_lat   ptw_pro.ptw_signatures.latitude%TYPE;
        v_auth_lng   ptw_pro.ptw_signatures.longitude%TYPE;
    BEGIN
        ptw_pro.ptw_signature_pkg.get_signature(:P5_PERMIT_ID, 'AUTH',
            :P5_AUTH_PERSON_SELECT, v_auth_sig, :P5_AUTH_PERSON_MOBILE, v_na_company,
            :P5_AUTH_DATETIME, :P5_AUTH_LATITUDE, :P5_AUTH_LONGITUDE);

        ptw_pro.ptw_signature_pkg.get_signature(:P5_PERMIT_ID, 'ACCEPT',
            :P5_ACCEPT_PERSON_NAME, v_accept_sig, :P5_ACCEPT_PERSON_MOBILE, :P5_ACCEPT_COMPANY,
            :P5_ACCEPT_DATETIME, :P5_ACCEPT_LATITUDE, :P5_ACCEPT_LONGITUDE);

        IF :P5_ACCEPT_DATETIME IS NULL THEN
            :P5_ACCEPT_DATETIME := TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI');
        END IF;
        IF :P5_AUTH_DATETIME IS NULL THEN
            :P5_AUTH_DATETIME := TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI');
        END IF;

        IF :P5_ACCEPT_COMPANY IS NULL AND :P5_ACCEPT_PERSON_NAME IS NULL THEN
            BEGIN
                SELECT person_in_charge_name, supervising_company
                INTO   :P5_ACCEPT_PERSON_NAME, :P5_ACCEPT_COMPANY
                FROM   ptw_pro.ptw_lv_permits
                WHERE  permit_id = :P5_PERMIT_ID;
            EXCEPTION
                WHEN OTHERS THEN NULL;
            END;
        END IF;

        IF v_auth_sig IS NOT NULL THEN
            :P5_AUTH_SIGNATURE_DATA := 'data:image/png;base64,'
                || apex_web_service.blob2clobbase64(v_auth_sig);
        END IF;
        IF v_accept_sig IS NOT NULL THEN
            :P5_ACCEPT_SIGNATURE_DATA := 'data:image/png;base64,'
                || apex_web_service.blob2clobbase64(v_accept_sig);
        END IF;
    EXCEPTION
        WHEN OTHERS THEN NULL;
    END;
END;
```

Note: the original wrapped the whole thing in one `EXCEPTION WHEN NO_DATA_FOUND` that
also defaulted `:P5_WORKFLOW_STATUS := 'DRAFT'` on a brand-new permit. I split that into
its own small block around just the permit-header `SELECT` so a genuinely new permit still
defaults to DRAFT correctly, without swallowing errors from the signature lookups.

### Process: "Save Authorisation and Acceptance Data"

```plsql
DECLARE
    v_auth_sig_blob   BLOB;
    v_accept_sig_blob BLOB;

    FUNCTION base64_to_blob(p_base64 CLOB) RETURN BLOB IS
        v_blob BLOB;
        v_clob CLOB;
    BEGIN
        IF p_base64 IS NULL THEN
            RETURN NULL;
        END IF;
        v_clob := REGEXP_REPLACE(p_base64, '^data:image/[^;]+;base64,', '');
        v_blob := apex_web_service.clobbase642blob(v_clob);
        RETURN v_blob;
    END base64_to_blob;

BEGIN
    v_auth_sig_blob   := base64_to_blob(:P5_AUTH_SIGNATURE_DATA);
    v_accept_sig_blob := base64_to_blob(:P5_ACCEPT_SIGNATURE_DATA);

    ptw_pro.ptw_signature_pkg.save_signature(
        p_permit_id      => :P5_PERMIT_ID,
        p_stage          => 'AUTH',
        p_person_name    => UPPER(:P5_AUTH_PERSON_SELECT),
        --   was: (SELECT first_name || ' ' || last_name FROM ptw_pro.ptw_lv_users
        --         WHERE UPPER(username) = UPPER(:P5_AUTH_PERSON_SELECT)) — left as
        --   username per the original's own commented-out alternative
        p_signature_blob => v_auth_sig_blob,
        p_mobile_no      => (SELECT mobile_no FROM ptw_pro.ptw_lv_users
                              WHERE UPPER(username) = UPPER(:P5_AUTH_PERSON_SELECT)),
        p_event_datetime => TO_DATE(:P5_AUTH_DATETIME, 'DD-MON-YYYY HH24:MI'),
        p_latitude       => :APP_LATITUDE,
        p_longitude      => :APP_LONGITUDE
    );

    ptw_pro.ptw_signature_pkg.save_signature(
        p_permit_id      => :P5_PERMIT_ID,
        p_stage          => 'ACCEPT',
        p_person_name    => :P5_ACCEPT_PERSON_NAME,
        p_signature_blob => v_accept_sig_blob,
        p_mobile_no      => :P5_ACCEPT_PERSON_MOBILE,
        p_company_name   => :P5_ACCEPT_COMPANY,
        p_event_datetime => TO_DATE(:P5_ACCEPT_DATETIME, 'DD-MON-YYYY HH24:MI'),
        p_latitude       => :APP_LATITUDE,
        p_longitude      => :APP_LONGITUDE
    );

    UPDATE ptw_pro.ptw_lv_permits
    SET    workflow_status = 'AUTHORISED',
           current_step    = 'AUTHORISATION',
           modified_by     = NVL(V('APP_USER'), USER),
           modified_date   = CURRENT_TIMESTAMP
    WHERE  permit_id = :P5_PERMIT_ID;

    COMMIT;

    apex_application.g_print_success_message :=
        CASE WHEN :REQUEST = 'AUTHORISE'
             THEN 'Permit ' || :P5_PERMIT_NUMBER || ' has been authorised.'
             ELSE 'Permit ' || :P5_PERMIT_NUMBER || ' saved successfully.'
        END;

    :P5_WORKFLOW_STATUS := 'AUTHORISED';

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        apex_error.add_error(
            p_message => 'Error saving authorisation data: ' || SQLERRM,
            p_display_location => apex_error.c_inline_in_notification
        );
END;
```

---

## Page 10 — Low Voltage Monitoring

Note preserved from the original: **Check 1 always gets a row (even blank),
Checks 2 and 3 only get a row if their detail was actually filled in** —
this matches the PDF's "Check 1 always shown, 2/3 only if present" behaviour
exactly, so nothing changes visually.

### Process: "Load Monitoring Data"

Replace the 16 `:P10_MS_CHECKn_*` assignment lines with:

```plsql
FOR chk IN (
    SELECT check_seq, detail, check_time, in_order, comments
    FROM   ptw_pro.ptw_monitoring_checks
    WHERE  monitoring_id = :P10_MONITORING_ID
    ORDER  BY check_seq
) LOOP
    CASE chk.check_seq
        WHEN 1 THEN
            :P10_MS_CHECK1_DETAIL   := chk.detail;
            :P10_MS_CHECK1_TIME     := chk.check_time;
            :P10_MS_CHECK1_IN_ORDER := chk.in_order;
            :P10_MS_CHECK1_COMMENTS := chk.comments;
        WHEN 2 THEN
            :P10_MS_CHECK2_DETAIL   := chk.detail;
            :P10_MS_CHECK2_TIME     := chk.check_time;
            :P10_MS_CHECK2_IN_ORDER := chk.in_order;
            :P10_MS_CHECK2_COMMENTS := chk.comments;
        WHEN 3 THEN
            :P10_MS_CHECK3_DETAIL   := chk.detail;
            :P10_MS_CHECK3_TIME     := chk.check_time;
            :P10_MS_CHECK3_IN_ORDER := chk.in_order;
            :P10_MS_CHECK3_COMMENTS := chk.comments;
    END CASE;
END LOOP;
```

Everything else in this process (`CHK_PERMIT_ON_DISPLAY` etc., `MONITOR_NAME`,
signature) is unchanged.

### Process: "Save Monitoring Data"

In both the `UPDATE` and `INSERT` branches, **remove** all 12
`ms_check1/2/3_*` columns (both from the `SET`/column list and the
corresponding bind variables). Everything else in that UPDATE/INSERT stays.

Then, immediately **after** the `IF :P10_MONITORING_ID IS NOT NULL THEN ...
END IF;` block (so `:P10_MONITORING_ID` is guaranteed populated either way,
via the existing `RETURNING ... INTO` on insert), add:

```plsql
-- Check 1 always saved, even if blank (matches original "always shown")
ptw_pro.ptw_monitoring_pkg.save_check(
    p_monitoring_id => :P10_MONITORING_ID,
    p_check_seq     => 1,
    p_detail        => :P10_MS_CHECK1_DETAIL,
    p_check_time    => :P10_MS_CHECK1_TIME,
    p_in_order      => :P10_MS_CHECK1_IN_ORDER,
    p_comments      => :P10_MS_CHECK1_COMMENTS
);

IF :P10_MS_CHECK2_DETAIL IS NOT NULL THEN
    ptw_pro.ptw_monitoring_pkg.save_check(
        p_monitoring_id => :P10_MONITORING_ID,
        p_check_seq     => 2,
        p_detail        => :P10_MS_CHECK2_DETAIL,
        p_check_time    => :P10_MS_CHECK2_TIME,
        p_in_order      => :P10_MS_CHECK2_IN_ORDER,
        p_comments      => :P10_MS_CHECK2_COMMENTS
    );
END IF;

IF :P10_MS_CHECK3_DETAIL IS NOT NULL THEN
    ptw_pro.ptw_monitoring_pkg.save_check(
        p_monitoring_id => :P10_MONITORING_ID,
        p_check_seq     => 3,
        p_detail        => :P10_MS_CHECK3_DETAIL,
        p_check_time    => :P10_MS_CHECK3_TIME,
        p_in_order      => :P10_MS_CHECK3_IN_ORDER,
        p_comments      => :P10_MS_CHECK3_COMMENTS
    );
END IF;
```

---

## Page 16 — Clear Permit

Worth knowing before you touch this one: the current Load process selects
`accept_person_mobile` into `:P16_CLEAR_PERSON_MOBILE`, then immediately
selects `clear_person_mobile` into the *same* bind variable — the second
assignment always wins, so the "prefill from accept" was already dead code
today, not something this migration changes. The rewrite below reproduces
the actual current behaviour (mobile comes from the CLEAR stage only). If
you want the prefill to genuinely work, that's a separate, deliberate fix.

### Process: "Load Permit Data"

```plsql
DECLARE
    v_status   VARCHAR2(20);
    v_ended    DATE;
    v_sig      BLOB;
    v_na_lat   ptw_pro.ptw_signatures.latitude%TYPE;
    v_na_lng   ptw_pro.ptw_signatures.longitude%TYPE;
BEGIN
    SELECT workflow_status, ended_datetime, permit_number,
           person_in_charge_name, supervising_company
    INTO   v_status, v_ended, :P16_PERMIT_NUMBER,
           :P16_CLEAR_PERSON_NAME, :P16_CLEAR_COMPANY
    FROM   ptw_pro.ptw_lv_permits
    WHERE  permit_id = :P16_PERMIT_ID;

    IF v_status NOT IN ('STARTED', 'COMPLETED') THEN
        apex_error.add_error(
            p_message          => 'This permit cannot be viewed here. Current status: ' || v_status,
            p_display_location => apex_error.c_on_error_page
        );
        RETURN;
    END IF;

    IF v_status = 'STARTED' THEN
        IF SYSDATE >= v_ended THEN
            apex_error.add_error(
                p_message          => 'This permit has expired ('
                                      || TO_CHAR(v_ended, 'DD-MON-YYYY HH24:MI')
                                      || ') and cannot be cleared.',
                p_display_location => apex_error.c_on_error_page
            );
            RETURN;
        END IF;
        :P16_CLEAR_DATETIME := TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI');
    END IF;

    IF v_status = 'COMPLETED' THEN
        ptw_pro.ptw_signature_pkg.get_signature(:P16_PERMIT_ID, 'CLEAR',
            :P16_CLEAR_PERSON_NAME, v_sig, :P16_CLEAR_PERSON_MOBILE, :P16_CLEAR_COMPANY,
            :P16_CLEAR_DATETIME, v_na_lat, v_na_lng);

        SELECT clear_work_complete, clear_area_safe
        INTO   :P16_CLEAR_WORK_COMPLETE, :P16_CLEAR_AREA_SAFE
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = :P16_PERMIT_ID;

        IF v_sig IS NOT NULL AND DBMS_LOB.GETLENGTH(v_sig) > 0 THEN
            :P16_CLEAR_SIGNATURE_DATA_URL := 'data:image/png;base64,'
                || apex_web_service.blob2clobbase64(v_sig);
        ELSE
            :P16_CLEAR_SIGNATURE_DATA_URL := NULL;
        END IF;
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        apex_error.add_error(
            p_message => 'Permit not found.', p_display_location => apex_error.c_on_error_page
        );
    WHEN OTHERS THEN
        apex_error.add_error(
            p_message => 'Error loading permit data: ' || SQLERRM,
            p_display_location => apex_error.c_on_error_page
        );
END;
```

### Process: "Clear Permit"

```plsql
DECLARE
    v_sig_blob  BLOB;
    v_clob      CLOB;
    v_now       DATE := SYSDATE;
BEGIN
    IF :P16_CLEAR_SIGNATURE_DATA IS NOT NULL THEN
        v_clob     := REPLACE(:P16_CLEAR_SIGNATURE_DATA, 'data:image/png;base64,', '');
        v_sig_blob := apex_web_service.clobbase642blob(v_clob);
    END IF;

    -- Guarded status transition stays on PTW_LV_PERMITS, same race-condition
    -- protection as before (workflow_status/expiry check + ROWCOUNT).
    UPDATE ptw_pro.ptw_lv_permits
    SET    clear_work_complete = :P16_CLEAR_WORK_COMPLETE,
           clear_area_safe     = :P16_CLEAR_AREA_SAFE,
           workflow_status     = 'COMPLETED',
           current_step        = 'CLEARANCE',
           completion_date     = v_now,
           modified_by         = V('APP_USER'),
           modified_date       = v_now
    WHERE  permit_id           = :P16_PERMIT_ID
    AND    workflow_status     = 'STARTED'
    AND    SYSDATE             < ended_datetime;

    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20001,
            'Permit could not be cleared. It may have expired or '
            || 'already been closed. Please refresh the permits list.');
    END IF;

    ptw_pro.ptw_signature_pkg.save_signature(
        p_permit_id      => :P16_PERMIT_ID,
        p_stage          => 'CLEAR',
        p_person_name    => UPPER(TRIM(:P16_CLEAR_PERSON_NAME)),
        p_signature_blob => v_sig_blob,
        p_mobile_no      => TRIM(:P16_CLEAR_PERSON_MOBILE),
        p_company_name   => UPPER(TRIM(:P16_CLEAR_COMPANY)),
        p_event_datetime => v_now,
        p_latitude       => TO_NUMBER(:APP_LATITUDE),
        p_longitude      => TO_NUMBER(:APP_LONGITUDE)
    );

    COMMIT;
    :P16_CLEARED := 'Y';
    apex_application.g_print_success_message :=
        'Permit ' || :P16_PERMIT_NUMBER || ' cleared successfully.';

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        apex_error.add_error(
            p_message          => 'Error clearing permit: ' || SQLERRM,
            p_display_location => apex_error.c_inline_in_notification
        );
END;
```

---

## Page 17 — Cancel Permit

### Process: "Load Cancel Permit Data"

```plsql
DECLARE
    v_clob CLOB;
    v_sig  BLOB;
    v_na_mobile  ptw_pro.ptw_signatures.mobile_no%TYPE;
    v_na_company ptw_pro.ptw_signatures.company_name%TYPE;
    v_na_lat     ptw_pro.ptw_signatures.latitude%TYPE;
    v_na_lng     ptw_pro.ptw_signatures.longitude%TYPE;
BEGIN
    SELECT permit_number, workflow_status
    INTO   :P17_PERMIT_NUMBER, :P17_WORKFLOW_STATUS
    FROM   ptw_pro.ptw_lv_permits
    WHERE  permit_id = :P17_PERMIT_ID;

    IF :P17_WORKFLOW_STATUS = 'CANCELLED' THEN

        ptw_pro.ptw_signature_pkg.get_signature(:P17_PERMIT_ID, 'CANCEL',
            :P17_CANCEL_PERSON_NAME, v_sig, v_na_mobile, v_na_company,
            :P17_CANCEL_DATETIME, v_na_lat, v_na_lng);

        SELECT cancel_work_complete
        INTO   :P17_CANCEL_WORK_COMPLETE
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = :P17_PERMIT_ID;

        IF v_sig IS NOT NULL AND DBMS_LOB.GETLENGTH(v_sig) > 0 THEN
            v_clob := apex_web_service.blob2clobbase64(v_sig);
            v_clob := REPLACE(REPLACE(v_clob, CHR(13), ''), CHR(10), '');
            :P17_CANCEL_SIGNATURE_DATA_URL :=
                'data:image/png;base64,' || DBMS_LOB.SUBSTR(v_clob, 32000, 1);
        ELSE
            :P17_CANCEL_SIGNATURE_DATA_URL := NULL;
        END IF;

    ELSE
        :P17_CANCEL_DATETIME := TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI');
        :P17_CANCEL_SIGNATURE_DATA_URL := NULL;
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        apex_error.add_error(
            p_message => 'Permit not found.', p_display_location => apex_error.c_on_error_page
        );
    WHEN OTHERS THEN
        apex_error.add_error(
            p_message => 'Error loading cancellation data: ' || SQLERRM,
            p_display_location => apex_error.c_on_error_page
        );
END;
```

### Process: "Cancel Permit"

```plsql
DECLARE
    v_sig_blob BLOB;

    FUNCTION base64_to_blob(p_base64 CLOB) RETURN BLOB IS
        v_blob BLOB;
        v_clob CLOB;
    BEGIN
        IF p_base64 IS NULL THEN RETURN NULL; END IF;
        v_clob := REGEXP_REPLACE(p_base64, '^data:image/[^;]+;base64,', '');
        v_blob := apex_web_service.clobbase642blob(v_clob);
        RETURN v_blob;
    END base64_to_blob;

BEGIN
    v_sig_blob := base64_to_blob(:P17_CANCEL_SIGNATURE_DATA);

    -- Guarded status transition, same protection as before.
    UPDATE ptw_pro.ptw_lv_permits
    SET    cancel_work_complete = :P17_CANCEL_WORK_COMPLETE,
           workflow_status      = 'CANCELLED',
           current_step         = 'CANCELLED',
           completion_date      = SYSDATE,
           modified_by          = NVL(V('APP_USER'), USER),
           modified_date        = CURRENT_TIMESTAMP
    WHERE  permit_id            = :P17_PERMIT_ID
    AND    workflow_status NOT IN ('CANCELLED','COMPLETED','CLEARED');

    IF SQL%ROWCOUNT = 0 THEN
        apex_error.add_error(
            p_message          => 'Permit could not be cancelled. It may have already '
                               || 'been cancelled or completed. Please refresh the '
                               || 'permits list.',
            p_display_location => apex_error.c_inline_in_notification
        );
        RETURN;
    END IF;

    ptw_pro.ptw_signature_pkg.save_signature(
        p_permit_id      => :P17_PERMIT_ID,
        p_stage          => 'CANCEL',
        p_person_name    => UPPER(TRIM(:P17_CANCEL_PERSON_NAME)),
        p_signature_blob => v_sig_blob,
        p_event_datetime => SYSDATE,
        p_latitude       => :APP_LATITUDE,
        p_longitude      => :APP_LONGITUDE
    );

    :P17_CANCELLED := 'Y';
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        apex_error.add_error(
            p_message          => 'Error cancelling permit: ' || SQLERRM,
            p_display_location => apex_error.c_inline_in_notification
        );
        RAISE;
END;
```

---

## Page 50 — Permit Search

Query selects `p.auth_person_name` from `ptw_pro.ptw_lv_permits p` directly.

**Find:**
```sql
p.auth_person_name,
```

**Replace with:**
```sql
(SELECT sig.person_name FROM ptw_pro.ptw_signatures sig
 WHERE  sig.permit_id = p.permit_id AND sig.stage = 'AUTH') AS auth_person_name,
```

---

## Page 51 — Permit Analytics

**Nothing to change.** Confirmed its query already runs against
`ptw_pro.ptw_lv_analytics_v` (aliased `p`), not `PTW_LV_PERMITS` directly —
`auth_datetime`, `clear_datetime`, `cancel_datetime`, `has_clearance`,
`has_cancellation` all come from the view, which `08_update_views.sql`
already fixed. This page inherits the fix automatically.
