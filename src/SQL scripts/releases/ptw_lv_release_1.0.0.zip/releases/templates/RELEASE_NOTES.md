# PTW LV-Electrical — Release Notes

## Release {{VERSION}} — baseline (first production release)

| | |
| --- | --- |
| Release type | Full install (baseline). Builds a new environment from nothing |
| Built | {{BUILT}} |
| Source | GitHub `600ner70/PTW_LV`, commit `7242528` ("latest atw and dra changes", 22 Nov 2026) |
| APEX application | 105 "PTW_PRO", exported from DEV 10 Oct 2026 on APEX 26.1.5 |
| Requires | Oracle APEX 26.1.5 or later on Autonomous Database, in a schema called `PTW_PRO` |
| Install guide | `README.md` |
| Contents and checksums | `MANIFEST.txt` |

### Summary

This is the first production release of the PTW LV-Electrical app. It turns the paper Permit to Work into an APEX app that works on mobile. The app takes a permit from issue to clearance, covers monitoring and dynamic risk assessments, and keeps each company's data separate.

### What's included

**Permit to Work**
- Permit workflow: start permit, site and work details, control measures and PPE, equipment isolation, authorisation and acceptance, then clear or cancel.
- Permit types: LV Isolation, General, Hot Work (with fire watch), Fire Systems Isolation and Working at Height. Each type has its own checklist and sections.
- Pages become read-only once a permit leaves the In Progress status.
- Captured signatures, with a location recorded at each stage, and a full change history.
- Linked permits, photo attachments and photo download.
- Permit numbering per company, using that company's prefix.

**Monitoring**
- LV monitoring checks, logging of monitoring concerns, and fire watch.

**Dynamic Risk Assessment (DRA)**
- DRA dashboard, site assessment details, hazards and controls, sign-off and a DRA report.

**Authority to Work (ATW)** *(database layer)*
- The `PTW_LV_ATW` and `PTW_LV_ATW_EVENTS` tables, the `PTW_ATW_PKG` package and the `PTW_LV_ATW_V` view.
- Lifecycle: Draft or Requested, then Issued, On Site and Checked Out, ending as Revoked, Expired or Cancelled.
- ATW numbering per company, plus auditing of every change.

**Reports and PDFs**
- PDF permits for LV, General, Hot Work, Fire Isolation, Working at Height and LOA, plus the DRA PDF.
- Permit search and permit analytics.

**Administration and security**
- Multi-company: Oracle VPD policies on 20 tables keep each company's data separate. Super users can view as a chosen company.
- Admin pages for companies, permit types, teams, sites and users.
- Roles through `PTW_LV_ROLES`, with APEX access control on top (Administrator, Contributor, Reader).

**Automations and mobile**
- Push notifications for permit expiry warnings and fire watch milestones, and a daily workflow-status clean-up.
- Progressive Web App with offline support and geolocation capture.

### Database objects

| Type | Count |
| --- | --- |
| Tables | 31 |
| Foreign keys | 45 |
| Indexes (non-constraint) | 37 |
| Sequences | 14 |
| Views | 6 |
| Functions | 10 |
| Packages | 12 |
| Triggers | 25 |
| VPD policies | 20 |

### Removed or not carried over

- `PTW_LV_USER_ROLES_OLD` and its index: legacy, replaced by `PTW_LV_ROLES` and `PTW_LV_USER_ROLE_ASSIGNMENTS`.
- `DEBUG_MESSAGES`: development only.
- DEV test companies, test users and test permits.

### Known issues and actions before go-live

1. **The ATW pages are not in this release.** The APEX export is dated 10 Oct 2026 and doesn't contain the ATW pages, so ATW is installed in the database only. Re-export app 105 from DEV and rebuild if the ATW pages should go live.
2. **ATW expiry needs a schedule.** `PTW_ATW_PKG.expire_atws` moves yesterday's ATWs to Expired. None of the three automations in the export calls it. Add an APEX automation or scheduler job before ATW goes live.
3. **ATW roles.** The package expects the roles `ATW_ISSUER` and `SECURITY` (as well as `ADMIN` and `AUTHORISER`) in `PTW_LV_ROLES`. Check that they exist in DEV before generating `12_reference_data.sql`.
4. **Reference data has to be generated from DEV.** `12_reference_data.sql` is a placeholder that stops the install until you replace it. See `README.md`.
5. **Check DEV for drift.** Run `tools/check_dev_drift.sql` in DEV just before release, to confirm the repo DDL matches DEV.
6. **Not yet test-installed.** The scripts were checked by reading them (object references, install order, terminators). The first install into the new environment is the rehearsal.
7. **Security housekeeping.** The repo is public and contains the session-state checksum salt. After import, regenerate the salt with Session State Protection → Expire Bookmarks.

### Post-install configuration

Set `APP_ENV` to `PROD`, regenerate the push notification credentials, and check the automations are active. Then create APEX accounts and access-control roles, turn debugging off, and set Build Status to Run Application Only. Full steps are in `README.md`.
