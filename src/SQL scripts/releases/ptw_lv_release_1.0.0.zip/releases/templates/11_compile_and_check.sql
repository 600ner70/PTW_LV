--------------------------------------------------------------------------------
-- PTW LV release {{VERSION}} : Recompile and check for invalid objects
-- Run as      : PTW_PRO
-- Generated   : {{BUILT}}
-- Raises an error (and stops the install) if anything is still INVALID.
--------------------------------------------------------------------------------

BEGIN
    DBMS_UTILITY.COMPILE_SCHEMA(schema => USER, compile_all => FALSE);
END;
/

SELECT object_type, object_name
FROM   user_objects
WHERE  status = 'INVALID'
ORDER  BY object_type, object_name;

DECLARE
    l_invalid VARCHAR2(4000);
BEGIN
    SELECT LISTAGG(object_type || ' ' || object_name, ', ') WITHIN GROUP (ORDER BY object_name)
    INTO   l_invalid
    FROM   user_objects
    WHERE  status = 'INVALID';

    IF l_invalid IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20002, 'Invalid objects after install: ' || SUBSTR(l_invalid, 1, 3900)
            || ' -- see USER_ERRORS for details.');
    END IF;
END;
/
