--------------------------------------------------------------------------------
-- PTW LV release {{VERSION}} : Smoke test of the database install
-- Run as      : PTW_PRO
-- Generated   : {{BUILT}}
-- Raises an error listing every failed check; prints PASS otherwise.
--------------------------------------------------------------------------------

DECLARE
    l_fail VARCHAR2(4000);
    l_n    NUMBER;

    PROCEDURE chk(p_ok BOOLEAN, p_msg VARCHAR2) IS
    BEGIN
        IF NOT p_ok THEN l_fail := l_fail || CHR(10) || ' - ' || p_msg; END IF;
    END;
BEGIN
    SELECT COUNT(*) INTO l_n FROM user_tables WHERE table_name NOT LIKE 'DR$%';
    chk(l_n >= {{N_TABLES}}, 'expected at least {{N_TABLES}} tables, found ' || l_n);

    SELECT COUNT(*) INTO l_n FROM user_objects WHERE status = 'INVALID';
    chk(l_n = 0, l_n || ' invalid objects');

    SELECT COUNT(*) INTO l_n FROM user_policies WHERE enable = 'YES';
    chk(l_n = {{N_POLICIES}}, 'expected {{N_POLICIES}} enabled VPD policies, found ' || l_n);

    SELECT COUNT(*) INTO l_n FROM user_triggers WHERE status <> 'ENABLED';
    chk(l_n = 0, l_n || ' disabled triggers');

    SELECT COUNT(*) INTO l_n FROM ptw_types WHERE available = 'Y';
    chk(l_n > 0, 'no available permit types (reference data missing)');

    SELECT COUNT(*) INTO l_n FROM ptw_checklist_items;
    chk(l_n > 0, 'no checklist items (reference data missing)');

    SELECT COUNT(*) INTO l_n FROM ptw_dra_items;
    chk(l_n > 0, 'no DRA items (reference data missing)');

    SELECT COUNT(*) INTO l_n FROM ptw_lv_roles;
    chk(l_n > 0, 'no roles (reference data missing)');

    SELECT COUNT(*) INTO l_n FROM ptw_lv_users WHERE is_super_user = 'Y' AND username <> 'SYSTEM_AUTOMATION';
    chk(l_n > 0, 'no super user (run 13_bootstrap_users.sql)');

    SELECT COUNT(*) INTO l_n FROM ptw_lv_users WHERE username = 'SYSTEM_AUTOMATION';
    chk(l_n = 1, 'SYSTEM_AUTOMATION user missing');

    SELECT COUNT(*) INTO l_n FROM ptw_lv_companies;
    chk(l_n > 0, 'no company (run 13_bootstrap_users.sql)');

    IF l_fail IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20005, 'Smoke test FAILED:' || SUBSTR(l_fail, 1, 3900));
    END IF;
    DBMS_OUTPUT.PUT_LINE('Smoke test PASS - release {{VERSION}} database objects look correct.');
END;
/
