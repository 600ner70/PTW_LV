--------------------------------------------------------------------------------
-- PTW LV release {{VERSION}} : Has DEV changed since this release was built?
-- Run in      : DEV, SQL Workshop -> SQL Commands, as PTW_PRO
-- Read-only.  Every row returned is a difference to look at.
--   MISSING_IN_RELEASE : exists in DEV but not in the release -> add it
--   MISSING_IN_DEV     : in the release but not in DEV        -> dropped in DEV?
--   COLUMN_COUNT       : table has a different number of columns -> DDL changed
-- Excluded on purpose: PTW_LV_USER_ROLES_OLD, DEBUG_MESSAGES (see MANIFEST.txt).
--------------------------------------------------------------------------------
WITH expected AS (
{{EXPECTED_OBJECTS}}
),
actual AS (
    SELECT o.object_type t, o.object_name n,
           (SELECT COUNT(*) FROM user_tab_columns c
            WHERE c.table_name = o.object_name AND o.object_type = 'TABLE') c
    FROM   user_objects o
    WHERE  o.object_type IN ('TABLE','SEQUENCE','INDEX','VIEW','FUNCTION','PACKAGE','TRIGGER','PROCEDURE')
    AND    o.object_name NOT LIKE 'SYS\_%' ESCAPE '\'
    AND    o.object_name NOT LIKE 'ISEQ$$%'
    AND    o.object_name NOT LIKE 'BIN$%'
    AND    o.object_name NOT LIKE 'DR$%'
    AND    o.object_name NOT IN ('PTW_LV_USER_ROLES_OLD','DEBUG_MESSAGES','IDX_PTW_LV_UR_USERNAME')
    -- indexes that back PK/UK constraints are created by the constraint
    AND    NOT (o.object_type = 'INDEX' AND EXISTS (
               SELECT 1 FROM user_constraints k WHERE k.index_name = o.object_name))
)
SELECT 'MISSING_IN_RELEASE' issue, a.t object_type, a.n object_name, NULL release_cols, a.c dev_cols
FROM   actual a WHERE NOT EXISTS (SELECT 1 FROM expected e WHERE e.t = a.t AND e.n = a.n)
UNION ALL
SELECT 'MISSING_IN_DEV', e.t, e.n, e.c, NULL
FROM   expected e WHERE NOT EXISTS (SELECT 1 FROM actual a WHERE a.t = e.t AND a.n = e.n)
UNION ALL
SELECT 'COLUMN_COUNT', e.t, e.n, e.c, a.c
FROM   expected e JOIN actual a ON a.t = e.t AND a.n = e.n
WHERE  e.t = 'TABLE' AND e.c <> a.c
ORDER  BY 1, 2, 3;

-- Also worth a look: objects changed most recently in DEV.
-- Anything changed after the repo's DDL export may not be in the release.
SELECT object_type, object_name, TO_CHAR(last_ddl_time, 'YYYY-MM-DD HH24:MI') last_ddl_time
FROM   user_objects
WHERE  object_type IN ('TABLE','VIEW','FUNCTION','PACKAGE','PACKAGE BODY','TRIGGER','PROCEDURE')
ORDER  BY last_ddl_time DESC
FETCH FIRST 25 ROWS ONLY;
