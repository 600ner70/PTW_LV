--------------------------------------------------------------------------------
-- PTW LV release {{VERSION}} : One-shot installer for SQLcl / SQL*Plus
-- Only usable where SQL*Net is allowed (Transaction Processing workload,
-- or any non-APEX-Service database). On APEX Service run the numbered files
-- one by one in SQL Workshop -> SQL Scripts instead (see README.md).
--
-- Prerequisite: 01_admin_grants.sql already run as ADMIN.
-- Usage:        sql PTW_PRO@<tns_alias>
--               SQL> @install_sqlcl.sql
--------------------------------------------------------------------------------
whenever sqlerror exit failure rollback
set define off serveroutput on size unlimited
spool install_{{VERSION}}.log

prompt == 02 sequences
@@02_sequences.sql
prompt == 03 tables
@@03_tables.sql
prompt == 04 foreign keys
@@04_foreign_keys.sql
prompt == 05 indexes
@@05_indexes.sql
prompt == 06 package specs
@@06_package_specs.sql
prompt == 07 views
@@07_views.sql
prompt == 08 functions
@@08_functions.sql
prompt == 09 package bodies
@@09_package_bodies.sql
prompt == 10 triggers
@@10_triggers.sql
prompt == 11 compile and check
@@11_compile_and_check.sql
prompt == 12 reference data
@@12_reference_data.sql
prompt == 13 bootstrap users
@@13_bootstrap_users.sql
prompt == 14 VPD policies
@@14_vpd_policies.sql
prompt == 15 smoke test
@@15_smoke_test.sql

prompt == APEX application 105
set define on
accept ws prompt 'APEX workspace name in this database: '
begin
    apex_application_install.set_workspace(upper('&ws'));
    apex_application_install.set_application_id(105);
    apex_application_install.set_schema('PTW_PRO');
end;
/
set define off
@@apex/f105.sql

spool off
prompt Release {{VERSION}} installed. Now do the post-install steps in README.md.
