# PTW LV — Release {{VERSION}} (full install)

Built {{BUILT}} by `releases/build_release.py`. This is a full install. It builds the PTW LV-Electrical app and its `PTW_PRO` schema from nothing, in an empty Autonomous Database.

| | |
| --- | --- |
| APEX application | 105, exported from DEV on APEX **26.1.5** on 10 Oct 2026 (`apex/f105.sql`) |
| Target APEX version | **26.1.5 or later**. You can't import the export into an older APEX |
| Parsing / data schema | `PTW_PRO` (the name must be exactly this) |
| Checksums and contents | `MANIFEST.txt` |

## Before you can use this release

The build used what is in the repo. Two things live only in DEV, so finish these steps first:

1. **Reference data.** `12_reference_data.sql` is a placeholder and stops the install on purpose. In DEV, run `tools/export_reference_data_from_dev.sql` in SQL Workshop → SQL Commands as PTW_PRO. Then paste the DBMS Output over the placeholder and commit.
2. **Check that DEV hasn't changed.** In DEV, run `tools/check_dev_drift.sql`. It should return no rows in the first result. If it does return rows, export those objects from DEV into `src/SQL scripts/<type>/` and rebuild with `python3 releases/build_release.py {{VERSION}}`.
3. Edit the four constants at the top of `13_bootstrap_users.sql`: first company, its code, its permit prefix, and the first super user.

## Install order

Stop at the first error. "SQL Scripts" means SQL Workshop → SQL Scripts → Upload, then Run. After each run, check the results page shows **0 errors**.

| Step | File | Run as | Where |
| --- | --- | --- | --- |
| 0 | Create workspace + new schema `PTW_PRO` | ADMIN | APEX Administration Services → Manage Workspaces |
| 1 | `01_admin_grants.sql` | ADMIN | Database Actions → SQL (Run Script) |
| 2 | `02_sequences.sql` | PTW_PRO | SQL Scripts |
| 3 | `03_tables.sql` | PTW_PRO | SQL Scripts |
| 4 | `04_foreign_keys.sql` | PTW_PRO | SQL Scripts |
| 5 | `05_indexes.sql` | PTW_PRO | SQL Scripts |
| 6 | `06_package_specs.sql` | PTW_PRO | SQL Scripts |
| 7 | `07_views.sql` | PTW_PRO | SQL Scripts |
| 8 | `08_functions.sql` | PTW_PRO | SQL Scripts |
| 9 | `09_package_bodies.sql` | PTW_PRO | SQL Scripts |
| 10 | `10_triggers.sql` | PTW_PRO | SQL Scripts |
| 11 | `11_compile_and_check.sql` | PTW_PRO | SQL Scripts. Must report no invalid objects |
| 12 | `12_reference_data.sql` | PTW_PRO | SQL Scripts |
| 13 | `13_bootstrap_users.sql` | PTW_PRO | SQL Scripts |
| 14 | `14_vpd_policies.sql` | PTW_PRO | SQL Scripts. Always after 12 and 13 |
| 15 | `15_smoke_test.sql` | PTW_PRO | SQL Scripts. Must print PASS |
| 16 | `apex/f105.sql` | developer | App Builder → Import. Parsing schema PTW_PRO, reuse ID 105, supporting objects No |

If the database allows SQL*Net (the Transaction Processing workload), steps 2–16 can run in one go: `sql PTW_PRO@<alias>` then `@install_sqlcl.sql`.

**If an install fails partway**, the easiest fix is to start again. Drop the workspace and its schema in Administration Services, then begin from step 0. Steps 12–14 aren't designed to run twice.

## After the import

1. Shared Components → Application Definition → Substitutions: set `APP_ENV` to `PROD`. The export carries `DEV`.
2. Shared Components → Progressive Web App → Push Notifications: regenerate the credentials.
3. Shared Components → Automations: check all three are active, and run each once.
4. Create the super user's APEX account. The username must match `13_bootstrap_users.sql`. Grant it the **Administrator** role in Shared Components → Application Access Control. The app is ACL-only.
5. Session State Protection → Expire Bookmarks. This regenerates the checksum salt, which is published in the repo.
6. Application Definition → Properties → Debugging: No. Once everything is tested, set Availability → Build Status to **Run Application Only**.
7. Sign in as the super user. Set up sites and teams, create users, and run a permit end to end.

## What's deliberately left out

See `MANIFEST.txt`. In short:

- `PTW_LV_USER_ROLES_OLD` and its index: a legacy table that no code uses.
- `DEBUG_MESSAGES`: nothing in the app or packages writes to it.
- Hand-written trigger files that the DEV export did not contain: `ptw_lv_equipment_isolation_stage_loc`, `ptw_lv_control_measures_stage_loc`, and the `*_audit_trg.sql` duplicates.
- Test companies and test users from DEV.

## Next releases

Every later change to PROD is a new folder, `releases/1.0.1/` and so on. It holds only the change scripts and a fresh `f105.sql`, so it upgrades an existing install. This full install is the baseline, used to build a new environment.
