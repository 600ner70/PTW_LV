--------------------------------------------------------------------------------
-- PTW LV release {{VERSION}} : Admin pre-requisites
-- Run as      : ADMIN  (Database Actions -> SQL, "Run Script" / F5)
-- Generated   : {{BUILT}}
--
-- Before running: create the APEX workspace with a NEW schema called PTW_PRO
-- (APEX Administration Services -> Manage Workspaces -> Create Workspace).
-- The schema MUST be called PTW_PRO: all code uses the ptw_pro. prefix.
--
-- No network ACL is needed for the geocode call (nominatim.openstreetmap.org):
-- Autonomous Database ships with an ACL that lets APEX_WEB_SERVICE call public
-- HTTPS endpoints.
--------------------------------------------------------------------------------

DECLARE
    l_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO l_count FROM dba_users WHERE username = 'PTW_PRO';
    IF l_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20001,
            'Schema PTW_PRO does not exist. Create the APEX workspace with a new schema PTW_PRO first.');
    END IF;
END;
/

-- VPD policies (14_vpd_policies.sql) are created by PTW_PRO with DBMS_RLS
GRANT EXECUTE ON SYS.DBMS_RLS TO PTW_PRO;

-- Normally granted by APEX workspace provisioning; repeated here so the
-- install does not depend on it.
GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, CREATE SEQUENCE,
      CREATE PROCEDURE, CREATE TRIGGER, CREATE TYPE, CREATE JOB TO PTW_PRO;

ALTER USER PTW_PRO QUOTA UNLIMITED ON DATA;

-- Check
SELECT privilege, table_name
FROM   dba_tab_privs
WHERE  grantee = 'PTW_PRO' AND table_name = 'DBMS_RLS';
