--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : Triggers
-- Run as      : PTW_PRO
-- Generated   : 2026-11-22 13:55 UTC by releases/build_release.py
--------------------------------------------------------------------------------

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."PTW_LV_CONTROL_MEASURES_STAGE_LOC_TRG"
AFTER INSERT OR UPDATE ON ptw_pro.ptw_lv_control_measures
FOR EACH ROW
DECLARE
    v_changed BOOLEAN := FALSE;
BEGIN
    IF INSERTING THEN
       v_changed := TRUE;
    END IF;
       --
    IF NVL(:NEW.cm_01_site_induction,'NULL') != NVL(:OLD.cm_01_site_induction,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_02_risk_assessment,'NULL') != NVL(:OLD.cm_02_risk_assessment,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_03_competence_checked,'NULL') != NVL(:OLD.cm_03_competence_checked,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_04_hazards_aware,'NULL') != NVL(:OLD.cm_04_hazards_aware,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_05_ppe_identified,'NULL') != NVL(:OLD.cm_05_ppe_identified,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_06_sources_isolated,'NULL') != NVL(:OLD.cm_06_sources_isolated,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_07_proved_dead,'NULL') != NVL(:OLD.cm_07_proved_dead,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_08_stored_energy,'NULL') != NVL(:OLD.cm_08_stored_energy,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_09_live_covered,'NULL') != NVL(:OLD.cm_09_live_covered,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_10_no_live_work,'NULL') != NVL(:OLD.cm_10_no_live_work,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_11_first_aid,'NULL') != NVL(:OLD.cm_11_first_aid,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_12_barriers,'NULL') != NVL(:OLD.cm_12_barriers,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_13_access_egress,'NULL') != NVL(:OLD.cm_13_access_egress,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_14_insulated_matting,'NULL') != NVL(:OLD.cm_14_insulated_matting,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_15_calibration_current,'NULL') != NVL(:OLD.cm_15_calibration_current,'NULL') THEN v_changed := TRUE; END IF;
    IF NVL(:NEW.cm_16_danger_signs,'NULL') != NVL(:OLD.cm_16_danger_signs,'NULL') THEN v_changed := TRUE; END IF;

    IF v_changed THEN
        INSERT INTO ptw_pro.ptw_stage_locations (
            permit_id,
            permit_stage,
            latitude,
            longitude,
            created_date,
            created_by,
            company_id
        ) VALUES (
            :NEW.permit_id,
            'CONTROL_MEASURES',
            :NEW.cm_latitude,
            :NEW.cm_longitude,
            SYSDATE,
            NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER),
            :NEW.company_id
        );
    END IF;
END ptw_lv_control_measures_stage_loc_trg;
/

ALTER TRIGGER "PTW_PRO"."PTW_LV_CONTROL_MEASURES_STAGE_LOC_TRG" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."PTW_LV_MONITORING_STAGE_LOC_TRG"
AFTER INSERT OR UPDATE ON ptw_pro.ptw_lv_monitoring
FOR EACH ROW
DECLARE
    v_changed   BOOLEAN := FALSE;
    l_latitude  NUMBER;
    l_longitude NUMBER;
BEGIN
    IF INSERTING THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.monitor_latitude;
        l_longitude := :NEW.monitor_longitude;
    END IF;

    IF NVL(:NEW.monitor_name,'NULL') != NVL(:OLD.monitor_name,'NULL') THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.monitor_latitude;
        l_longitude := :NEW.monitor_longitude;
    END IF;

    IF NVL(:NEW.monitoring_status,'NULL') != NVL(:OLD.monitoring_status,'NULL') THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.monitor_latitude;
        l_longitude := :NEW.monitor_longitude;
    END IF;

    IF (:NEW.monitor_signature IS NOT NULL AND :OLD.monitor_signature IS NOT NULL) THEN
        IF DBMS_LOB.COMPARE(:NEW.monitor_signature, :OLD.monitor_signature) != 0 THEN
            v_changed   := TRUE;
            l_latitude  := :NEW.monitor_latitude;
            l_longitude := :NEW.monitor_longitude;
        END IF;
    ELSIF (:NEW.monitor_signature IS NULL  AND :OLD.monitor_signature IS NOT NULL) OR
          (:NEW.monitor_signature IS NOT NULL AND :OLD.monitor_signature IS NULL) THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.monitor_latitude;
        l_longitude := :NEW.monitor_longitude;
    END IF;

    IF v_changed THEN
        INSERT INTO ptw_pro.ptw_stage_locations (
            permit_id,
            permit_stage,
            latitude,
            longitude,
            created_date,
            created_by,
            company_id
        ) VALUES (
            :NEW.permit_id,
            'MONITORING',
            l_latitude,
            l_longitude,
            SYSDATE,
            NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER),
            :NEW.company_id
        );
    END IF;

END ptw_lv_monitoring_stage_loc_trg;
/

ALTER TRIGGER "PTW_PRO"."PTW_LV_MONITORING_STAGE_LOC_TRG" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."PTW_LV_PERMITS_STAGE_LOC_TRG"
AFTER INSERT OR UPDATE ON ptw_pro.ptw_lv_permits
FOR EACH ROW
DECLARE
    v_changed BOOLEAN := FALSE;
    l_latitude NUMBER;
    l_longitude NUMBER;
BEGIN
    IF INSERTING THEN
       v_changed := TRUE;
    END IF;
    --
    IF NVL(:NEW.safety_programme_ref_no,'NULL') != NVL(:OLD.safety_programme_ref_no,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.isolation_diagram_serial_no,'NULL') != NVL(:OLD.isolation_diagram_serial_no,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    -- Replaced: site_details is a legacy column ptw_permit_save_pkg no
    -- longer writes to - it uses site_id (a proper FK to ptw_lv_sites)
    -- instead. Watching site_details meant changing which site a permit
    -- is assigned to was never detected here.
    IF NVL(:NEW.site_id,-999999) != NVL(:OLD.site_id,-999999) THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    -- Added: actively written by save_permit_header, was never checked
    -- here at all - editing only this field left no audit trail.
    IF NVL(:NEW.area_of_works,'NULL') != NVL(:OLD.area_of_works,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.work_description,'NULL') !=  NVL(:OLD.work_description,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.person_in_charge_name,'NULL') != NVL(:OLD.person_in_charge_name,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.supervising_company,'NULL') != NVL(:OLD.supervising_company,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.other_persons_count,-999999) != NVL(:OLD.other_persons_count,-999999) THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.client_permission_granted,'NULL') != NVL(:OLD.client_permission_granted,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.affects_it_systems,'NULL') != NVL(:OLD.affects_it_systems,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.it_permission_granted,'NULL') != NVL(:OLD.it_permission_granted,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    -- Added: actively written by save_permit_header, was never checked
    -- here at all (this is the WAH specialist-equipment field, but the
    -- column is shared/available across types).
    IF NVL(:NEW.specialist_equipment_details,'NULL') != NVL(:OLD.specialist_equipment_details,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.site_work_latitude;
      l_longitude := :NEW.site_work_longitude;
    END IF;
    IF NVL(:NEW.ppe_safety_helmet,'NULL') != NVL(:OLD.ppe_safety_helmet,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_arc_flash,'NULL') != NVL(:OLD.ppe_arc_flash,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_safety_footwear,'NULL') != NVL(:OLD.ppe_safety_footwear,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_hi_vis,'NULL') != NVL(:OLD.ppe_hi_vis,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_safety_goggles,'NULL') != NVL(:OLD.ppe_safety_goggles,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_insulating_gloves,'NULL') != NVL(:OLD.ppe_insulating_gloves,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_fall_restraint,'NULL') != NVL(:OLD.ppe_fall_restraint,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_fall_arrest,'NULL') != NVL(:OLD.ppe_fall_arrest,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_ear_defenders,'NULL') != NVL(:OLD.ppe_ear_defenders,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    IF NVL(:NEW.ppe_safety_gloves,'NULL') != NVL(:OLD.ppe_safety_gloves,'NULL') THEN
      v_changed := TRUE;
      l_latitude := :NEW.ppe_latitude;
      l_longitude := :NEW.ppe_longitude;
    END IF;
    --
    IF (:NEW.accept_person_signature IS NOT NULL AND :OLD.accept_person_signature IS NOT NULL) THEN
        IF DBMS_LOB.COMPARE(:NEW.accept_person_signature, :OLD.accept_person_signature) != 0 THEN
          v_changed := TRUE;
          l_latitude := :NEW.accept_latitude;
          l_longitude := :NEW.accept_longitude;
        END IF;
    ELSIF (:NEW.accept_person_signature IS NULL AND :OLD.accept_person_signature IS NOT NULL) OR
          (:NEW.accept_person_signature IS NOT NULL AND :OLD.accept_person_signature IS NULL) THEN
          v_changed := TRUE;
          l_latitude := :NEW.accept_latitude;
          l_longitude := :NEW.accept_longitude;
    END IF;
    IF (:NEW.auth_person_signature IS NOT NULL AND :OLD.auth_person_signature IS NOT NULL) THEN
        IF DBMS_LOB.COMPARE(:NEW.auth_person_signature, :OLD.auth_person_signature) != 0 THEN
          v_changed := TRUE;
          l_latitude := :NEW.auth_latitude;
          l_longitude := :NEW.auth_longitude;
        END IF;
    ELSIF (:NEW.auth_person_signature IS NULL AND :OLD.auth_person_signature IS NOT NULL) OR
          (:NEW.auth_person_signature IS NOT NULL AND :OLD.auth_person_signature IS NULL) THEN
          v_changed := TRUE;
          l_latitude := :NEW.auth_latitude;
          l_longitude := :NEW.auth_longitude;
    END IF;
    IF (NVL(:NEW.auth_datetime, DATE '1900-01-01') != NVL(:OLD.auth_datetime, DATE '1900-01-01')) THEN
          v_changed := TRUE;
          l_latitude := :NEW.auth_latitude;
          l_longitude := :NEW.auth_longitude;
    END IF;
    IF :NEW.current_step = 'LIVE' AND (NVL(:NEW.started_datetime, DATE '1900-01-01') != NVL(:OLD.started_datetime, DATE '1900-01-01'))THEN
          v_changed := TRUE;
          l_latitude := :NEW.started_latitude;
          l_longitude := :NEW.started_longitude;
    END IF;
    -- Equipment Isolation: catch step transition (NEXT_STEP button)
    IF NVL(:NEW.current_step,'NULL') != NVL(:OLD.current_step,'NULL')
       AND :NEW.current_step = 'EQUIP_ISOLATION' THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.equip_iso_latitude;
        l_longitude := :NEW.equip_iso_longitude;
    END IF;

    -- Equipment Isolation: catch SAVE_DRAFT within the same step
    IF :NEW.current_step = 'EQUIP_ISOLATION'
       AND NVL(:NEW.equip_iso_latitude, -999999) != NVL(:OLD.equip_iso_latitude, -999999) THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.equip_iso_latitude;
        l_longitude := :NEW.equip_iso_longitude;
    END IF;
    -- Clearance: catch step transition (most reliable signal)
    IF NVL(:NEW.current_step,'NULL') != NVL(:OLD.current_step,'NULL')
       AND :NEW.current_step = 'CLEARANCE' THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.clear_latitude;
        l_longitude := :NEW.clear_longitude;
    END IF;

    -- Cancelled: catch step transition
    IF NVL(:NEW.current_step,'NULL') != NVL(:OLD.current_step,'NULL')
       AND :NEW.current_step = 'CANCELLED' THEN
        v_changed   := TRUE;
        l_latitude  := :NEW.cancel_latitude;
        l_longitude := :NEW.cancel_longitude;
    END IF;
    IF v_changed THEN
        INSERT INTO ptw_pro.ptw_stage_locations (
            permit_id,
            permit_stage,
            latitude,
            longitude,
            created_date,
            created_by,
            company_id
        ) VALUES (
            :NEW.permit_id,
            :NEW.current_step,
            l_latitude,
            l_longitude,
            SYSDATE,
            NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER),
            :NEW.company_id
        );
    END IF;

END ptw_lv_permits_stage_loc_trg;
/

ALTER TRIGGER "PTW_PRO"."PTW_LV_PERMITS_STAGE_LOC_TRG" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_CHECKLIST_ITEMS_AUDIT"
BEFORE INSERT ON ptw_pro.ptw_checklist_items
FOR EACH ROW
BEGIN
    :NEW.created_date := SYSDATE;
    :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_CHECKLIST_ITEMS_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_AUDIT"
BEFORE INSERT OR UPDATE ON ptw_pro.ptw_lv_atw
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.created_date := CURRENT_TIMESTAMP;
        :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
    END IF;
    :NEW.modified_date := CURRENT_TIMESTAMP;
    :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_atw
FOR EACH ROW
 WHEN (NEW.company_id IS NULL) BEGIN
    :NEW.company_id := ptw_pro.ptw_sec_pkg.get_effective_company_id;

    IF :NEW.company_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20200,
            'Cannot determine company for this Authority to Work. If you are a super '
            || 'user, select a company first; otherwise contact your administrator.');
    END IF;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_EV_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_atw_events
FOR EACH ROW
BEGIN
    SELECT company_id
    INTO   :NEW.company_id
    FROM   ptw_pro.ptw_lv_atw
    WHERE  atw_id = :NEW.atw_id;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_EV_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_NUMBER"
BEFORE UPDATE OF status ON ptw_pro.ptw_lv_atw
FOR EACH ROW
 WHEN (NEW.status = 'ISSUED' AND NEW.atw_number IS NULL) DECLARE
    v_prefix VARCHAR2(4);
    v_seq    NUMBER;
    v_year   VARCHAR2(4) := TO_CHAR(:NEW.valid_date, 'YYYY');
BEGIN
    SELECT permit_prefix,
           CASE WHEN last_atw_year = v_year THEN last_atw_seq + 1 ELSE 1 END
    INTO   v_prefix, v_seq
    FROM   ptw_pro.ptw_lv_companies
    WHERE  company_id = :NEW.company_id
    FOR UPDATE;

    IF v_prefix IS NULL THEN
        RAISE_APPLICATION_ERROR(-20201,
            'Cannot generate ATW number: no permit prefix set for this company. '
            || 'Set one on the Company admin page first.');
    END IF;

    UPDATE ptw_pro.ptw_lv_companies
    SET    last_atw_seq  = v_seq,
           last_atw_year = v_year
    WHERE  company_id = :NEW.company_id;

    :NEW.atw_number := 'ATW-' || v_prefix || '/' || v_year || '/' || LPAD(v_seq, 5, '0');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20202,
            'Cannot generate ATW number: company_id ' || :NEW.company_id || ' not found.');
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_ATW_NUMBER" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_CM_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_control_measures
FOR EACH ROW
 WHEN (NEW.company_id IS NULL) BEGIN
    SELECT company_id INTO :NEW.company_id
    FROM ptw_pro.ptw_lv_permits
    WHERE permit_id = :NEW.permit_id;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_CM_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_COMPANIES_AUDIT"
BEFORE INSERT OR UPDATE ON ptw_pro.ptw_lv_companies
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.created_date := SYSTIMESTAMP;
        :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
    END IF;
    :NEW.modified_date := SYSTIMESTAMP;
    :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_COMPANIES_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_COMPANY_TYPES_AUDIT"
BEFORE INSERT ON ptw_pro.ptw_lv_company_types
FOR EACH ROW
BEGIN
    :NEW.created_date  := SYSTIMESTAMP;
    :NEW.created_by    := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
    :NEW.modified_date := SYSTIMESTAMP;
    :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_COMPANY_TYPES_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_DRA_AUDIT"
BEFORE INSERT OR UPDATE ON ptw_pro.ptw_lv_dra_assessments
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.created_date := CURRENT_TIMESTAMP;
        :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
    END IF;
    :NEW.modified_date := CURRENT_TIMESTAMP;
    :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_DRA_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_DRA_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_dra_assessments
FOR EACH ROW
 WHEN (NEW.company_id IS NULL) BEGIN
    :NEW.company_id := ptw_pro.ptw_sec_pkg.get_effective_company_id;

    IF :NEW.company_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20060,
            'Cannot determine company for this DRA. If you are a super ' ||
            'user, select a company first; otherwise contact your administrator.');
    END IF;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_DRA_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_DRA_NUMBER"
BEFORE INSERT ON ptw_pro.ptw_lv_dra_assessments
FOR EACH ROW
FOLLOWS ptw_pro.trg_ptw_lv_dra_company
DECLARE
    v_prefix VARCHAR2(4);
    v_seq    NUMBER;
    v_year   VARCHAR2(4) := TO_CHAR(NVL(:NEW.created_date, SYSDATE), 'YYYY');
BEGIN
    IF :NEW.dra_number IS NOT NULL THEN
        RETURN;
    END IF;

    IF :NEW.company_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20061,
            'Cannot generate DRA number: company_id not set. Check trigger ordering.');
    END IF;

    SELECT permit_prefix,
           CASE WHEN last_dra_year = v_year THEN last_dra_seq + 1 ELSE 1 END
    INTO   v_prefix, v_seq
    FROM   ptw_pro.ptw_lv_companies
    WHERE  company_id = :NEW.company_id
    FOR UPDATE;

    IF v_prefix IS NULL THEN
        RAISE_APPLICATION_ERROR(-20062,
            'Cannot generate DRA number: no permit prefix set for this ' ||
            'company. Set one on the Company admin page first.');
    END IF;

    UPDATE ptw_pro.ptw_lv_companies
    SET    last_dra_seq  = v_seq,
           last_dra_year = v_year
    WHERE  company_id = :NEW.company_id;

    :NEW.dra_number := 'DRA-' || v_prefix || '/' || v_year || '/' || LPAD(v_seq, 5, '0');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20063,
            'Cannot generate DRA number: company_id ' || :NEW.company_id || ' not found.');
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_DRA_NUMBER" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_ISO_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_equipment_isolation
FOR EACH ROW
 WHEN (NEW.company_id IS NULL) BEGIN
    SELECT company_id INTO :NEW.company_id
    FROM ptw_pro.ptw_lv_permits
    WHERE permit_id = :NEW.permit_id;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_ISO_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_MC_COMPANY"
    BEFORE INSERT ON ptw_pro.ptw_lv_monitoring_concerns
    FOR EACH ROW
     WHEN (NEW.company_id IS NULL) DECLARE
    v_company_id ptw_pro.ptw_lv_permits.company_id%TYPE;
BEGIN
    SELECT p.company_id
    INTO   v_company_id
    FROM   ptw_pro.ptw_lv_monitoring m
    JOIN   ptw_pro.ptw_lv_permits    p ON p.permit_id = m.permit_id
    WHERE  m.monitoring_id = :NEW.monitoring_id;

    :NEW.company_id := v_company_id;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_MC_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_MON_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_monitoring
FOR EACH ROW
 WHEN (NEW.company_id IS NULL) BEGIN
    SELECT company_id INTO :NEW.company_id
    FROM ptw_pro.ptw_lv_permits
    WHERE permit_id = :NEW.permit_id;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_MON_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_PERMITS_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_permits
FOR EACH ROW
 WHEN (NEW.company_id IS NULL) DECLARE
    v_app_user      VARCHAR2(255);
    v_company_id    ptw_pro.ptw_lv_users.company_id%TYPE;
    v_is_super_user ptw_pro.ptw_lv_users.is_super_user%TYPE;
    v_override      VARCHAR2(50);
BEGIN
    v_app_user := SYS_CONTEXT('APEX$SESSION', 'APP_USER');

    SELECT company_id, is_super_user
    INTO   v_company_id, v_is_super_user
    FROM   ptw_pro.ptw_lv_users
    WHERE  UPPER(username) = UPPER(v_app_user)
    AND    is_active = 'Y';

    IF v_is_super_user = 'Y' THEN
        v_override := V('G_OVERRIDE_COMPANY_ID');
        IF v_override IS NULL OR v_override = '' THEN
            RAISE_APPLICATION_ERROR(-20010,
                'Super User: please select a company before creating a permit.');
        END IF;
        :NEW.company_id := TO_NUMBER(v_override);
    ELSE
        IF v_company_id IS NULL THEN
            RAISE_APPLICATION_ERROR(-20011,
                'Your user account is not assigned to a company. Contact your administrator.');
        END IF;
        :NEW.company_id := v_company_id;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20012,
            'Unable to determine company for this permit.');
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_PERMITS_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_PERMIT_NUMBER"
BEFORE INSERT ON ptw_pro.ptw_lv_permits
FOR EACH ROW
DECLARE
    v_prefix VARCHAR2(4);
    v_seq    NUMBER;
    -- Use the permit's own created_date if already set
    -- (offline sync passes an explicit created_date).
    -- This ensures the year in the permit number always
    -- matches the actual date on the record.
    v_year   VARCHAR2(4) := TO_CHAR(
                                NVL(:NEW.created_date, SYSDATE),
                                'YYYY'
                            );
BEGIN
    -- If permit_number is already set leave it unchanged.
    -- (Handles any manual override or re-insert scenario.)
    IF :NEW.permit_number IS NOT NULL THEN
        RETURN;
    END IF;

    -- company_id must already be stamped by
    -- trg_ptw_lv_permits_company before this trigger fires.
    IF :NEW.company_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20013,
            'Cannot generate permit number: company_id not ' ||
            'set. Check trigger ordering.');
    END IF;

    -- Lock the company row and derive the next sequence
    -- number atomically. FOR UPDATE prevents two concurrent
    -- inserts for the same company getting the same number.
    -- Yearly reset: if last_permit_year differs from current
    -- year (or is NULL = first permit ever for this company)
    -- the sequence resets to 1.
    SELECT permit_prefix,
           CASE
               WHEN last_permit_year = v_year
               THEN last_permit_seq + 1
               ELSE 1
           END
    INTO   v_prefix, v_seq
    FROM   ptw_pro.ptw_lv_companies
    WHERE  company_id = :NEW.company_id
    FOR UPDATE;

    IF v_prefix IS NULL THEN
        RAISE_APPLICATION_ERROR(-20014,
            'Cannot generate permit number: no permit prefix ' ||
            'set for this company. Set a prefix on the ' ||
            'Company admin page first.');
    END IF;

    -- Store the updated sequence back to the company row.
    UPDATE ptw_pro.ptw_lv_companies
    SET    last_permit_seq  = v_seq,
           last_permit_year = v_year
    WHERE  company_id = :NEW.company_id;

    -- Stamp the generated permit number onto the new row.
    :NEW.permit_number := v_prefix
                       || '/' || v_year
                       || '/' || LPAD(v_seq, 5, '0');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20015,
            'Cannot generate permit number: company_id '  ||
            :NEW.company_id || ' not found.');
END trg_ptw_lv_permit_number;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_PERMIT_NUMBER" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_PHO_COMPANY"
BEFORE INSERT ON ptw_pro.ptw_lv_permit_photos
FOR EACH ROW
 WHEN (NEW.company_id IS NULL) BEGIN
    SELECT company_id INTO :NEW.company_id
    FROM ptw_pro.ptw_lv_permits
    WHERE permit_id = :NEW.permit_id;
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_PHO_COMPANY" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_SITES_AUDIT"
 BEFORE INSERT OR UPDATE ON ptw_pro.ptw_lv_sites
 FOR EACH ROW
 BEGIN
     IF INSERTING THEN
         :NEW.created_date := SYSTIMESTAMP;
         :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
     END IF;
     :NEW.modified_date := SYSTIMESTAMP;
     :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
 END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_SITES_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_TEAMS_AUDIT"
 BEFORE INSERT OR UPDATE ON ptw_pro.ptw_lv_teams
 FOR EACH ROW
 BEGIN
     IF INSERTING THEN
         :NEW.created_date := SYSTIMESTAMP;
         :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
     END IF;
     :NEW.modified_date := SYSTIMESTAMP;
     :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
 END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_TEAMS_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_TEAM_TYPES_AUDIT"
 BEFORE INSERT OR UPDATE ON ptw_pro.ptw_lv_team_types
 FOR EACH ROW
 BEGIN
     IF INSERTING THEN
         :NEW.created_date := SYSTIMESTAMP;
         :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
     END IF;
     :NEW.modified_date := SYSTIMESTAMP;
     :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
 END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_TEAM_TYPES_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_LV_USER_TYPES_AUDIT"
 BEFORE INSERT OR UPDATE ON ptw_pro.ptw_lv_user_types
 FOR EACH ROW
 BEGIN
     IF INSERTING THEN
         :NEW.created_date := SYSTIMESTAMP;
         :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
     END IF;
     :NEW.modified_date := SYSTIMESTAMP;
     :NEW.modified_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
 END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_LV_USER_TYPES_AUDIT" ENABLE;

CREATE OR REPLACE EDITIONABLE TRIGGER "PTW_PRO"."TRG_PTW_TYPES_AUDIT"
BEFORE INSERT ON ptw_pro.ptw_types
FOR EACH ROW
BEGIN
    :NEW.created_date := SYSDATE;
    :NEW.created_by   := NVL(SYS_CONTEXT('APEX$SESSION', 'APP_USER'), USER);
END;
/

ALTER TRIGGER "PTW_PRO"."TRG_PTW_TYPES_AUDIT" ENABLE;
