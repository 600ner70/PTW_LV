--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : Generate 12_reference_data.sql from DEV
-- Run in      : DEV, SQL Workshop -> SQL Commands, as PTW_PRO
-- Output      : DBMS Output. Copy ALL of it into 12_reference_data.sql
--               (replacing the placeholder block) and commit.
--
-- Covers the lookup tables that have no company_id:
--   PTW_TYPES, PTW_TYPE_SECTIONS, PTW_CHECKLIST_ITEMS, PTW_DRA_ITEMS, PTW_LV_ROLES
-- IDs are kept for types, checklist items and DRA items (children refer to
-- them); roles are matched by name (ROLE_ID is an ALWAYS identity column).
-- Afterwards the generated script moves each sequence past the highest ID.
--
-- Read-only: this script changes nothing in DEV.
--------------------------------------------------------------------------------
DECLARE
    PROCEDURE p(s VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(s); END;
    FUNCTION q(v VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE WHEN v IS NULL THEN 'NULL' ELSE '''' || REPLACE(v, '''', '''''') || '''' END;
    END;
    FUNCTION n(v NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN NVL(TO_CHAR(v, 'TM9', 'NLS_NUMERIC_CHARACTERS=''.,'''), 'NULL');
    END;
    FUNCTION d(v DATE) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE WHEN v IS NULL THEN 'NULL'
                    ELSE 'TO_DATE(''' || TO_CHAR(v, 'YYYY-MM-DD HH24:MI:SS') || ''',''YYYY-MM-DD HH24:MI:SS'')' END;
    END;
    PROCEDURE resync(p_seq VARCHAR2, p_table VARCHAR2, p_col VARCHAR2) IS
    BEGIN
        p('DECLARE l_max NUMBER; l_cur NUMBER; BEGIN');
        p('  SELECT NVL(MAX(' || p_col || '),0) INTO l_max FROM ' || p_table || ';');
        p('  l_cur := ' || p_seq || '.NEXTVAL;');
        p('  IF l_max >= l_cur THEN');
        p('    EXECUTE IMMEDIATE ''ALTER SEQUENCE ' || p_seq || ' INCREMENT BY '' || (l_max - l_cur + 1);');
        p('    l_cur := ' || p_seq || '.NEXTVAL;');
        p('    EXECUTE IMMEDIATE ''ALTER SEQUENCE ' || p_seq || ' INCREMENT BY 1'';');
        p('  END IF;');
        p('END;');
        p('/');
    END;
BEGIN
    p('--------------------------------------------------------------------------------');
    p('-- PTW LV release 1.0.0 : Reference (lookup) data');
    p('-- Run as      : PTW_PRO');
    p('-- Generated   : ' || TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI TZR') || ' from ' || SYS_CONTEXT('USERENV','DB_NAME'));
    p('--------------------------------------------------------------------------------');
    p('SET DEFINE OFF');
    p('');
    p('-- PTW_TYPES');
    FOR r IN (SELECT * FROM ptw_types ORDER BY type_id) LOOP
        p('INSERT INTO ptw_types (type_id, ptw_type, type_desc, created_date, created_by, available, has_monitoring) VALUES ('
          || n(r.type_id) || ', ' || q(r.ptw_type) || ', ' || q(r.type_desc) || ', ' || d(r.created_date) || ', '
          || q(r.created_by) || ', ' || q(r.available) || ', ' || q(r.has_monitoring) || ');');
    END LOOP;
    p('');
    p('-- PTW_TYPE_SECTIONS');
    FOR r IN (SELECT * FROM ptw_type_sections ORDER BY type_id, section_code) LOOP
        p('INSERT INTO ptw_type_sections (type_id, section_code) VALUES (' || n(r.type_id) || ', ' || q(r.section_code) || ');');
    END LOOP;
    p('');
    p('-- PTW_CHECKLIST_ITEMS');
    FOR r IN (SELECT * FROM ptw_checklist_items ORDER BY checklist_item_id) LOOP
        p('INSERT INTO ptw_checklist_items (checklist_item_id, type_id, section_code, item_code, item_seq, question_text, help_text, response_type, is_active, created_date, created_by) VALUES ('
          || n(r.checklist_item_id) || ', ' || n(r.type_id) || ', ' || q(r.section_code) || ', ' || q(r.item_code) || ', '
          || n(r.item_seq) || ', ' || q(r.question_text) || ', ' || q(r.help_text) || ', ' || q(r.response_type) || ', '
          || q(r.is_active) || ', ' || d(r.created_date) || ', ' || q(r.created_by) || ');');
    END LOOP;
    p('');
    p('-- PTW_DRA_ITEMS');
    FOR r IN (SELECT * FROM ptw_dra_items ORDER BY dra_item_id) LOOP
        p('INSERT INTO ptw_dra_items (dra_item_id, section_code, category_no, category_label, item_code, item_seq, question_text, response_type, is_active, created_date, created_by) VALUES ('
          || n(r.dra_item_id) || ', ' || q(r.section_code) || ', ' || n(r.category_no) || ', ' || q(r.category_label) || ', '
          || q(r.item_code) || ', ' || n(r.item_seq) || ', ' || q(r.question_text) || ', ' || q(r.response_type) || ', '
          || q(r.is_active) || ', ' || d(r.created_date) || ', ' || q(r.created_by) || ');');
    END LOOP;
    p('');
    p('-- PTW_LV_ROLES (ROLE_ID generated)');
    FOR r IN (SELECT * FROM ptw_lv_roles ORDER BY display_order, role_id) LOOP
        p('INSERT INTO ptw_lv_roles (role_name, role_description, is_admin_role, display_order, is_active) VALUES ('
          || q(r.role_name) || ', ' || q(r.role_description) || ', ' || q(r.is_admin_role) || ', '
          || n(r.display_order) || ', ' || q(r.is_active) || ');');
    END LOOP;
    p('');
    p('COMMIT;');
    p('');
    p('-- Move sequences past the loaded IDs');
    resync('ptw_type_id_seq',        'ptw_types',           'type_id');
    resync('ptw_checklist_item_seq', 'ptw_checklist_items', 'checklist_item_id');
    resync('ptw_dra_item_seq',       'ptw_dra_items',       'dra_item_id');
END;
/
