--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : First company, first super user, automation user
-- Run as      : PTW_PRO
-- Generated   : 2026-11-22 13:55 UTC
--
-- EDIT THE FOUR CONSTANTS BELOW before running.
-- The super user's username must match the APEX account you will create in
-- the PROD workspace (Workspace Administration -> Manage Users and Groups).
-- Safe to re-run: existing rows are left alone.
--------------------------------------------------------------------------------

DECLARE
    c_company_name   CONSTANT VARCHAR2(200) := 'CHANGE ME Ltd';   -- your first real company
    c_company_code   CONSTANT VARCHAR2(30)  := 'CHANGEME';        -- short unique code
    c_permit_prefix  CONSTANT VARCHAR2(4)   := 'CHG';             -- 1-4 UPPERCASE letters, used in permit numbers
    c_super_username CONSTANT VARCHAR2(100) := 'CHANGE.ME';       -- APEX username of the first super user

    l_company_id ptw_lv_companies.company_id%TYPE;
    l_user_id    ptw_lv_users.user_id%TYPE;
BEGIN
    IF c_company_code = 'CHANGEME' OR c_super_username = 'CHANGE.ME' THEN
        RAISE_APPLICATION_ERROR(-20004, 'Edit the constants at the top of 13_bootstrap_users.sql first.');
    END IF;

    -- 1. Company
    BEGIN
        SELECT company_id INTO l_company_id FROM ptw_lv_companies WHERE company_code = c_company_code;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        INSERT INTO ptw_lv_companies (company_name, company_code, permit_prefix, is_active, created_by)
        VALUES (c_company_name, c_company_code, c_permit_prefix, 'Y', 'RELEASE_1.0.0')
        RETURNING company_id INTO l_company_id;
    END;

    -- 2. License every available permit type to that company
    INSERT INTO ptw_lv_company_types (company_id, type_id, is_active, created_by)
    SELECT l_company_id, t.type_id, 'Y', 'RELEASE_1.0.0'
    FROM   ptw_types t
    WHERE  t.available = 'Y'
    AND    NOT EXISTS (SELECT 1 FROM ptw_lv_company_types ct
                       WHERE ct.company_id = l_company_id AND ct.type_id = t.type_id);

    -- 3. Super user (no company: sees all companies)
    BEGIN
        SELECT user_id INTO l_user_id FROM ptw_lv_users WHERE UPPER(username) = UPPER(c_super_username);
    EXCEPTION WHEN NO_DATA_FOUND THEN
        INSERT INTO ptw_lv_users (username, is_active, is_super_user, company_id, created_by)
        VALUES (UPPER(c_super_username), 'Y', 'Y', NULL, 'RELEASE_1.0.0')
        RETURNING user_id INTO l_user_id;
    END;

    -- 4. Give the super user every admin role
    INSERT INTO ptw_lv_user_role_assignments (user_id, role_id, is_active, granted_by)
    SELECT l_user_id, r.role_id, 'Y', 'RELEASE_1.0.0'
    FROM   ptw_lv_roles r
    WHERE  r.is_admin_role = 'Y'
    AND    NOT EXISTS (SELECT 1 FROM ptw_lv_user_role_assignments a
                       WHERE a.user_id = l_user_id AND a.role_id = r.role_id);

    -- 5. Automation user used by APEX Automations (from src/SQL scripts/data/add_automation_user.sql)
    MERGE INTO ptw_lv_users u
    USING (SELECT 'SYSTEM_AUTOMATION' username FROM dual) s
    ON (u.username = s.username)
    WHEN NOT MATCHED THEN
        INSERT (username, first_name, last_name, is_active, is_super_user, company_id, created_by)
        VALUES ('SYSTEM_AUTOMATION', 'System', 'Automation', 'Y', 'Y', NULL, 'SYSTEM');

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Company ' || c_company_code || ' = ' || l_company_id
                         || ', super user ' || UPPER(c_super_username) || ' = ' || l_user_id);
END;
/
