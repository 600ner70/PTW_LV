--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : Package specifications
-- Run as      : PTW_PRO
-- Generated   : 2026-11-22 13:55 UTC by releases/build_release.py
--------------------------------------------------------------------------------

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_ATW_PKG" AS
-- =====================================================================
-- Authority to Work (ATW)
--
-- Lifecycle
--   DRAFT ----(issue_atw)----> ISSUED --(check_in)--> ON_SITE
--   REQUESTED -(issue_atw)-/      ^                     |
--      (phase 2: contractor       |----(check_in)-------|  (same day only)
--       pre-fill)                 |                     v
--                                 +---------------- CHECKED_OUT
--   ISSUED / ON_SITE / CHECKED_OUT --(revoke_atw)--> REVOKED
--   ISSUED / ON_SITE / CHECKED_OUT --(expire_atws, next day)--> EXPIRED
--   DRAFT / REQUESTED --(cancel_atw or expire_atws)--> CANCELLED
--
-- All DML goes through this package. Pages never update PTW_LV_ATW
-- directly, so the rules live in one place.
--
-- Error codes: -20200 .. -20239
-- =====================================================================

    -- Site-local time zone. All ATW dates/times are stored as site-local
    -- DATEs (ADB SYSDATE is UTC by default - see feature spec, section 8).
    c_tz              CONSTANT VARCHAR2(40) := 'Europe/London';

    -- Role lists live in the body (is_issuer / can_verify / is_contractor):
    --   issue / revoke / act on behalf : ADMIN, AUTHORISER, ATW_ISSUER
    --   scan and verify                : the above + SECURITY
    -- APEX authorization schemes should call these functions rather than
    -- repeat the role lists.
    FUNCTION local_now   RETURN DATE;
    FUNCTION local_today RETURN DATE;

    FUNCTION is_issuer     (p_username IN VARCHAR2) RETURN VARCHAR2;  -- Y/N
    FUNCTION is_contractor (p_username IN VARCHAR2) RETURN VARCHAR2;  -- Y/N
    FUNCTION can_verify    (p_username IN VARCHAR2) RETURN VARCHAR2;  -- Y/N

    -- Status the pass should SHOW right now. Same as status, except a
    -- live ATW from a previous day reads EXPIRED even before the nightly
    -- automation has run.
    FUNCTION effective_status (
        p_status     IN ptw_pro.ptw_lv_atw.status%TYPE,
        p_valid_date IN ptw_pro.ptw_lv_atw.valid_date%TYPE
    ) RETURN VARCHAR2;

    ---------------------------------------------------------------------
    -- Issuer (BGIS staff) actions
    ---------------------------------------------------------------------
    -- Create (p_atw_id NULL) or update a DRAFT/REQUESTED ATW.
    PROCEDURE save_draft (
        p_atw_id            IN OUT ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_site_id           IN     ptw_pro.ptw_lv_atw.site_id%TYPE,
        p_holder_user_id    IN     ptw_pro.ptw_lv_atw.holder_user_id%TYPE,
        p_work_description  IN     ptw_pro.ptw_lv_atw.work_description%TYPE,
        p_rams_reference    IN     ptw_pro.ptw_lv_atw.rams_reference%TYPE,
        p_induction_ok      IN     ptw_pro.ptw_lv_atw.induction_ok%TYPE,
        p_ssow_ok           IN     ptw_pro.ptw_lv_atw.ssow_ok%TYPE,
        p_competence_ok     IN     ptw_pro.ptw_lv_atw.competence_ok%TYPE,
        p_equipment_ppe_ok  IN     ptw_pro.ptw_lv_atw.equipment_ppe_ok%TYPE,
        p_issuer_notes      IN     ptw_pro.ptw_lv_atw.issuer_notes%TYPE
    );

    -- Issue (sign off) a DRAFT or REQUESTED ATW for today.
    -- p_check_in_now = 'Y' also checks the holder in (issued at the gate).
    PROCEDURE issue_atw (
        p_atw_id          IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_issuer_sig_b64  IN CLOB,
        p_latitude        IN NUMBER   DEFAULT NULL,
        p_longitude       IN NUMBER   DEFAULT NULL,
        p_check_in_now    IN VARCHAR2 DEFAULT 'N'
    );

    PROCEDURE revoke_atw (
        p_atw_id  IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_reason  IN ptw_pro.ptw_lv_atw.revoke_reason%TYPE
    );

    PROCEDURE cancel_atw (
        p_atw_id  IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_reason  IN VARCHAR2 DEFAULT NULL
    );

    ---------------------------------------------------------------------
    -- Holder (contractor) or issuer-on-behalf actions
    ---------------------------------------------------------------------
    PROCEDURE check_in (
        p_atw_id     IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_latitude   IN NUMBER DEFAULT NULL,
        p_longitude  IN NUMBER DEFAULT NULL
    );

    PROCEDURE check_out (
        p_atw_id     IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_latitude   IN NUMBER DEFAULT NULL,
        p_longitude  IN NUMBER DEFAULT NULL
    );

    ---------------------------------------------------------------------
    -- Phase 2 (built now so the data model is ready): contractor
    -- pre-fills today's request; issuer then completes checks + issues.
    ---------------------------------------------------------------------
    PROCEDURE save_request (
        p_atw_id            IN OUT ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_site_id           IN     ptw_pro.ptw_lv_atw.site_id%TYPE,
        p_work_description  IN     ptw_pro.ptw_lv_atw.work_description%TYPE,
        p_rams_reference    IN     ptw_pro.ptw_lv_atw.rams_reference%TYPE
    );

    ---------------------------------------------------------------------
    -- Pass / verify
    ---------------------------------------------------------------------
    -- Today's ATW for a user (any status except CANCELLED/REVOKED), else NULL.
    FUNCTION get_today_atw_id (p_username IN VARCHAR2) RETURN NUMBER;

    -- Absolute URL encoded in the QR code. Works with the in-app scanner
    -- AND a phone's native camera (opens the verify page, login if needed).
    FUNCTION verify_url (p_token IN VARCHAR2) RETURN VARCHAR2;

    -- Wallet-style pass HTML for the pass page (dynamic content region).
    FUNCTION render_pass (p_atw_id IN ptw_pro.ptw_lv_atw.atw_id%TYPE) RETURN CLOB;

    -- Resolve a scanned token (or a full verify URL) to an atw_id and log
    -- the scan. Returns NULL if not found / other company (VPD).
    -- Raises if the caller is not allowed to verify.
    FUNCTION verify_scan (p_token_or_url IN VARCHAR2) RETURN NUMBER;

    ---------------------------------------------------------------------
    -- PTW integration  (agreed 17-OCT-2026)
    --
    -- The ATW never looks at permits. The PERMIT validates against ATWs
    -- when its people are entered (Page 2) and at acceptance (Page 5):
    --   * Person in Charge  = a contractor ON_SITE with an ATW at the
    --                         permit's site today
    --   * Company responsible = that person's employer (from the ATW)
    --   * Number of other persons <= other contractors from the same
    --                         employer ON_SITE at that site today
    --   * Skipped when the Person in Charge is BGIS staff (pic_is_bgis = 'Y')
    --
    -- c_ptw_enforce = 'N' switches all permit validation off (soft launch
    -- or emergency) without a page change.
    ---------------------------------------------------------------------
    c_ptw_enforce     CONSTANT VARCHAR2(1) := 'Y';

    -- Page-level check (Page 2 "Next Step", before anything is saved).
    -- Returns NULL if OK, otherwise the error text. Use as an APEX
    -- validation of type "Function Body (returning Error Text)".
    FUNCTION validate_permit_people (
        p_site_id             IN ptw_pro.ptw_lv_permits.site_id%TYPE,
        p_pic_is_bgis         IN VARCHAR2,
        p_atw_id              IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_supervising_company IN ptw_pro.ptw_lv_permits.supervising_company%TYPE,
        p_other_persons_count IN ptw_pro.ptw_lv_permits.other_persons_count%TYPE
    ) RETURN VARCHAR2;

    -- Same check against what is saved on the permit (Page 5 acceptance:
    -- the contractor may have checked out since Page 2 was filled in).
    FUNCTION permit_atw_problem (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    ) RETURN VARCHAR2;

    -- Raises -20230 with permit_atw_problem's text. For use inside PL/SQL
    -- (e.g. top of ptw_auth_workflow_pkg.submit_for_authorisation) so the
    -- rule holds even if a page validation is missed.
    PROCEDURE assert_permit_atw (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    );

    -- Page 2, after ptw_permit_save_pkg.save_permit_header (DRAFT only).
    -- Stores atw_id / pic_is_bgis and, for contractors, overwrites
    -- person_in_charge_name and supervising_company from the ATW so the
    -- permit always names exactly the person on the pass.
    PROCEDURE set_permit_pic (
        p_permit_id   IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_pic_is_bgis IN VARCHAR2,
        p_atw_id      IN ptw_pro.ptw_lv_atw.atw_id%TYPE
    );

    -- Comma list of live permits where this ATW's holder is Person in
    -- Charge. Display only (shown on the pass for whoever checks it).
    FUNCTION live_permit_numbers (
        p_atw_id IN ptw_pro.ptw_lv_atw.atw_id%TYPE
    ) RETURN VARCHAR2;

    ---------------------------------------------------------------------
    -- Automation (nightly, shortly after local midnight)
    ---------------------------------------------------------------------
    PROCEDURE expire_atws (p_expired OUT NUMBER, p_cancelled OUT NUMBER);

    ---------------------------------------------------------------------
    -- VPD: second policy on PTW_LV_ATW / PTW_LV_ATW_EVENTS (AND-ed with
    -- PTW_COMPANY_POLICY). A user whose ONLY role is CONTRACTOR sees only
    -- their own ATWs. Company-level VPD alone would let one contractor
    -- see every other contractor's passes, because contractors are
    -- users under the BGIS company.
    ---------------------------------------------------------------------
    FUNCTION holder_policy (
        p_schema IN VARCHAR2,
        p_object IN VARCHAR2
    ) RETURN VARCHAR2;

END ptw_atw_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_AUTH_WORKFLOW_PKG" AS

    c_awaiting_auth CONSTANT VARCHAR2(20) := 'AWAITING_AUTH';

    -- 'Y' if p_username may authorise/reject p_permit_id right now.
    FUNCTION can_authorise (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_username  IN VARCHAR2
    ) RETURN VARCHAR2;

    -- 'Y' if p_username is an active AUTHORISER/ADMIN (any permit).
    FUNCTION is_authoriser (p_username IN VARCHAR2) RETURN VARCHAR2;

    PROCEDURE submit_for_authorisation (
        p_permit_id       IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_requested_auth  IN VARCHAR2,
        p_accept_name     IN ptw_pro.ptw_signatures.person_name%TYPE,
        p_accept_mobile   IN ptw_pro.ptw_signatures.mobile_no%TYPE,
        p_accept_company  IN ptw_pro.ptw_signatures.company_name%TYPE,
        p_accept_sig_b64  IN CLOB,
        p_latitude        IN NUMBER,
        p_longitude       IN NUMBER
    );

    PROCEDURE authorise (
        p_permit_id     IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_auth_sig_b64  IN CLOB,
        p_latitude      IN NUMBER,
        p_longitude     IN NUMBER
    );

    PROCEDURE reject (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_reason    IN VARCHAR2
    );

END ptw_auth_workflow_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_CHECKLIST_PKG" AS
    --------------------------------------------------------------------------
    -- Loads the checklist for a permit: every active checklist item for the
    -- permit's PTW_TYPE, left-joined to any existing response. Type is
    -- derived from the permit itself, not passed in, so a permit_id the
    -- caller's VPD context can't see returns NO_DATA_FOUND rather than
    -- letting the caller pick an arbitrary type_id.
    --
    -- Returns a JSON array, e.g.:
    -- [{"checklist_item_id":101,"item_code":"CM_01_SITE_INDUCTION",
    --   "section":"CONTROL_MEASURES","seq":10,"question":"...",
    --   "help":"...","response_type":"TRISTATE","response":"Y"}, ...]
    --------------------------------------------------------------------------
    FUNCTION get_checklist_json(p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE)
        RETURN CLOB;

    --------------------------------------------------------------------------
    -- Saves responses from a JSON array in the same shape:
    -- [{"checklist_item_id":101,"response":"Y"}, ...]
    -- (extra keys are ignored, so the same payload from get_checklist_json
    -- can be round-tripped straight back in)
    --
    -- company_id is derived from the permit, never taken from the payload.
    --
    -- p_latitude/p_longitude are new, optional (default NULL so any other
    -- existing caller doesn't break). A CONTROL_MEASURES entry is logged to
    -- PTW_STAGE_LOCATIONS from here directly when this save actually
    -- changes something - ptw_lv_control_measures_stage_loc_trg, which used
    -- to own this, fires on the old fixed-column ptw_lv_control_measures
    -- table that nothing writes to anymore since this checklist refactor,
    -- so it's been permanently dormant and Control Measures has never
    -- appeared in permit history since.
    --------------------------------------------------------------------------
    PROCEDURE save_checklist_responses(
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_json      IN CLOB,
        p_latitude  IN NUMBER DEFAULT NULL,
        p_longitude IN NUMBER DEFAULT NULL
    );

END ptw_checklist_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_DRA_PKG" AS

    PROCEDURE save_dra_header(
        p_dra_id              IN OUT ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_dra_type            IN     ptw_pro.ptw_lv_dra_assessments.dra_type%TYPE,
        p_workflow_status     IN     ptw_pro.ptw_lv_dra_assessments.workflow_status%TYPE, -- ignored, kept for compatibility
        p_site_id             IN     ptw_pro.ptw_lv_dra_assessments.site_id%TYPE,
        p_site_details        IN     ptw_pro.ptw_lv_dra_assessments.site_details%TYPE,
        p_job_number          IN     ptw_pro.ptw_lv_dra_assessments.job_number%TYPE,
        p_engineer_name       IN     ptw_pro.ptw_lv_dra_assessments.engineer_name%TYPE,
        p_supervising_company IN     ptw_pro.ptw_lv_dra_assessments.supervising_company%TYPE,
        p_permit_id           IN     ptw_pro.ptw_lv_dra_assessments.permit_id%TYPE,
        p_latitude            IN     NUMBER,
        p_longitude           IN     NUMBER,
        p_dra_number          OUT    ptw_pro.ptw_lv_dra_assessments.dra_number%TYPE,
        p_saved               OUT    BOOLEAN,
        p_message             OUT    VARCHAR2
    );

    FUNCTION get_dra_json(p_dra_id IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE)
        RETURN CLOB;

    PROCEDURE save_dra_responses(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_json      IN CLOB
    );

    PROCEDURE save_dra_details(
        p_dra_id          IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_hazard_details  IN ptw_pro.ptw_lv_dra_assessments.hazard_details%TYPE,
        p_control_details IN ptw_pro.ptw_lv_dra_assessments.control_details%TYPE
    );

    PROCEDURE complete_dra(
        p_dra_id            IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_can_proceed       IN ptw_pro.ptw_lv_dra_assessments.stage3_can_proceed%TYPE,
        p_no_reason         IN ptw_pro.ptw_lv_dra_assessments.stage3_no_reason%TYPE DEFAULT NULL,
        p_signature_name    IN ptw_pro.ptw_lv_dra_assessments.signature_person_name%TYPE,
        p_signature_b64     IN CLOB,
        p_latitude          IN NUMBER DEFAULT NULL,
        p_longitude         IN NUMBER DEFAULT NULL
    );

    PROCEDURE cancel_dra(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_reason    IN ptw_pro.ptw_lv_dra_assessments.cancel_reason%TYPE
    );

    -- 'Y' if the DRA is COMPLETED, said work CAN proceed, and is either
    -- unlinked or already linked to p_permit_id.
    FUNCTION can_use_for_permit(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    ) RETURN VARCHAR2;

    PROCEDURE link_to_permit(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    );

END ptw_dra_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_GEOCODE_PKG" AS

    --------------------------------------------------------------------------
    -- Returns a human-readable place name for a lat/long via reverse
    -- geocoding (OpenStreetMap Nominatim), checking PTW_GEOCODE_CACHE first.
    --
    -- Never raises - returns NULL on any failure (bad coordinates, network
    -- issue, rate limit, malformed response) so a geocoding problem never
    -- blocks a page that's showing a map for another reason entirely.
    --------------------------------------------------------------------------
    FUNCTION get_place_name(
        p_latitude  IN NUMBER,
        p_longitude IN NUMBER
    ) RETURN VARCHAR2;

END ptw_geocode_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_MONITORING_PKG" AS
    --------------------------------------------------------------------------
    -- Replaces the MS_CHECK1../2../3.. column groups on PTW_LV_MONITORING.
    -- Still called 3 times today (check_seq 1,2,3) to match the current UI
    -- exactly — but nothing here caps it at 3, so lifting that cap later is
    -- a UI change only, not a schema change.
    --------------------------------------------------------------------------
    PROCEDURE save_check(
        p_monitoring_id IN ptw_pro.ptw_lv_monitoring.monitoring_id%TYPE,
        p_check_seq     IN ptw_pro.ptw_monitoring_checks.check_seq%TYPE,
        p_detail        IN ptw_pro.ptw_monitoring_checks.detail%TYPE,
        p_check_time    IN ptw_pro.ptw_monitoring_checks.check_time%TYPE,
        p_in_order      IN ptw_pro.ptw_monitoring_checks.in_order%TYPE,
        p_comments      IN ptw_pro.ptw_monitoring_checks.comments%TYPE DEFAULT NULL
    );

END ptw_monitoring_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_PDF_LIB_PKG" AS
    --------------------------------------------------------------------------
    -- STEP 2 of the run order.
    -- Shared PDF plumbing used by every per-type PDF function
    -- (GENERATE_PTW_LV_PDF, GENERATE_PTW_GENERAL_PDF, and whatever comes
    -- next). Nothing in here is permit-content that a customer would want
    -- to customise - it's formatting helpers, signature rendering, and the
    -- sections that are genuinely identical regardless of permit type
    -- (site/work details, signature stages, monitoring, stage history).
    --
    -- A type's own PDF function stays free to skip any of these and write
    -- bespoke HTML instead - nothing here is mandatory to call.
    --
    -- VISUAL UPDATE (this version): restyled GET_DOCUMENT_HEAD (the page
    -- background/header/section-title CSS, shared by every type) and
    -- GET_SITE_WORK_DETAILS_HTML (shared by every type) to read more like
    -- the original BGIS paper form and less like a web-app card: sharp
    -- corners instead of rounded, a muted neutral page background instead
    -- of a saturated colour wash, and Site & Work Details rendered as a
    -- genuine bordered 2-field-pair grid (new .ptw-lv-detail-grid class)
    -- instead of stacked single-column label:value rows. Nothing else in
    -- this package changed - Control Measures, PPE, Equipment Isolation,
    -- signatures, monitoring, history all render exactly as before.
    -- FIRE_ISOLATION_IMPLEMENTATION.md has the matching change for that
    -- type's own bespoke Client Permission section, which reuses the new
    -- grid class for visual consistency with Site & Work Details.
    --------------------------------------------------------------------------

    -- ---- Formatting helpers -------------------------------------------
    FUNCTION safe_val (p_text VARCHAR2) RETURN VARCHAR2;
    FUNCTION safe_num (p_num NUMBER) RETURN VARCHAR2;
    FUNCTION get_yn (p_value VARCHAR2) RETURN VARCHAR2;
    FUNCTION get_yn_label (p_value VARCHAR2) RETURN VARCHAR2;
    FUNCTION get_safe_label (p_value VARCHAR2) RETURN VARCHAR2;
    FUNCTION get_checked (p_value VARCHAR2) RETURN VARCHAR2;
    FUNCTION get_cm_tick (p_value VARCHAR2) RETURN VARCHAR2;
    FUNCTION get_cm_na (p_value VARCHAR2) RETURN VARCHAR2;
    FUNCTION get_cm_no (p_value VARCHAR2) RETURN VARCHAR2;
    FUNCTION fmt_datetime (p_date DATE) RETURN VARCHAR2;
    FUNCTION fmt_date (p_date DATE) RETURN VARCHAR2;
    FUNCTION get_signature_img (p_blob BLOB) RETURN CLOB;

    -- ---- Document chrome -------------------------------------------------
    -- Returns <!DOCTYPE html>...<style>...</style></head><body><div class="ptw-lv-report-container">
    -- Shared CSS, single source of truth for the visual look and feel.
    FUNCTION get_document_head (p_document_title VARCHAR2, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB;

    -- Returns </div></body></html>
    FUNCTION get_document_close RETURN CLOB;

    -- Base64 company logo, or NULL if this company has none uploaded.
    FUNCTION get_company_logo_b64 (p_company_id NUMBER) RETURN CLOB;

    -- Looks up PTW_TYPES.HAS_MONITORING for the given type code. Defaults to
    -- 'Y' if the type isn't found, so a missing/unrecognised type fails open
    -- (shows monitoring) rather than silently hiding a section that should
    -- be there.
    FUNCTION type_has_monitoring (p_ptw_type VARCHAR2) RETURN VARCHAR2;

    -- ---- Sections identical across permit types --------------------------
    FUNCTION get_site_work_details_html (p_permit_id NUMBER) RETURN CLOB;
    FUNCTION get_control_measures_html  (p_permit_id NUMBER) RETURN CLOB;
    FUNCTION get_ppe_html               (p_permit_id NUMBER) RETURN CLOB;
    -- p_ptw_type controls the column headings only (data/table structure is
    -- identical for every type - PTW_LV_EQUIPMENT_ISOLATION has no type-specific
    -- columns). Defaults to the original LV Isolation / generic wording so
    -- every existing caller is unaffected.
    FUNCTION get_equipment_isolation_html (
        p_permit_id NUMBER,
        p_ptw_type  VARCHAR2 DEFAULT 'LV ISOLATION'
    ) RETURN CLOB;
    FUNCTION get_authorisation_html     (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB;
    FUNCTION get_acceptance_html        (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB;
    FUNCTION get_clearance_html         (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB;
    FUNCTION get_cancellation_html      (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB;

    -- All monitoring visit pages, including the trailing "Generated" stamp
    -- when there are none. p_page_heading lets a type use different wording
    -- (e.g. "Low Voltage Monitoring" vs "Site Monitoring"). p_ptw_type
    -- controls the individual check labels only (data/table structure is
    -- identical for every type - PTW_LV_MONITORING has no type-specific
    -- columns). Defaults to the original wording so every existing caller
    -- is unaffected.
    FUNCTION get_monitoring_pages_html (
        p_permit_id    NUMBER,
        p_page_heading VARCHAR2 DEFAULT 'Site Monitoring',
        p_ptw_type     VARCHAR2 DEFAULT 'LV ISOLATION'
    ) RETURN CLOB;

    FUNCTION get_stage_history_html (p_permit_id NUMBER) RETURN CLOB;

END ptw_pdf_lib_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_PERMIT_LINK_PKG" AS

    -- How many permits this permit is linked to (either direction).
    -- Used by the dashboard action button - only show the Link icon's
    -- count badge, or decide whether to show the icon at all, without a
    -- caller needing to know about PTW_PERMIT_LINKS_V.
    FUNCTION get_link_count(p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE) RETURN NUMBER;

    -- Creates a link between two permits. Validates:
    --   - both permits exist and resolve to the SAME company_id (VPD
    --     scopes what you can SEE, this is what stops you INSERTing a
    --     link to a permit_id you typed in from another company)
    --   - not linking a permit to itself
    --   - not already linked, in either direction (UQ_PTW_PERMIT_LINKS_PAIR
    --     only catches one direction - this checks both before inserting)
    PROCEDURE add_link(
        p_permit_id        IN  ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_linked_permit_id IN  ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_link_note        IN  ptw_pro.ptw_permit_links.link_note%TYPE DEFAULT NULL,
        p_added            OUT BOOLEAN,
        p_message          OUT VARCHAR2
    );

    -- Removes a link by its link_id. VPD already stops a cross-company
    -- delete from matching any row; this just reports success/failure
    -- cleanly rather than a silent "0 rows deleted".
    PROCEDURE remove_link(
        p_link_id  IN  ptw_pro.ptw_permit_links.link_id%TYPE,
        p_removed  OUT BOOLEAN,
        p_message  OUT VARCHAR2
    );

END ptw_permit_link_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_PERMIT_SAVE_PKG" AS

    -- Saves (inserts or updates) a permit's Page 2 header
    -- fields. Called identically from Page 2's online
    -- "Save Permit Data" process and its "SYNC_OFFLINE_DATA"
    -- Ajax Callback - same logic, same guards, same site
    -- resolution, regardless of which context calls it.
    --
    -- p_permit_id: IN NULL means INSERT a new permit (OUT
    --   returns the new permit_id). IN NOT NULL means UPDATE
    --   that permit (OUT returns the same value unchanged).
    -- p_ptw_type: on INSERT, defaults to 'LV ISOLATION' if
    --   NULL. On UPDATE, a NULL leaves the permit's existing
    --   type untouched (never silently resets an existing
    --   permit's type).
    -- p_site_id / p_site_new_name: pass exactly one. If
    --   p_site_id is provided, it's used directly (an
    --   existing site was selected). If only
    --   p_site_new_name is provided, the procedure resolves
    --   or creates the site itself (same find-or-create +
    --   race-handling logic in both callers, not duplicated).
    -- p_workflow_status: pass the permit's CURRENT
    --   workflow_status (read by the caller before calling
    --   this procedure). If it is not 'DRAFT', the procedure
    --   does nothing and returns p_saved = FALSE,
    --   p_message = 'Permit is no longer in draft - no
    --   changes saved.' - this is the guard that was
    --   previously online-only.
    -- p_insurance_necessary: FIRE SYSTEMS ISOLATION only - Y/N,
    --   is it necessary to inform the insurance company of this
    --   activity. Paired with p_insurer_informed_datetime.
    --
    -- OUT parameters let each caller build its own response:
    --   online sets page items directly from them; offline
    --   builds its JSON {success, message} response from them.
    PROCEDURE save_permit_header(
        p_permit_id                    IN OUT ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_ptw_type                     IN     ptw_pro.ptw_lv_permits.ptw_type%TYPE,
        p_workflow_status              IN     ptw_pro.ptw_lv_permits.workflow_status%TYPE,
        p_safety_programme_ref_no      IN     ptw_pro.ptw_lv_permits.safety_programme_ref_no%TYPE,
        p_isolation_diagram_serial_no  IN     ptw_pro.ptw_lv_permits.isolation_diagram_serial_no%TYPE,
        p_site_id                      IN     ptw_pro.ptw_lv_permits.site_id%TYPE,
        p_site_new_name                IN     ptw_pro.ptw_lv_sites.site_name%TYPE,
        p_area_of_works                IN     ptw_pro.ptw_lv_permits.area_of_works%TYPE,
        p_work_description             IN     ptw_pro.ptw_lv_permits.work_description%TYPE,
        p_person_in_charge_name        IN     ptw_pro.ptw_lv_permits.person_in_charge_name%TYPE,
        p_supervising_company          IN     ptw_pro.ptw_lv_permits.supervising_company%TYPE,
        p_other_persons_count          IN     ptw_pro.ptw_lv_permits.other_persons_count%TYPE,
        p_client_permission_granted    IN     ptw_pro.ptw_lv_permits.client_permission_granted%TYPE,
        p_affects_it_systems           IN     ptw_pro.ptw_lv_permits.affects_it_systems%TYPE,
        p_it_permission_granted        IN     ptw_pro.ptw_lv_permits.it_permission_granted%TYPE,
        p_specialist_equipment_details IN     ptw_pro.ptw_lv_permits.specialist_equipment_details%TYPE,
        p_fire_systems_affected        IN     ptw_pro.ptw_lv_permits.fire_systems_affected%TYPE       DEFAULT NULL,
        p_fire_systems_isolated        IN     ptw_pro.ptw_lv_permits.fire_systems_isolated%TYPE       DEFAULT NULL,
        p_insurer_informed_datetime    IN     ptw_pro.ptw_lv_permits.insurer_informed_datetime%TYPE   DEFAULT NULL,
        p_isolation_comments           IN     ptw_pro.ptw_lv_permits.isolation_comments%TYPE          DEFAULT NULL,
        p_fire_precautions_details     IN     ptw_pro.ptw_lv_permits.fire_precautions_details%TYPE    DEFAULT NULL,
        p_fire_alarm_arrangements      IN     ptw_pro.ptw_lv_permits.fire_alarm_arrangements%TYPE     DEFAULT NULL,
        p_insurance_necessary          IN     ptw_pro.ptw_lv_permits.insurance_necessary%TYPE         DEFAULT NULL,
        p_latitude                     IN     ptw_pro.ptw_lv_permits.site_work_latitude%TYPE,
        p_longitude                    IN     ptw_pro.ptw_lv_permits.site_work_longitude%TYPE,
        p_resolved_site_id             OUT    ptw_pro.ptw_lv_sites.site_id%TYPE,
        p_permit_number                OUT    ptw_pro.ptw_lv_permits.permit_number%TYPE,
        p_saved                        OUT    BOOLEAN,
        p_message                      OUT    VARCHAR2
    );

END ptw_permit_save_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_SEC_PKG" AS

    -- Called once per APEX session (Post-Authentication process)
    PROCEDURE set_session_context(p_username IN VARCHAR2);

    -- VPD policy function — returns the predicate appended to all
    -- SELECT/UPDATE/DELETE on protected tables
    FUNCTION company_policy(
        p_schema  IN VARCHAR2,
        p_object  IN VARCHAR2
    ) RETURN VARCHAR2;

    -- Page 8 (User Management) guard: raises an error if the target user
    -- is not in the caller's company (unless caller is a super user /
    -- workspace admin). Call this at the top of every Page 8 DML process
    -- before acting on a user_id passed via page item.
    PROCEDURE check_user_in_company(p_username IN VARCHAR2);

    FUNCTION get_effective_company_id RETURN NUMBER;

END ptw_sec_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_SIGNATURE_PKG" AS
    --------------------------------------------------------------------------
    -- p_stage must be one of 'AUTH','ACCEPT','CLEAR','CANCEL','CLOSE'.
    -- p_auth_to_datetime is only ever populated for stage = 'AUTH'; pass
    -- NULL (the default) for every other stage.
    --------------------------------------------------------------------------
    PROCEDURE save_signature(
        p_permit_id        IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_stage            IN ptw_pro.ptw_signatures.stage%TYPE,
        p_person_name      IN ptw_pro.ptw_signatures.person_name%TYPE,
        p_signature_blob   IN ptw_pro.ptw_signatures.signature_blob%TYPE,
        p_mobile_no        IN ptw_pro.ptw_signatures.mobile_no%TYPE      DEFAULT NULL,
        p_company_name     IN ptw_pro.ptw_signatures.company_name%TYPE   DEFAULT NULL,
        p_event_datetime   IN ptw_pro.ptw_signatures.event_datetime%TYPE DEFAULT SYSDATE,
        p_latitude         IN ptw_pro.ptw_signatures.latitude%TYPE       DEFAULT NULL,
        p_longitude        IN ptw_pro.ptw_signatures.longitude%TYPE      DEFAULT NULL,
        p_auth_to_datetime IN ptw_pro.ptw_signatures.auth_to_datetime%TYPE DEFAULT NULL
    );

    PROCEDURE get_signature(
        p_permit_id        IN  ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_stage            IN  ptw_pro.ptw_signatures.stage%TYPE,
        p_person_name      OUT ptw_pro.ptw_signatures.person_name%TYPE,
        p_signature_blob   OUT ptw_pro.ptw_signatures.signature_blob%TYPE,
        p_mobile_no        OUT ptw_pro.ptw_signatures.mobile_no%TYPE,
        p_company_name     OUT ptw_pro.ptw_signatures.company_name%TYPE,
        p_event_datetime   OUT ptw_pro.ptw_signatures.event_datetime%TYPE,
        p_latitude         OUT ptw_pro.ptw_signatures.latitude%TYPE,
        p_longitude        OUT ptw_pro.ptw_signatures.longitude%TYPE,
        p_auth_to_datetime OUT ptw_pro.ptw_signatures.auth_to_datetime%TYPE
    );

END ptw_signature_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE "PTW_PRO"."PTW_UI_PKG" AS

    -- Workflow step bar HTML.
    --   p_permit_id    - existing permit; if supplied, ptw_type and the
    --                    furthest-progress current_step are read from the DB
    --                    and take priority over p_ptw_type for type lookup.
    --   p_ptw_type     - fallback type for new/unsaved permits (no permit_id yet).
    --   p_current_step - the step the CALLING PAGE represents (e.g. Page 2
    --                    always passes 'SITE_WORK_DETAILS', Page 4 always
    --                    passes 'EQUIP_ISOLATION'). Drives which step is
    --                    shown active (blue). Every page should pass its
    --                    own P{n}_CURRENT_STEP item here — do not omit it.
    FUNCTION get_workflow_steps_html(
        p_permit_id    IN ptw_pro.ptw_lv_permits.permit_id%TYPE    DEFAULT NULL,
        p_ptw_type     IN ptw_pro.ptw_lv_permits.ptw_type%TYPE     DEFAULT NULL,
        p_current_step IN ptw_pro.ptw_lv_permits.current_step%TYPE DEFAULT NULL
    ) RETURN CLOB;

    -- Small badge showing the permit type's description (e.g. "General
    -- Permit to Work"). Sits directly below the step bar on every page.
    FUNCTION get_permit_type_badge_html(
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE DEFAULT NULL,
        p_ptw_type  IN ptw_pro.ptw_lv_permits.ptw_type%TYPE  DEFAULT NULL
    ) RETURN CLOB;

END ptw_ui_pkg;
/
