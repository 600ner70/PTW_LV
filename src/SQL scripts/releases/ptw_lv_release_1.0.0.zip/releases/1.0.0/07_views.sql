--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : Views
-- Run as      : PTW_PRO
-- Generated   : 2026-11-22 13:55 UTC by releases/build_release.py
--------------------------------------------------------------------------------

CREATE OR REPLACE FORCE EDITIONABLE VIEW "PTW_PRO"."PTW_LV_ANALYTICS_V" ("PERMIT_ID", "PERMIT_NUMBER", "WORKFLOW_STATUS", "STATUS_DISPLAY", "STATUS_COLOUR", "COMPANY", "PERSON_IN_CHARGE", "SITE_DETAILS", "AREA_OF_WORKS", "WORK_DESCRIPTION", "CREATED_BY", "AUTH_PERSON_NAME", "CREATED_DATE_ONLY", "CREATED_DATE", "STARTED_DATETIME", "ENDED_DATETIME", "AUTH_DATETIME", "CLEAR_DATETIME", "CANCEL_DATETIME", "HAS_CLEARANCE", "HAS_CANCELLATION", "HAS_PHOTOS", "PTW_TYPE", "GROUP_DAILY", "GROUP_WEEKLY", "GROUP_MONTHLY") AS
  SELECT
    p.permit_id,
    p.permit_number,
    p.workflow_status,
    CASE p.workflow_status
        WHEN 'STARTED'     THEN 'Live'
        WHEN 'DRAFT'       THEN 'Draft'
        WHEN 'AUTHORISED'  THEN 'Authorised'
        WHEN 'COMPLETED'   THEN 'Completed'
        WHEN 'LAPSED'      THEN 'Lapsed'
        WHEN 'SUSPENDED'   THEN 'Suspended'
        WHEN 'CANCELLED'   THEN 'Cancelled'
        ELSE p.workflow_status
    END AS status_display,
    CASE p.workflow_status
        WHEN 'STARTED'     THEN '#28a745'
        WHEN 'DRAFT'       THEN '#17a2b8'
        WHEN 'AUTHORISED'  THEN '#6c757d'
        WHEN 'COMPLETED'   THEN '#6f42c1'
        WHEN 'LAPSED'      THEN '#6c757d'
        WHEN 'SUSPENDED'   THEN '#fd7e14'
        WHEN 'CANCELLED'   THEN '#dc3545'
        ELSE '#6c757d'
    END AS status_colour,
    NVL(p.supervising_company,   'Unknown') AS company,
    NVL(p.person_in_charge_name, 'Unknown') AS person_in_charge,
    NVL(COALESCE(s.site_name, p.site_details), 'Unknown') AS site_details,
    p.area_of_works,
    p.work_description,
    p.created_by,
    auth_sig.person_name AS auth_person_name,
    TRUNC(p.created_date) AS created_date_only,
    p.created_date,
    p.started_datetime,
    p.ended_datetime,
    auth_sig.event_datetime  AS auth_datetime,
    clear_sig.event_datetime AS clear_datetime,
    cancel_sig.event_datetime AS cancel_datetime,
    CASE WHEN clear_sig.event_datetime  IS NOT NULL THEN 'Y' ELSE 'N' END AS has_clearance,
    CASE WHEN cancel_sig.event_datetime IS NOT NULL THEN 'Y' ELSE 'N' END AS has_cancellation,
    CASE WHEN p.cancel_work_complete = 'N' THEN 'Y' ELSE 'N' END AS has_photos,
    p.ptw_type,
    TRUNC(p.created_date, 'DD') AS group_daily,
    TRUNC(p.created_date, 'IW') AS group_weekly,
    TRUNC(p.created_date, 'MM') AS group_monthly
FROM ptw_pro.ptw_lv_permits p
LEFT JOIN ptw_pro.ptw_lv_sites s      ON s.site_id = p.site_id
LEFT JOIN ptw_pro.ptw_signatures auth_sig
       ON auth_sig.permit_id = p.permit_id AND auth_sig.stage = 'AUTH'
LEFT JOIN ptw_pro.ptw_signatures clear_sig
       ON clear_sig.permit_id = p.permit_id AND clear_sig.stage = 'CLEAR'
LEFT JOIN ptw_pro.ptw_signatures cancel_sig
       ON cancel_sig.permit_id = p.permit_id AND cancel_sig.stage = 'CANCEL';

CREATE OR REPLACE FORCE EDITIONABLE VIEW "PTW_PRO"."PTW_LV_ATW_V" ("ATW_ID", "ATW_NUMBER", "COMPANY_ID", "SITE_ID", "SITE_NAME", "HOLDER_USER_ID", "HOLDER_USERNAME", "HOLDER_NAME", "HOLDER_EMPLOYER", "HOLDER_MOBILE", "VALID_DATE", "WORK_DESCRIPTION", "RAMS_REFERENCE", "INDUCTION_OK", "SSOW_OK", "COMPETENCE_OK", "EQUIPMENT_PPE_OK", "ISSUER_NOTES", "STATUS", "EFFECTIVE_STATUS", "REQUESTED_BY", "REQUESTED_DATETIME", "ISSUED_BY", "ISSUER_NAME", "ISSUED_DATETIME", "CHECK_IN_DATETIME", "CHECK_OUT_DATETIME", "REVOKED_BY", "REVOKED_DATETIME", "REVOKE_REASON", "EXPIRED_DATETIME", "NOT_CHECKED_OUT", "VERIFY_TOKEN", "CREATED_DATE", "CREATED_BY", "MODIFIED_DATE", "MODIFIED_BY") AS
  SELECT a.atw_id,
       a.atw_number,
       a.company_id,
       a.site_id,
       s.site_name,
       a.holder_user_id,
       UPPER(u.username)                                        AS holder_username,
       a.holder_name,
       a.holder_employer,
       a.holder_mobile,
       a.valid_date,
       a.work_description,
       a.rams_reference,
       a.induction_ok,
       a.ssow_ok,
       a.competence_ok,
       a.equipment_ppe_ok,
       a.issuer_notes,
       a.status,
       ptw_pro.ptw_atw_pkg.effective_status(a.status, a.valid_date) AS effective_status,
       a.requested_by,
       a.requested_datetime,
       a.issued_by,
       a.issuer_name,
       a.issued_datetime,
       a.check_in_datetime,
       a.check_out_datetime,
       a.revoked_by,
       a.revoked_datetime,
       a.revoke_reason,
       a.expired_datetime,
       a.not_checked_out,
       a.verify_token,
       a.created_date,
       a.created_by,
       a.modified_date,
       a.modified_by
FROM   ptw_pro.ptw_lv_atw   a
JOIN   ptw_pro.ptw_lv_sites s ON s.site_id = a.site_id
JOIN   ptw_pro.ptw_lv_users u ON u.user_id = a.holder_user_id;

CREATE OR REPLACE FORCE EDITIONABLE VIEW "PTW_PRO"."PTW_LV_CANCELLATION_REASON_V" ("PERMIT_ID", "CANCEL_WORK_COMPLETE", "CANCEL_PERSON_NAME", "CANCEL_DATETIME", "CANCEL_PERSON_SIGNATURE", "CONCERN_ID", "CHECK_NUMBER", "CHECK_LABEL", "CONCERN_DESCRIPTION", "ACTIONS_TAKEN", "CONCERN_PERSON_NAME", "CONCERN_DATETIME", "CONCERN_SIGNATURE", "IS_CONCERN_CANCELLATION") AS
  SELECT
    p.permit_id,
    p.cancel_work_complete,
    cancel_sig.person_name      AS cancel_person_name,
    cancel_sig.event_datetime   AS cancel_datetime,
    cancel_sig.signature_blob   AS cancel_person_signature,
    mc.concern_id,
    mc.check_number,
    CASE mc.check_number
        WHEN 1 THEN 'Method Statement Check 1'
        WHEN 2 THEN 'Method Statement Check 2'
        WHEN 3 THEN 'Method Statement Check 3'
    END                                            AS check_label,
    mc.concern_description,
    mc.actions_taken,
    mc.concern_person_name,
    mc.concern_datetime,
    mc.concern_signature,
    CASE WHEN mc.concern_id IS NOT NULL THEN 'Y' ELSE 'N' END AS is_concern_cancellation
FROM   ptw_pro.ptw_lv_permits p
LEFT JOIN ptw_pro.ptw_signatures cancel_sig
       ON cancel_sig.permit_id = p.permit_id AND cancel_sig.stage = 'CANCEL'
LEFT JOIN ptw_pro.ptw_lv_monitoring_concerns mc
       ON mc.happy_to_continue = 'N'
       AND mc.monitoring_id IN (
             SELECT m.monitoring_id
             FROM   ptw_pro.ptw_lv_monitoring m
             WHERE  m.permit_id = p.permit_id
           )
WHERE  p.workflow_status = 'CANCELLED';

CREATE OR REPLACE FORCE EDITIONABLE VIEW "PTW_PRO"."PTW_LV_EFFECTIVE_TYPES_V" ("USER_ID", "USERNAME", "COMPANY_ID", "TEAM_ID", "TYPE_ID", "IS_ACTIVE") AS
  SELECT
    u.user_id,
    u.username,
    u.company_id,
    u.team_id,
    ct.type_id,
    CASE
        WHEN ut.is_active IS NOT NULL THEN ut.is_active   -- engineer override wins
        WHEN tt.is_active IS NOT NULL THEN tt.is_active   -- else team override
        ELSE 'Y'                                          -- else company grant (ct pre-filtered active)
    END AS is_active
FROM ptw_pro.ptw_lv_users         u
JOIN ptw_pro.ptw_lv_company_types ct
     ON ct.company_id = u.company_id AND ct.is_active = 'Y'
LEFT JOIN ptw_pro.ptw_lv_team_types tt
     ON tt.team_id = u.team_id AND tt.type_id = ct.type_id
LEFT JOIN ptw_pro.ptw_lv_user_types ut
     ON ut.user_id = u.user_id AND ut.type_id = ct.type_id;

CREATE OR REPLACE FORCE EDITIONABLE VIEW "PTW_PRO"."PTW_LV_USER_ROLES_V" ("ROLE_ID", "USERNAME", "ROLE_NAME", "IS_ACTIVE", "USER_ACTIVE", "ROLE_ACTIVE", "FIRST_NAME", "LAST_NAME", "EMAIL_ADDRESS", "MOBILE_NO", "JOB_TITLE", "GRANTED_BY", "GRANTED_DATE", "MODIFIED_DATE", "USER_ID", "ROLE_REF_ID", "IS_ADMIN_ROLE", "ROLE_DESCRIPTION", "DISPLAY_ORDER", "COMPANY_ID", "COMPANY_NAME", "IS_SUPER_USER") AS
  SELECT
    ur.user_role_id                                         AS role_id,
    u.username,
    r.role_name,
    CASE
        WHEN u.is_active = 'Y' AND ur.is_active = 'Y' THEN 'Y'
        ELSE 'N'
    END                                                     AS is_active,
    u.is_active                                             AS user_active,
    ur.is_active                                            AS role_active,
    u.first_name,
    u.last_name,
    u.email_address,
    u.mobile_no,
    u.job_title,
    ur.granted_by,
    ur.granted_date,
    ur.modified_date,
    u.user_id,
    r.role_id                                               AS role_ref_id,
    r.is_admin_role,
    r.role_description,
    r.display_order,
    u.company_id,
    c.company_name,
    u.is_super_user
FROM   ptw_pro.ptw_lv_user_role_assignments  ur
JOIN   ptw_pro.ptw_lv_users                  u   ON u.user_id = ur.user_id
JOIN   ptw_pro.ptw_lv_roles                  r   ON r.role_id = ur.role_id
LEFT JOIN ptw_pro.ptw_lv_companies           c   ON c.company_id = u.company_id;

CREATE OR REPLACE FORCE EDITIONABLE VIEW "PTW_PRO"."PTW_PERMIT_LINKS_V" ("LINK_ID", "PERMIT_ID", "OTHER_PERMIT_ID", "LINK_NOTE", "COMPANY_ID", "CREATED_BY", "CREATED_DATE") AS
  SELECT link_id, permit_id, linked_permit_id AS other_permit_id, link_note, company_id, created_by, created_date
FROM   ptw_pro.ptw_permit_links
UNION ALL
SELECT link_id, linked_permit_id AS permit_id, permit_id AS other_permit_id, link_note, company_id, created_by, created_date
FROM   ptw_pro.ptw_permit_links;
