--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : Reference (lookup) data
-- Run as      : PTW_PRO
-- Generated   : 2026-11-22 13:55 UTC
--
-- PLACEHOLDER. The repo does not hold the reference data; it lives in DEV.
-- To fill this file:
--   1. In DEV, open SQL Workshop -> SQL Commands (as PTW_PRO).
--   2. Paste and run tools/export_reference_data_from_dev.sql.
--   3. Copy the whole DBMS Output into this file, replacing everything below
--      this header, and commit it.
--
-- Tables covered: PTW_TYPES, PTW_TYPE_SECTIONS, PTW_CHECKLIST_ITEMS,
--                 PTW_DRA_ITEMS, PTW_LV_ROLES
-- The block below stops the install so this step can't be skipped by mistake.
--------------------------------------------------------------------------------

BEGIN
    RAISE_APPLICATION_ERROR(-20003,
        '12_reference_data.sql has not been generated yet. Run tools/export_reference_data_from_dev.sql in DEV and paste its output here.');
END;
/
