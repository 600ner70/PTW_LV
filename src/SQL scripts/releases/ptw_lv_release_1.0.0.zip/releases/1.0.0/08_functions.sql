--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : Standalone functions
-- Run as      : PTW_PRO
-- Generated   : 2026-11-22 13:55 UTC by releases/build_release.py
--------------------------------------------------------------------------------

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_DRA_PDF" (
    p_dra_id IN NUMBER
) RETURN CLOB
IS
    -- Document control values printed in the footer, as on the pad.
    -- Confirm with BGIS: the pad itself says "MONTH & YEAR" for Issue Date.
    c_doc_revision   CONSTANT VARCHAR2(10) := '1';
    c_doc_issue_date CONSTANT VARCHAR2(30) := 'MONTH &amp; YEAR';
    c_doc_retention  CONSTANT VARCHAR2(30) := '3 Months';

    r           ptw_pro.ptw_lv_dra_assessments%ROWTYPE;
    v_site_name ptw_pro.ptw_lv_sites.site_name%TYPE;
    v_permit_no ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_title     VARCHAR2(100);
    v_logo_b64  CLOB;
    v_html      CLOB;
    v_last_cat  NUMBER := -1;
    v_letter    PLS_INTEGER := 0;

    FUNCTION esc (p VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN ptw_pro.ptw_pdf_lib_pkg.safe_val(p);
    END;

    -- Value or blank (the pad shows empty boxes, not "-")
    FUNCTION val (p VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE WHEN TRIM(p) IS NULL THEN '&nbsp;' ELSE esc(p) END;
    END;

    FUNCTION box (p_checked BOOLEAN) RETURN VARCHAR2 IS
    BEGIN
        RETURN '<span class="dra-box">' || CASE WHEN p_checked THEN '&#10003;' ELSE '&nbsp;' END || '</span>';
    END;

    PROCEDURE ap (p VARCHAR2) IS
    BEGIN
        DBMS_LOB.APPEND(v_html, TO_CLOB(p));
    END;

    -- Four-across label | tick grid, row-major in item_seq order (same
    -- order as the pad). A short last row stretches its final item.
    PROCEDURE tick_grid (p_section VARCHAR2, p_details VARCHAR2) IS
        TYPE t_items IS TABLE OF VARCHAR2(600) INDEX BY PLS_INTEGER;
        TYPE t_flags IS TABLE OF BOOLEAN       INDEX BY PLS_INTEGER;
        l_lbl   t_items;
        l_tick  t_flags;
        l_n     PLS_INTEGER := 0;
        l_cols  CONSTANT PLS_INTEGER := 4;
        l_rows  PLS_INTEGER;
        l_idx   PLS_INTEGER;
        l_left  PLS_INTEGER;
    BEGIN
        FOR i IN (
            SELECT di.question_text, dr.response
            FROM   ptw_pro.ptw_dra_items di
            LEFT JOIN ptw_pro.ptw_dra_responses dr
                   ON dr.dra_item_id = di.dra_item_id AND dr.dra_id = p_dra_id
            WHERE  di.section_code = p_section
            AND    di.is_active = 'Y'
            ORDER  BY di.item_seq
        ) LOOP
            l_n := l_n + 1;
            l_lbl(l_n)  := esc(i.question_text);
            l_tick(l_n) := (i.response = 'Y');
        END LOOP;

        ap('<table class="dra-grid dra-ticks"><colgroup>'
           || '<col style="width:21%"><col style="width:4%"><col style="width:21%"><col style="width:4%">'
           || '<col style="width:21%"><col style="width:4%"><col style="width:21%"><col style="width:4%">'
           || '</colgroup><tbody>');

        l_rows := CEIL(l_n / l_cols);
        FOR rw IN 1 .. l_rows LOOP
            ap('<tr>');
            l_left := l_n - (rw - 1) * l_cols;           -- items left from this row on
            FOR cl IN 1 .. LEAST(l_cols, l_left) LOOP
                l_idx := (rw - 1) * l_cols + cl;
                IF cl = l_left AND l_left < l_cols THEN
                    -- last item of a short final row spans the gap
                    ap('<td class="dra-tl" colspan="' || (1 + 2 * (l_cols - l_left)) || '">' || l_lbl(l_idx)
                       || '</td><td class="dra-tb">' || box(l_tick(l_idx)) || '</td>');
                ELSE
                    ap('<td class="dra-tl">' || l_lbl(l_idx) || '</td><td class="dra-tb">'
                       || box(l_tick(l_idx)) || '</td>');
                END IF;
            END LOOP;
            ap('</tr>');
        END LOOP;

        ap('<tr><td colspan="8" class="dra-details"><span class="dra-small">Details (and any additional Hazard Information)</span>'
           || '<div class="dra-detail-val">' || val(p_details) || '</div></td></tr>'
           || '</tbody></table>');
    END tick_grid;

BEGIN
    IF p_dra_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No DRA Selected</h2></div>';
    END IF;

    BEGIN
        SELECT * INTO r
        FROM   ptw_pro.ptw_lv_dra_assessments
        WHERE  dra_id = p_dra_id;            -- VPD scopes to the caller's company
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">DRA Not Found</h2></div>';
    END;

    IF r.site_id IS NOT NULL THEN
        SELECT MAX(site_name) INTO v_site_name FROM ptw_pro.ptw_lv_sites WHERE site_id = r.site_id;
    END IF;
    IF r.permit_id IS NOT NULL THEN
        SELECT MAX(permit_number) INTO v_permit_no FROM ptw_pro.ptw_lv_permits WHERE permit_id = r.permit_id;
    END IF;

    v_title := CASE r.dra_type
                   WHEN 'SUBCONTRACTOR' THEN 'BGIS Subcontractor Dynamic Risk Assessment'
                   ELSE 'BGIS Dynamic Risk Assessment'
               END;

    DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);
    v_logo_b64 := ptw_pro.ptw_pdf_lib_pkg.get_company_logo_b64(r.company_id);
    DBMS_LOB.APPEND(v_html, ptw_pro.ptw_pdf_lib_pkg.get_document_head(
                                v_title || ' - ' || esc(r.dra_number), 'LV ISOLATION'));

    -- ================= Styles (scoped to .dra) =================
    ap('
<style>
  .dra { font-family: Arial, Helvetica, sans-serif; color:#231F20; font-size:7.5pt; line-height:1.25;
         padding:8px 12px 4px; background:#fff; }
  .dra .navy { color:#223F75; }
  .dra table { font-size:inherit; }
  .dra-keep { break-inside:avoid; page-break-inside:avoid; }
  .dra-top { display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:3px; }
  .dra-refs { font-size:7.5pt; color:#555; }
  .dra-refs b { color:#231F20; }
  .dra-logo img { max-height:38px; max-width:180px; display:block; }
  .dra-title { border:1px solid #231F20; text-align:center; font-weight:700; font-size:13pt;
               color:#223F75; padding:1px 0; margin-bottom:3px; }
  .dra-grid { width:100%; border-collapse:collapse; table-layout:fixed; }
  .dra-grid td { border:1px solid #231F20; padding:2px 5px; vertical-align:top; }
  .dra-lbl { color:#231F20; }
  .dra-v { font-weight:700; }
  .dra-before { text-align:center; font-size:10pt; margin:3px 0 0; }
  .dra-s1head { width:100%; border-collapse:collapse; }
  .dra-s1head td { padding:0 2px 2px; font-weight:700; vertical-align:bottom; }
  .dra-stage { color:#223F75; font-size:10.5pt; width:20%; }
  .dra-stt   { color:#223F75; font-size:11pt; text-align:center; }
  .dra-ynh   { width:34px; text-align:center; font-size:8.5pt; }
  .dra-s1 { width:100%; border-collapse:collapse; border:1px solid #231F20; }
  .dra-s1 td { padding:0 5px; height:12px; line-height:1.15; vertical-align:middle; }
  .dra-s1 tr.dra-cat td { border-top:1px solid #231F20; color:#223F75; font-weight:700; padding-top:2px; }
  .dra-s1 td.dra-yn { width:34px; text-align:center; border-left:1px solid #231F20; }
  .dra-box { display:inline-block; width:9px; height:9px; line-height:9px; border:1px solid #231F20;
             text-align:center; font-size:7pt; font-weight:700; color:#223F75; vertical-align:middle; flex-shrink:0; }
  .dra-h2 { color:#223F75; font-weight:700; font-size:10pt; margin:4px 0 0; }
  .dra-sub { font-size:7.5pt; margin-bottom:2px; }
  .dra-small { font-size:7pt; color:#555; }
  .dra-ticks td { padding:0 3px; vertical-align:middle; }
  .dra-ticks td.dra-tl { text-align:center; font-size:7pt; line-height:1.1; }
  .dra-ticks td.dra-tb { text-align:center; padding:1px 0; }
  .dra-details { height:22px; }
  .dra-detail-val { font-weight:700; margin-top:2px; white-space:pre-wrap; }
  .dra-s3 { margin:4px 0 2px; font-size:8pt; display:flex; align-items:flex-end; gap:5px; flex-wrap:nowrap; white-space:nowrap; }
  .dra-s3 .dra-stage { width:auto; }
  .dra-sig { display:inline-block; flex:1; min-width:110px; height:26px; border-bottom:1px solid #231F20; vertical-align:bottom; }
  .dra-sig img { max-height:26px; max-width:200px; display:block; }
  .dra-sig-meta { font-size:7pt; color:#555; margin-top:2px; }
  .dra-no td { height:32px; }
  .dra-no td.dra-no-l { width:30%; }
  .dra-no-h { color:#223F75; font-weight:700; font-size:9pt; }
  .dra-foot { width:72%; margin:5px auto 1px; border-collapse:collapse; font-size:7pt; text-align:center; }
  .dra-foot td { border:1px solid #231F20; padding:1px 4px; font-weight:700; }
  .dra-gen { text-align:center; font-size:6.5pt; color:#888; }
  .dra-banner { padding:4px 8px; margin:4px 0; font-weight:700; text-align:center; border:1px solid; }
  .dra-banner.draft { background:#fff3cd; border-color:#e0b100; color:#7a5c00; }
  .dra-banner.cancel { background:#f8d7da; border-color:#c0392b; color:#721c24; }
  .dra tr, .dra-ticks tr { page-break-inside:avoid; break-inside:avoid; }
  @media print { .dra { padding:0; } }
</style>
<div class="dra">');

    -- ================= Header =================
    ap('<div class="dra-top"><div class="dra-refs">DRA No.: <b>' || esc(r.dra_number) || '</b>'
       || CASE WHEN v_permit_no IS NOT NULL THEN ' &nbsp;|&nbsp; Related Permit: <b>' || esc(v_permit_no) || '</b>' END
       || CASE WHEN r.dra_type = 'SUBCONTRACTOR'
               THEN ' &nbsp;|&nbsp; Subcontractor: <b>' || esc(r.supervising_company) || '</b>' END
       || '</div><div class="dra-logo">');
    IF v_logo_b64 IS NOT NULL THEN
        ap('<img src="data:image/png;base64,');
        DBMS_LOB.APPEND(v_html, v_logo_b64);
        ap('" alt="Company Logo">');
    END IF;
    ap('</div></div>');

    IF r.workflow_status = 'DRAFT' THEN
        ap('<div class="dra-banner draft">DRAFT - this DRA has not been completed and signed</div>');
    ELSIF r.workflow_status = 'CANCELLED' THEN
        ap('<div class="dra-banner cancel">CANCELLED ' || ptw_pro.ptw_pdf_lib_pkg.fmt_datetime(r.cancel_datetime)
           || ' - ' || esc(r.cancel_reason) || '</div>');
    END IF;

    ap('<div class="dra-title">' || v_title || '</div>');

    -- ================= Details grid =================
    ap('<table class="dra-grid"><colgroup><col style="width:50%"><col style="width:27%"><col style="width:23%"></colgroup><tbody>
        <tr><td rowspan="3"><span class="dra-lbl">Task and Work Location Details:</span>
                <div class="dra-v" style="margin-top:3px;white-space:pre-wrap;">' || val(r.site_details) || '</div></td>
            <td colspan="2"><span class="dra-lbl">Engineer Name:</span> <span class="dra-v">' || val(r.engineer_name) || '</span></td></tr>
        <tr><td colspan="2"><span class="dra-lbl">Client Site:</span> <span class="dra-v">' || val(v_site_name) || '</span></td></tr>
        <tr><td><span class="dra-lbl">Job Number:</span> <span class="dra-v">' || val(r.job_number) || '</span></td>
            <td><span class="dra-lbl">Date:</span> <span class="dra-v">' || TO_CHAR(r.assessment_date, 'DD/MM/YYYY') || '</span></td></tr>
        </tbody></table>');

    -- ================= Stage 1 =================
    ap('<div class="dra-before">Before Attempting Work</div>
        <table class="dra-s1head"><tr>
          <td class="dra-stage">Stage 1</td>
          <td class="dra-stt">STOP &amp; THINK</td>
          <td class="dra-ynh">YES</td><td class="dra-ynh navy">NO</td>
        </tr></table>
        <table class="dra-s1"><tbody>');

    FOR q IN (
        SELECT di.category_no, di.category_label, di.question_text, dr.response
        FROM   ptw_pro.ptw_dra_items di
        LEFT JOIN ptw_pro.ptw_dra_responses dr
               ON dr.dra_item_id = di.dra_item_id AND dr.dra_id = p_dra_id
        WHERE  di.section_code = 'STAGE1'
        AND    di.is_active = 'Y'
        ORDER  BY di.item_seq
    ) LOOP
        IF NVL(q.category_no, -1) <> v_last_cat THEN
            v_last_cat := NVL(q.category_no, -1);
            v_letter   := 0;
            ap('<tr class="dra-cat"><td>' || UPPER(esc(q.category_label)) || '</td>'
               || '<td class="dra-yn"></td><td class="dra-yn"></td></tr>');
        END IF;
        v_letter := v_letter + 1;
        ap('<tr><td>' || CHR(96 + v_letter) || ') ' || esc(q.question_text) || '</td>'
           || '<td class="dra-yn">' || box(q.response = 'YES') || '</td>'
           || '<td class="dra-yn">' || box(q.response = 'NO')  || '</td></tr>');
    END LOOP;
    ap('</tbody></table>');

    -- ================= Stage 2A / 2B =================
    ap('<div class="dra-keep"><div class="dra-h2">Stage 2A Identify Hazards</div>
        <div class="dra-sub">From the list below identify applicable HAZARDS and select your CONTROLS before moving to
          <b class="navy">STAGE 3</b> <span class="dra-small">(there may be others not on this list above)</span></div>');
    tick_grid('HAZARDS', r.hazard_details);
    ap('</div>');

    ap('<div class="dra-keep"><div class="dra-h2">Stage 2B Identify Controls</div>');
    tick_grid('CONTROLS', r.control_details);
    ap('</div>');

    -- ================= Stage 3 =================
    ap('<div class="dra-keep"><div class="dra-s3"><span class="dra-stage" style="font-weight:700;">Stage 3</span>
          <span>Can this task be completed with minimal (tolerable) risk to yourself and others?</span>
          <b>YES</b> ' || box(r.stage3_can_proceed = 'YES') ||
        ' <b class="navy">NO</b> ' || box(r.stage3_can_proceed = 'NO') ||
        ' <span>Signature:</span> <span class="dra-sig">');
    IF r.signature IS NOT NULL THEN
        DBMS_LOB.APPEND(v_html, ptw_pro.ptw_pdf_lib_pkg.get_signature_img(r.signature));
    ELSE
        ap('&nbsp;');
    END IF;
    ap('</span></div>');

    ap('<table class="dra-grid dra-no"><tbody><tr>
          <td class="dra-no-l"><div class="dra-no-h">If NO, Do NOT Proceed</div>
              Refer to your supervisor / line manager and record your reasons here:</td>
          <td class="dra-v" style="white-space:pre-wrap;">'
          || CASE WHEN r.stage3_can_proceed = 'NO' THEN val(r.stage3_no_reason) ELSE '&nbsp;' END ||
       '</td></tr></tbody></table>');
    IF r.signed_datetime IS NOT NULL THEN
        ap('<div class="dra-sig-meta">Signed by ' || esc(r.signature_person_name) || ' on '
           || ptw_pro.ptw_pdf_lib_pkg.fmt_datetime(r.signed_datetime) || '</div>');
    END IF;
    ap('</div>');

    -- ================= Footer (document control, as on the pad) =================
    ap('<table class="dra-foot"><tbody>
          <tr><td>Document Title:</td><td>Revision:</td><td>Issue Date:</td><td>Retention Period:</td></tr>
          <tr><td>BGIS Dynamic Risk Assessment</td><td>' || c_doc_revision || '</td><td>'
              || c_doc_issue_date || '</td><td>' || c_doc_retention || '</td></tr>
        </tbody></table>
        <div class="dra-gen">Generated ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') || ' &nbsp;|&nbsp; '
        || esc(r.dra_number) || '</div>
</div>');

    DBMS_LOB.APPEND(v_html, ptw_pro.ptw_pdf_lib_pkg.get_document_close);
    RETURN v_html;

EXCEPTION
    WHEN OTHERS THEN
        RETURN '<html><body><h2 style="color:red;">Error Generating DRA Report</h2>'
            || '<p>' || SQLERRM || '</p><pre>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || '</pre></body></html>';
END generate_ptw_dra_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_FIREISOLATION_PDF" (
    p_permit_id       IN NUMBER,
    p_include_history IN VARCHAR2 DEFAULT 'N'
) RETURN CLOB
IS
    v_permit_number        ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_company_id           ptw_pro.ptw_lv_permits.company_id%TYPE;
    v_client_perm          ptw_pro.ptw_lv_permits.client_permission_granted%TYPE;
    v_affects_it           ptw_pro.ptw_lv_permits.affects_it_systems%TYPE;
    v_it_perm              ptw_pro.ptw_lv_permits.it_permission_granted%TYPE;
    v_fire_affected        ptw_pro.ptw_lv_permits.fire_systems_affected%TYPE;
    v_fire_isolated        ptw_pro.ptw_lv_permits.fire_systems_isolated%TYPE;
    v_insurance_necessary  ptw_pro.ptw_lv_permits.insurance_necessary%TYPE;
    v_insurer_informed_dt  ptw_pro.ptw_lv_permits.insurer_informed_datetime%TYPE;
    v_isolation_comments   ptw_pro.ptw_lv_permits.isolation_comments%TYPE;
    v_fire_precautions     ptw_pro.ptw_lv_permits.fire_precautions_details%TYPE;
    v_fire_alarm_arr       ptw_pro.ptw_lv_permits.fire_alarm_arrangements%TYPE;
    v_xref_permit_number   ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_logo_b64             CLOB;
    v_html                 CLOB;
    v_row_num              NUMBER := 0;

BEGIN
    DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

    IF p_permit_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No Permit Selected</h2></div>';
    END IF;

    BEGIN
        SELECT permit_number, company_id, client_permission_granted,
               affects_it_systems, it_permission_granted,
               fire_systems_affected, fire_systems_isolated,
               insurance_necessary, insurer_informed_datetime, isolation_comments,
               fire_precautions_details, fire_alarm_arrangements
        INTO   v_permit_number, v_company_id, v_client_perm,
               v_affects_it, v_it_perm,
               v_fire_affected, v_fire_isolated,
               v_insurance_necessary, v_insurer_informed_dt, v_isolation_comments,
               v_fire_precautions, v_fire_alarm_arr
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">Permit Not Found</h2>'
                || '<p>Permit ID: ' || p_permit_id || '</p></div>';
    END;

    -- Cross-reference: the linked permit (via PTW_PERMIT_LINKS_V) whose
    -- own type is HOT WORK, shown as a header banner reference only -
    -- no data is pulled in from that permit. If more than one is linked
    -- (unusual but not prevented), the most recently created link wins.
    BEGIN
        SELECT op.permit_number
        INTO   v_xref_permit_number
        FROM   ptw_pro.ptw_permit_links_v lv
        JOIN   ptw_pro.ptw_lv_permits op ON op.permit_id = lv.other_permit_id
        WHERE  lv.permit_id = p_permit_id
        AND    op.ptw_type  = 'HOT WORK'
        ORDER  BY lv.created_date DESC
        FETCH FIRST 1 ROW ONLY;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            v_xref_permit_number := NULL;
    END;

    v_logo_b64 := ptw_pro.ptw_pdf_lib_pkg.get_company_logo_b64(v_company_id);

    v_html := ptw_pro.ptw_pdf_lib_pkg.get_document_head(
        'Fire Systems Isolation - ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number),
        'FIRE SYSTEMS ISOLATION');

    -- ============================================================
    -- HEADER - cross-reference banner (mirrors the source form's own
    -- top banner: "Fire Isolation: Hot Work Permit No. ___ has been
    -- raised to supplement this Fire Isolation Certificate. No. ___"),
    -- title, then the caution strip (present on the source, missing
    -- from v1).
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-header">
        <div style="display:flex;justify-content:space-between;
                    align-items:center;margin-bottom:8px;">
            <h1 style="margin:0;">Fire Systems Isolation Certificate</h1>';

    IF v_logo_b64 IS NOT NULL THEN
        v_html := v_html || '<img src="data:image/png;base64,';
        DBMS_LOB.APPEND(v_html, v_logo_b64);
        v_html := v_html || '" style="max-height:40px;margin-left:20px;" alt="Company Logo" />';
    END IF;

    v_html := v_html || '
        </div>
        <div class="header-refs">
            <div>Certificate No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '</strong></div>
            <div>Hot Work Permit No.:<br><strong>' ||
                NVL(ptw_pro.ptw_pdf_lib_pkg.safe_val(v_xref_permit_number), 'Not linked') || '</strong></div>
        </div>
    </div>
    <div style="padding:5px 12px;font-size:7.5pt;color:#555;
                border-bottom:1px solid #c0c0c0;">
        This certificate must be correctly authorised. On expiry, return all copies of this certificate
        to the certificate Issuer. Do not leave site until this certificate is cancelled.
    </div>';

    -- ============================================================
    -- SHARED: Site & Work Details
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_site_work_details_html(p_permit_id);

    -- ============================================================
    -- CLIENT PERMISSION / IT SYSTEMS / FIRE SYSTEMS / INSURANCE -
    -- bespoke, self-contained. Covers every question in the source
    -- form's top block that isn't already in Site & Work Details.
    --
    -- Rendered as a bordered 2-question-per-row grid (.ptw-lv-detail-grid,
    -- shared with Site & Work Details above - see
    -- ptw_pdf_lib_pkg.get_document_head) instead of one full-width
    -- question per row, matching the denser grid look of the source
    -- form's own Yes/No question block.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Client Permission / Fire &amp; Smoke Systems / Insurance</div>
        <table class="ptw-lv-detail-grid">
            <tr>
                <td class="g-label">Has the client granted permission for these works to proceed?</td>
                <td class="g-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_client_perm) || '</td>
                <td class="g-label">Is it necessary to inform the insurance company of this activity?</td>
                <td class="g-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_insurance_necessary) || '</td>
            </tr>';

    IF v_insurance_necessary = 'Y' THEN
        v_html := v_html || '
            <tr>
                <td class="g-label-wide">Date and time insurance company informed</td>
                <td class="g-value-wide" colspan="3">' || ptw_pro.ptw_pdf_lib_pkg.fmt_datetime(v_insurer_informed_dt) || '</td>
            </tr>';
    END IF;

    v_html := v_html || '
            <tr>
                <td class="g-label">Will any fixed smoke/fire detection or suppression systems be affected?</td>
                <td class="g-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_fire_affected) || '</td>
                <td class="g-label">If &lsquo;Yes&rsquo;, have they been isolated or impeded?</td>
                <td class="g-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_fire_isolated) || '</td>
            </tr>
            <tr>
                <td class="g-label">Will these works affect any IT or other business critical systems?</td>
                <td class="g-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_affects_it) || '</td>
                <td class="g-label">If &lsquo;Yes&rsquo;, has permission been granted to proceed?</td>
                <td class="g-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_it_perm) || '</td>
            </tr>
        </table>';

    v_html := v_html || '
    </div>';

    -- ============================================================
    -- FIRE PRECAUTIONS / FIRE ALARM ARRANGEMENTS - free text, both
    -- present on the source form under the Client Permission block.
    -- ============================================================
    IF v_fire_precautions IS NOT NULL OR v_fire_alarm_arr IS NOT NULL THEN
        v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Fire Precautions &amp; Alarm Arrangements</div>';

        IF v_fire_precautions IS NOT NULL THEN
            v_html := v_html || '
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Details of adequate fire precautions taken when smoke/fire detection and/or suppression systems have been isolated (fire extinguishers, blankets, etc.)</div>
            <div class="ptw-lv-value">' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_fire_precautions) || '</div>
        </div>';
        END IF;

        IF v_fire_alarm_arr IS NOT NULL THEN
            v_html := v_html || '
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Details of adequate means of raising the fire alarm during the works and/or during the period when smoke/fire detection and/or suppression systems are inhibited</div>
            <div class="ptw-lv-value">' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_fire_alarm_arr) || '</div>
        </div>';
        END IF;

        v_html := v_html || '
    </div>';
    END IF;

    -- ============================================================
    -- CONTROL MEASURES - bespoke 2-column (Tick / N/A) table, matching
    -- the source form (which has no "No" column, only Tick/N/A). NOT
    -- ptw_pdf_lib_pkg.get_control_measures_html (3-column, shared and
    -- untouched for every other type).
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Control Measures which must be in place before issuing this Fire Systems Isolation Certificate</div>
        <table class="ptw-lv-table">
            <thead>
                <tr>
                    <th class="cm-number">No.</th>
                    <th>Control Measure</th>
                    <th class="cm-tick">Tick, confirming compliance</th>
                    <th class="cm-tick">N/A</th>
                </tr>
            </thead>
            <tbody>';

    FOR cm_item IN (
        SELECT ci.item_seq, ci.question_text, cr.response
        FROM   ptw_pro.ptw_checklist_items ci
        JOIN   ptw_pro.ptw_lv_permits p ON p.permit_id = p_permit_id
        JOIN   ptw_pro.ptw_types t       ON t.ptw_type = p.ptw_type AND t.type_id = ci.type_id
        LEFT JOIN ptw_pro.ptw_checklist_responses cr
               ON cr.checklist_item_id = ci.checklist_item_id AND cr.permit_id = p_permit_id
        WHERE  ci.section_code = 'CONTROL_MEASURES'
        AND    ci.is_active = 'Y'
        ORDER BY ci.item_seq
    ) LOOP
        v_row_num := v_row_num + 1;
        DBMS_LOB.APPEND(v_html, TO_CLOB('
                <tr><td class="cm-number">' || v_row_num || '</td>
                    <td>' || ptw_pro.ptw_pdf_lib_pkg.safe_val(cm_item.question_text) || '</td>
                    <td class="cm-tick">' || ptw_pro.ptw_pdf_lib_pkg.get_cm_tick(cm_item.response) || '</td>
                    <td class="cm-tick">' || ptw_pro.ptw_pdf_lib_pkg.get_cm_na(cm_item.response)   || '</td></tr>'));
    END LOOP;

    v_html := v_html || '
            </tbody>
        </table>
    </div>';

    -- ============================================================
    -- FIRE WATCH PROCEDURES - this certificate's OWN sign-offs only
    -- (PTW_HOTWORK_FIRE_WATCH.permit_id = p_permit_id). Same table,
    -- same 6 milestones, same query shape as
    -- GENERATE_PTW_HOTWORK_PDF - see v5 note above.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Fire Watch Procedures</div>
        <table class="ptw-lv-table" style="font-size:8pt;">
            <thead><tr><th>Milestone</th><th>Signed By</th><th>Date/Time</th><th>Signature</th></tr></thead>
            <tbody>';

    FOR fw_row IN (
        SELECT m.label, fw.signed_by, fw.signed_datetime, fw.signature_blob
        FROM   (SELECT 1 seq, 'HW_COMPLETE' milestone_code, 'Hot Works Completed' label FROM dual UNION ALL
                SELECT 2, 'ATTEND_1ST_HR', '100% Attendance (1st Hour)' FROM dual UNION ALL
                SELECT 3, 'CHECK_15MIN_2ND_HR', 'Checked Every 15 Min (2nd Hour)' FROM dual UNION ALL
                SELECT 4, 'CHECK_30MIN_3RD_HR', 'Checked Every 30 Min (3rd Hour)' FROM dual UNION ALL
                SELECT 5, 'REINSTATE_4TH_HR', 'Reinstate Isolation (4th Hour)' FROM dual UNION ALL
                SELECT 6, 'FIRE_CHECKS_COMPLETE', 'Completion of Fire Checks' FROM dual) m
        LEFT JOIN ptw_pro.ptw_hotwork_fire_watch fw
               ON fw.permit_id = p_permit_id AND fw.milestone_code = m.milestone_code
        ORDER BY m.seq
    ) LOOP
        DBMS_LOB.APPEND(v_html, TO_CLOB(
            '<tr><td><strong style="color:#c0392b;">' || fw_row.label || '</strong></td><td>'
            || ptw_pro.ptw_pdf_lib_pkg.safe_val(fw_row.signed_by) || '</td><td>'
            || ptw_pro.ptw_pdf_lib_pkg.fmt_datetime(fw_row.signed_datetime) || '</td><td>'));
        DBMS_LOB.APPEND(v_html, TO_CLOB(ptw_pro.ptw_pdf_lib_pkg.get_signature_img(fw_row.signature_blob)));
        DBMS_LOB.APPEND(v_html, TO_CLOB('</td></tr>'));
    END LOOP;

    v_html := v_html || '
            </tbody>
        </table>
    </div>';

    -- ============================================================
    -- SHARED: PPE
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_ppe_html(p_permit_id);

    -- ============================================================
    -- SHARED: Equipment Isolation - relabelled for this type
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_equipment_isolation_html(p_permit_id, 'FIRE SYSTEMS ISOLATION');

    -- ============================================================
    -- COMMENTS
    -- ============================================================
    IF v_isolation_comments IS NOT NULL THEN
        v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Comments &amp; References to Associated Safety Documentation</div>
        <div class="ptw-lv-value" style="padding:6px 12px;">' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_isolation_comments) || '</div>
    </div>';
    END IF;

    -- ============================================================
    -- SHARED: Authorisation / Acceptance / Clearance / Cancellation
    -- - falls through to the existing DEFAULT wording branch.
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_authorisation_html(p_permit_id, 'FIRE SYSTEMS ISOLATION');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_acceptance_html(p_permit_id, 'FIRE SYSTEMS ISOLATION');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_clearance_html(p_permit_id, 'FIRE SYSTEMS ISOLATION');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_cancellation_html(p_permit_id, 'FIRE SYSTEMS ISOLATION');

    -- ============================================================
    -- FOOTER - 5-year retention text, word-for-word from source PDF
    -- ============================================================
    v_html := v_html || '
    <div class="footer">
        During the works the Original copy shall be retained by the &lsquo;Authorised Person&rsquo;
        and the copy shall be retained by the &lsquo;Person in Charge&rsquo; of the work and must
        have it available at all times for inspection. On completion of the works, the copy must be
        returned and both parts are signed when cancelling this Permit. Retention period 5 years.
        <br>Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') ||
        ' &nbsp;|&nbsp; Fire Systems Isolation Certificate: ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '
    </div>';

    -- ============================================================
    -- MONITORING - corrected from v1: this type DOES have monitoring.
    -- ============================================================
    IF ptw_pro.ptw_pdf_lib_pkg.type_has_monitoring('FIRE SYSTEMS ISOLATION') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_monitoring_pages_html(
            p_permit_id, 'Fire System Isolation Monitoring', 'FIRE SYSTEMS ISOLATION');
    END IF;

    IF NVL(p_include_history, 'N') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_stage_history_html(p_permit_id);
    END IF;

    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_document_close;

    RETURN v_html;

EXCEPTION
    WHEN OTHERS THEN
        RETURN '<html><body>'
            || '<h2 style="color:red;">Error Generating Report</h2>'
            || '<p>' || SQLERRM || '</p>'
            || '<pre>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || '</pre>'
            || '</body></html>';
END generate_ptw_fireisolation_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_GENERAL_PDF" (
    p_permit_id       IN NUMBER,
    p_include_history IN VARCHAR2 DEFAULT 'N'
) RETURN CLOB
IS
    v_permit_number ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_company_id    ptw_pro.ptw_lv_permits.company_id%TYPE;
    v_logo_b64      CLOB;
    v_html          CLOB;
BEGIN
    DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

    IF p_permit_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No Permit Selected</h2></div>';
    END IF;

    BEGIN
        SELECT permit_number, company_id
        INTO   v_permit_number, v_company_id
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">Permit Not Found</h2>'
                || '<p>Permit ID: ' || p_permit_id || '</p></div>';
    END;

    v_logo_b64 := ptw_pro.ptw_pdf_lib_pkg.get_company_logo_b64(v_company_id);

    v_html := ptw_pro.ptw_pdf_lib_pkg.get_document_head(
        'Permit to Work General - ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number), 'GENERAL');

    -- ============================================================
    -- HEADER (General-specific)
    -- Removed: "Safety Programme Reference No." — that's an LV-only
    -- field (isolation/earthing diagram tracking); General's real form
    -- has no equivalent field at all.
    -- Added: the compliance banner that sits directly under the title
    -- on the real form, previously dropped entirely.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-header">
        <div style="display:flex;justify-content:space-between;
                    align-items:center;margin-bottom:8px;">
            <h1 style="margin:0;">Permit to Work &mdash; General</h1>';

    IF v_logo_b64 IS NOT NULL THEN
        v_html := v_html || '<img src="data:image/png;base64,';
        DBMS_LOB.APPEND(v_html, v_logo_b64);
        v_html := v_html || '" style="max-height:40px;margin-left:20px;" alt="Company Logo" />';
    END IF;

    v_html := v_html || '
        </div>
        <div style="font-size:7.5pt;font-style:italic;font-weight:700;
                    border-top:1px solid rgba(0,0,0,0.15);
                    padding-top:6px;margin-top:4px;">
            All sections of this Permit MUST BE completed and all risk measures fully
            complied with. Permits can only be issued by an authorised person.
        </div>
        <div class="header-refs" style="margin-top:6px;">
            <div>Permit to Work No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '</strong></div>
        </div>
    </div>';

    -- ============================================================
    -- SHARED SECTIONS — same as LV, no Equipment Isolation between
    -- PPE and Authorisation for General.
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_site_work_details_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_control_measures_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_ppe_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_authorisation_html(p_permit_id, 'GENERAL');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_acceptance_html(p_permit_id, 'GENERAL');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_clearance_html(p_permit_id, 'GENERAL');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_cancellation_html(p_permit_id, 'GENERAL');

    -- ============================================================
    -- FOOTER (General-specific: conditional 1/6-year retention —
    -- taken directly from the source PDF's closure page)
    -- ============================================================
    v_html := v_html || '
    <div class="footer">
        These records must be retained for a minimum of 1 year unless an accident or
        incident has occurred anywhere on site during the time the permit is open, in
        which case the records must be retained for 6 years.
        <br>Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') ||
        ' &nbsp;|&nbsp; Permit: ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '
    </div>';

    -- ============================================================
    -- MONITORING PAGES — only if this permit type has monitoring at all.
    -- GENERAL's real form has no monitoring page (confirmed against the
    -- source PDF), so this section is skipped for GENERAL now that
    -- PTW_TYPES.HAS_MONITORING controls it rather than being unconditional.
    -- ============================================================
    IF ptw_pro.ptw_pdf_lib_pkg.type_has_monitoring('GENERAL') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_monitoring_pages_html(
            p_permit_id, 'Site Monitoring');
    END IF;

    -- ============================================================
    -- STAGE HISTORY (shared, only when requested)
    -- ============================================================
    IF NVL(p_include_history, 'N') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_stage_history_html(p_permit_id);
    END IF;

    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_document_close;

    RETURN v_html;

EXCEPTION
    WHEN OTHERS THEN
        RETURN '<html><body>'
            || '<h2 style="color:red;">Error Generating Report</h2>'
            || '<p>' || SQLERRM || '</p>'
            || '<pre>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || '</pre>'
            || '</body></html>';
END generate_ptw_general_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_HOTWORK_PDF" (
    p_permit_id       IN NUMBER,
    p_include_history IN VARCHAR2 DEFAULT 'N'
) RETURN CLOB
IS
    v_permit_number   ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_safety_ref      ptw_pro.ptw_lv_permits.safety_programme_ref_no%TYPE;
    v_fire_affected   ptw_pro.ptw_lv_permits.fire_systems_affected%TYPE;
    v_fire_isolated   ptw_pro.ptw_lv_permits.fire_systems_isolated%TYPE;
    v_insurer_dt      ptw_pro.ptw_lv_permits.insurer_informed_datetime%TYPE;
    v_iso_comments    ptw_pro.ptw_lv_permits.isolation_comments%TYPE;
    v_fire_precautions ptw_pro.ptw_lv_permits.fire_precautions_details%TYPE;
    v_fire_alarm      ptw_pro.ptw_lv_permits.fire_alarm_arrangements%TYPE;
    v_company_id      ptw_pro.ptw_lv_permits.company_id%TYPE;
    v_logo_b64        CLOB;
    v_html            CLOB;
BEGIN
    DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

    IF p_permit_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No Permit Selected</h2></div>';
    END IF;

    BEGIN
        SELECT permit_number, safety_programme_ref_no, fire_systems_affected,
               fire_systems_isolated, insurer_informed_datetime, isolation_comments,
               fire_precautions_details, fire_alarm_arrangements, company_id
        INTO   v_permit_number, v_safety_ref, v_fire_affected,
               v_fire_isolated, v_insurer_dt, v_iso_comments,
               v_fire_precautions, v_fire_alarm, v_company_id
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">Permit Not Found</h2>'
                || '<p>Permit ID: ' || p_permit_id || '</p></div>';
    END;

    v_logo_b64 := ptw_pro.ptw_pdf_lib_pkg.get_company_logo_b64(v_company_id);

    v_html := ptw_pro.ptw_pdf_lib_pkg.get_document_head(
        'Permit to Work Hot Work - ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number));

    -- ============================================================
    -- HEADER (Hot Work-specific: Safety Programme Ref + Permit No.
    -- only — no isolation diagram serial, that's LV-only)
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-header">
        <div style="display:flex;justify-content:space-between;
                    align-items:center;margin-bottom:8px;">
            <h1 style="margin:0;">Permit to Work &mdash; Hot Work</h1>';

    IF v_logo_b64 IS NOT NULL THEN
        v_html := v_html || '<img src="data:image/png;base64,';
        DBMS_LOB.APPEND(v_html, v_logo_b64);
        v_html := v_html || '" style="max-height:40px;margin-left:20px;" alt="Company Logo" />';
    END IF;

    v_html := v_html || '
        </div>
        <div class="header-refs">
            <div>Safety Programme Reference No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_safety_ref) || '</strong></div>
            <div>Permit to Work No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '</strong></div>
        </div>
    </div>';

    -- ============================================================
    -- SHARED: Site & Work Details — comes first, matching the real
    -- form's own top-to-bottom order (site/person/description/persons
    -- count rows come before the fire-system questions)
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_site_work_details_html(p_permit_id);

    -- ============================================================
    -- HOT WORK-SPECIFIC: Fire/smoke systems affected/isolated + insurer
    -- notified + isolation comments. Styled to match the shared section
    -- pattern (ptw-lv-section / ptw-lv-section-title) instead of an
    -- ad-hoc box, so it reads consistently with Site & Work Details and
    -- Control Measures rather than looking bolted on. Printed even when
    -- blank so the field's presence on the physical form is visible on
    -- the printed permit, not silently dropped.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Fire &amp; Smoke Systems</div>
        <div style="padding:8px 12px;">
            <strong>Will any fixed smoke/fire detection or suppression systems be affected
            by these works?</strong> ' || ptw_pro.ptw_pdf_lib_pkg.get_yn_label(v_fire_affected) || '
            &nbsp;&nbsp;<strong>If &lsquo;Yes&rsquo; have they been isolated or impeded?</strong> '
        || ptw_pro.ptw_pdf_lib_pkg.get_yn_label(v_fire_isolated) || '
            <br><strong>Date and time insuring company informed:</strong> '
        || ptw_pro.ptw_pdf_lib_pkg.fmt_datetime(v_insurer_dt) || '
            <br><strong>Comments relating to isolations:</strong> '
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_iso_comments) || '
        </div>
    </div>';

    -- ============================================================
    -- SHARED: Control Measures (the 9 numbered items)
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_control_measures_html(p_permit_id);

    -- ============================================================
    -- HOT WORK-SPECIFIC: the two isolation detail fields — these sit
    -- immediately AFTER the numbered Control Measures list on the real
    -- form, not grouped with the Yes/No questions above it. Same
    -- section styling as the box above, for consistency.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Fire &amp; Smoke System Isolation Details</div>
        <div style="padding:8px 12px;">
            <strong>Details of adequate fire precautions taken when smoke/fire detection
            and/or suppression systems have been isolated (fire extinguishers, blankets, etc.):</strong><br>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_fire_precautions) || '
            <br><br><strong>Details of adequate means of raising the fire alarm during the works
            and/or during the period when smoke/fire detection and/or suppression systems are
            inhibited:</strong><br>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_fire_alarm) || '
        </div>
    </div>';

    -- ============================================================
    -- HOT WORK-SPECIFIC: Fire watch log — reads the 6 milestone
    -- signatures from PTW_HOTWORK_FIRE_WATCH. Blank cells for
    -- anything not yet signed, matching the paper form's blank
    -- boxes rather than hiding rows that haven't happened yet.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Fire Watch Procedures</div>
        <table class="ptw-lv-table" style="font-size:8pt;">
            <thead><tr><th>Milestone</th><th>Signed By</th><th>Date/Time</th><th>Signature</th></tr></thead>
            <tbody>';

    FOR fw_row IN (
        SELECT m.label, fw.signed_by, fw.signed_datetime, fw.signature_blob
        FROM   (SELECT 1 seq, 'HW_COMPLETE' milestone_code, 'Hot Works Completed' label FROM dual UNION ALL
                SELECT 2, 'ATTEND_1ST_HR', '100% Attendance (1st Hour)' FROM dual UNION ALL
                SELECT 3, 'CHECK_15MIN_2ND_HR', 'Checked Every 15 Min (2nd Hour)' FROM dual UNION ALL
                SELECT 4, 'CHECK_30MIN_3RD_HR', 'Checked Every 30 Min (3rd Hour)' FROM dual UNION ALL
                SELECT 5, 'REINSTATE_4TH_HR', 'Reinstate Isolation (4th Hour)' FROM dual UNION ALL
                SELECT 6, 'FIRE_CHECKS_COMPLETE', 'Completion of Fire Checks' FROM dual) m
        LEFT JOIN ptw_pro.ptw_hotwork_fire_watch fw
               ON fw.permit_id = p_permit_id AND fw.milestone_code = m.milestone_code
        ORDER BY m.seq
    ) LOOP
        DBMS_LOB.APPEND(v_html, TO_CLOB(
            '<tr><td><strong style="color:#c0392b;">' || fw_row.label || '</strong></td><td>'
            || ptw_pro.ptw_pdf_lib_pkg.safe_val(fw_row.signed_by) || '</td><td>'
            || ptw_pro.ptw_pdf_lib_pkg.fmt_datetime(fw_row.signed_datetime) || '</td><td>'));
        DBMS_LOB.APPEND(v_html, TO_CLOB(ptw_pro.ptw_pdf_lib_pkg.get_signature_img(fw_row.signature_blob)));
        DBMS_LOB.APPEND(v_html, TO_CLOB('</td></tr>'));
    END LOOP;

    v_html := v_html || '
            </tbody>
        </table>
    </div>';
    -- ============================================================
    -- SHARED: PPE
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_ppe_html(p_permit_id);

    -- ============================================================
    -- HOT WORK HAS EQUIPMENT ISOLATION TOO (confirmed from the real
    -- form — same 4-row table as LV/WAH)
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_equipment_isolation_html(p_permit_id);

    -- ============================================================
    -- SHARED SECTIONS
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_authorisation_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_acceptance_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_clearance_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_cancellation_html(p_permit_id);

    -- ============================================================
    -- FOOTER (5-year retention — word-for-word from the source PDF)
    -- ============================================================
    v_html := v_html || '
    <div class="footer">
        During the works the Original copy shall be retained by the &lsquo;Authorised Person&rsquo;
        and the copy shall be retained by the &lsquo;Person in Charge&rsquo; of the work and must
        have it available at all times for inspection. On completion of the works, the copy must be
        returned and both parts are signed when cancelling this Permit. Retention period 5 years.
        <br>Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') ||
        ' &nbsp;|&nbsp; Permit: ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '
    </div>';

    -- ============================================================
    -- MONITORING PAGES — gated on PTW_TYPES.HAS_MONITORING, same
    -- pattern as General/WAH. Already 'Y' for Hot Work (type_id 96).
    -- ============================================================
    IF ptw_pro.ptw_pdf_lib_pkg.type_has_monitoring('HOT WORK') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_monitoring_pages_html(
            p_permit_id, 'Hotwork Monitoring');
    END IF;

    -- ============================================================
    -- STAGE HISTORY (shared, only when requested)
    -- ============================================================
    IF NVL(p_include_history, 'N') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_stage_history_html(p_permit_id);
    END IF;

    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_document_close;

    RETURN v_html;

EXCEPTION
    WHEN OTHERS THEN
        RETURN '<html><body>'
            || '<h2 style="color:red;">Error Generating Report</h2>'
            || '<p>' || SQLERRM || '</p>'
            || '<pre>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || '</pre>'
            || '</body></html>';
END generate_ptw_hotwork_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_LOA_PDF" (
    p_permit_id       IN NUMBER,
    p_include_history IN VARCHAR2 DEFAULT 'N'
) RETURN CLOB
IS
    v_permit_number   ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_company_id      ptw_pro.ptw_lv_permits.company_id%TYPE;
    v_client_perm     ptw_pro.ptw_lv_permits.client_permission_granted%TYPE;
    v_affects_it      ptw_pro.ptw_lv_permits.affects_it_systems%TYPE;
    v_it_perm         ptw_pro.ptw_lv_permits.it_permission_granted%TYPE;
    v_logo_b64        CLOB;
    v_html            CLOB;
    v_row_num         NUMBER := 0;
BEGIN
    DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

    IF p_permit_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No Permit Selected</h2></div>';
    END IF;

    BEGIN
        SELECT permit_number, company_id, client_permission_granted,
               affects_it_systems, it_permission_granted
        INTO   v_permit_number, v_company_id, v_client_perm,
               v_affects_it, v_it_perm
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">Permit Not Found</h2>'
                || '<p>Permit ID: ' || p_permit_id || '</p></div>';
    END;

    v_logo_b64 := ptw_pro.ptw_pdf_lib_pkg.get_company_logo_b64(v_company_id);

    v_html := ptw_pro.ptw_pdf_lib_pkg.get_document_head(
        'Limitation of Access - ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number),
        'LIMITATION OF ACCESS');

    -- ============================================================
    -- HEADER — navy banner (matches the source form's colour bar),
    -- permit number, then a genuinely prominent "NOT a Permit-to-Work"
    -- warning strip (bolder than the source's own small italic line,
    -- per your request), then the caution instruction line verbatim
    -- from the source form (previously missing entirely).
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-header" style="background:#789abd;color:#fff;">
        <div style="display:flex;justify-content:space-between;
                    align-items:center;margin-bottom:8px;">
            <h1 style="margin:0;color:#fff;">Limitation of Access &mdash; Electrical</h1>';

    IF v_logo_b64 IS NOT NULL THEN
        v_html := v_html || '<img src="data:image/png;base64,';
        DBMS_LOB.APPEND(v_html, v_logo_b64);
        v_html := v_html || '" style="max-height:40px;margin-left:20px;background:#fff;padding:3px 6px;border-radius:3px;" alt="Company Logo" />';
    END IF;

    v_html := v_html || '
        </div>
        <div class="header-refs" style="border-top:1px solid rgba(255,255,255,0.25);">
            <div style="color:#fff;">Limitation of Access No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '</strong></div>
        </div>
    </div>
    <div style="background:#e8b830;color:#1a1a1a;padding:7px 12px;
                font-weight:700;font-size:10.5pt;text-align:center;
                letter-spacing:0.4px;text-transform:uppercase;
                border-bottom:1px solid #c0c0c0;">
        &#9888; This is NOT a Permit-to-Work
    </div>
    <div style="padding:5px 12px;font-size:7.5pt;color:#555;
                border-bottom:1px solid #c0c0c0;">
        This LoA must be correctly authorised. On expiry, return all copies of this LoA
        to the LoA Issuer. Do not leave site until this LoA is cancelled.
    </div>';

    -- ============================================================
    -- SHARED: Site & Work Details
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_site_work_details_html(p_permit_id);

    -- ============================================================
    -- CLIENT PERMISSION — bespoke, self-contained. No shared
    -- ptw_pdf_lib_pkg function currently prints this for any type, so
    -- this is written directly rather than extending shared code.
    -- Wording matches Page 2's P2_CLIENT_PERMISSION_GRANTED /
    -- P2_AFFECTS_IT_SYSTEMS / P2_IT_PERMISSION_GRANTED labels exactly.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Client Permission</div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Has the client granted permission for these works to proceed?</div>
            <div class="ptw-lv-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_client_perm) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Will these works affect any IT or other business critical systems?</div>
            <div class="ptw-lv-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_affects_it) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">If &lsquo;Yes&rsquo;, has permission been granted to proceed?</div>
            <div class="ptw-lv-value">' || ptw_pro.ptw_pdf_lib_pkg.get_yn(v_it_perm) || '</div>
        </div>
    </div>';

    -- ============================================================
    -- CONTROL MEASURES — bespoke 2-column (Tick / N/A) table, matching
    -- the source form exactly. NOT ptw_pdf_lib_pkg.get_control_measures_html
    -- (which renders 3 columns: Yes/No/N/A) — that function is shared by
    -- every type, so it's left untouched; this type just doesn't call it.
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Control Measures which must be in place before issuing this Limitation of Access</div>
        <table class="ptw-lv-table">
            <thead>
                <tr>
                    <th class="cm-number">No.</th>
                    <th>Control Measure</th>
                    <th class="cm-tick">Tick, confirming compliance</th>
                    <th class="cm-tick">N/A</th>
                </tr>
            </thead>
            <tbody>';

    FOR cm_item IN (
        SELECT ci.item_seq, ci.question_text, cr.response
        FROM   ptw_pro.ptw_checklist_items ci
        JOIN   ptw_pro.ptw_lv_permits p ON p.permit_id = p_permit_id
        JOIN   ptw_pro.ptw_types t       ON t.ptw_type = p.ptw_type AND t.type_id = ci.type_id
        LEFT JOIN ptw_pro.ptw_checklist_responses cr
               ON cr.checklist_item_id = ci.checklist_item_id AND cr.permit_id = p_permit_id
        WHERE  ci.section_code = 'CONTROL_MEASURES'
        AND    ci.is_active = 'Y'
        ORDER BY ci.item_seq
    ) LOOP
        v_row_num := v_row_num + 1;
        DBMS_LOB.APPEND(v_html, TO_CLOB('
                <tr><td class="cm-number">' || v_row_num || '</td>
                    <td>' || ptw_pro.ptw_pdf_lib_pkg.safe_val(cm_item.question_text) || '</td>
                    <td class="cm-tick">' || ptw_pro.ptw_pdf_lib_pkg.get_cm_tick(cm_item.response) || '</td>
                    <td class="cm-tick">' || ptw_pro.ptw_pdf_lib_pkg.get_cm_na(cm_item.response)   || '</td></tr>'));
    END LOOP;

    v_html := v_html || '
            </tbody>
        </table>
    </div>';

    -- ============================================================
    -- SHARED: PPE, Equipment Isolation
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_ppe_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_equipment_isolation_html(p_permit_id);

    -- ============================================================
    -- SHARED: Authorisation / Acceptance / Clearance / Cancellation —
    -- LIMITATION OF ACCESS wording branches already added to
    -- ptw_pdf_lib_pkg (previous fix).
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_authorisation_html(p_permit_id, 'LIMITATION OF ACCESS');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_acceptance_html(p_permit_id, 'LIMITATION OF ACCESS');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_clearance_html(p_permit_id, 'LIMITATION OF ACCESS');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_cancellation_html(p_permit_id, 'LIMITATION OF ACCESS');

    -- ============================================================
    -- FOOTER — 5-year retention text, word-for-word from source PDF
    -- ============================================================
    v_html := v_html || '
    <div class="footer">
        During the works the Original copy shall be retained by the &lsquo;Authorised Person&rsquo;
        and the copy shall be retained by the &lsquo;Person in Charge&rsquo; of the work and must
        have it available at all times for inspection. On completion of the works, the copy must be
        returned and both parts are signed when cancelling this Limitation Document. Retention period 5 years.
        <br>Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') ||
        ' &nbsp;|&nbsp; Limitation of Access: ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '
    </div>';

    IF ptw_pro.ptw_pdf_lib_pkg.type_has_monitoring('LIMITATION OF ACCESS') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_monitoring_pages_html(
            p_permit_id, 'Limitation of Access Monitoring');
    END IF;

    IF NVL(p_include_history, 'N') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_stage_history_html(p_permit_id);
    END IF;

    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_document_close;

    RETURN v_html;

EXCEPTION
    WHEN OTHERS THEN
        RETURN '<html><body>'
            || '<h2 style="color:red;">Error Generating Report</h2>'
            || '<p>' || SQLERRM || '</p>'
            || '<pre>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || '</pre>'
            || '</body></html>';
END generate_ptw_loa_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_LV_PDF" (
    p_permit_id       IN NUMBER,
    p_include_history IN VARCHAR2 DEFAULT 'N'
) RETURN CLOB
IS
    v_permit_number ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_safety_ref    ptw_pro.ptw_lv_permits.safety_programme_ref_no%TYPE;
    v_iso_serial    ptw_pro.ptw_lv_permits.isolation_diagram_serial_no%TYPE;
    v_company_id    ptw_pro.ptw_lv_permits.company_id%TYPE;
    v_logo_b64      CLOB;
    v_html          CLOB;
BEGIN
    DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

    IF p_permit_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No Permit Selected</h2></div>';
    END IF;

    BEGIN
        SELECT permit_number, safety_programme_ref_no, isolation_diagram_serial_no, company_id
        INTO   v_permit_number, v_safety_ref, v_iso_serial, v_company_id
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">Permit Not Found</h2>'
                || '<p>Permit ID: ' || p_permit_id || '</p></div>';
    END;

    v_logo_b64 := ptw_pro.ptw_pdf_lib_pkg.get_company_logo_b64(v_company_id);

    v_html := ptw_pro.ptw_pdf_lib_pkg.get_document_head(
        'Permit to Work LV-Electrical - ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number));

    -- ============================================================
    -- HEADER (LV-specific: includes Isolation & Earthing ref)
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-header">
        <div style="display:flex;justify-content:space-between;
                    align-items:center;margin-bottom:8px;">
            <h1 style="margin:0;">Permit to Work &mdash; LV Electrical</h1>';

    IF v_logo_b64 IS NOT NULL THEN
        v_html := v_html || '<img src="data:image/png;base64,';
        DBMS_LOB.APPEND(v_html, v_logo_b64);
        v_html := v_html || '" style="max-height:40px;margin-left:20px;" alt="Company Logo" />';
    END IF;

    v_html := v_html || '
        </div>
        <div class="header-refs">
            <div>Safety Programme Reference No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_safety_ref) || '</strong></div>
            <div>Isolation &amp; Earthing Diagram Serial No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_iso_serial) || '</strong></div>
            <div>Permit to Work No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '</strong></div>
        </div>
    </div>';

    -- ============================================================
    -- SHARED SECTIONS
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_site_work_details_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_control_measures_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_ppe_html(p_permit_id);

    -- ============================================================
    -- LV-SPECIFIC: Equipment Isolation
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_equipment_isolation_html(p_permit_id);

    -- ============================================================
    -- SHARED SECTIONS
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_authorisation_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_acceptance_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_clearance_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_cancellation_html(p_permit_id);

    -- ============================================================
    -- FOOTER (LV-specific: 5-year retention wording)
    -- ============================================================
    v_html := v_html || '
    <div class="footer">
        During the works the Original copy shall be retained by the &lsquo;Authorised Person&rsquo;
        and the copy shall be retained by the &lsquo;Person in Charge&rsquo; of the work and must
        have it available at all times for inspection. On completion of the works, the copy must be
        returned and both parts are signed when cancelling this Permit. Retention period 5 years.
        <br>Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') ||
        ' &nbsp;|&nbsp; Permit: ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '
    </div>';

    -- ============================================================
    -- MONITORING PAGES (shared, LV-flavoured heading)
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_monitoring_pages_html(
        p_permit_id, 'Low Voltage Monitoring');

    -- ============================================================
    -- STAGE HISTORY (shared, only when requested)
    -- ============================================================
    IF NVL(p_include_history, 'N') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_stage_history_html(p_permit_id);
    END IF;

    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_document_close;

    RETURN v_html;

EXCEPTION
    WHEN OTHERS THEN
        RETURN '<html><body>'
            || '<h2 style="color:red;">Error Generating Report</h2>'
            || '<p>' || SQLERRM || '</p>'
            || '<pre>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || '</pre>'
            || '</body></html>';
END generate_ptw_lv_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_PERMIT_PDF" (
    p_permit_id       IN NUMBER,
    p_include_history IN VARCHAR2 DEFAULT 'N'
) RETURN CLOB
IS
    v_ptw_type ptw_pro.ptw_lv_permits.ptw_type%TYPE;
BEGIN
    IF p_permit_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No Permit Selected</h2></div>';
    END IF;

    BEGIN
        SELECT ptw_type INTO v_ptw_type
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">Permit Not Found</h2>'
                || '<p>Permit ID: ' || p_permit_id || '</p></div>';
    END;

    CASE v_ptw_type
        WHEN 'LV ISOLATION' THEN
            RETURN ptw_pro.generate_ptw_lv_pdf(p_permit_id, p_include_history);
        WHEN 'GENERAL' THEN
            RETURN ptw_pro.generate_ptw_general_pdf(p_permit_id, p_include_history);
        WHEN 'WORKING AT HEIGHT' THEN
            RETURN ptw_pro.generate_ptw_wah_pdf(p_permit_id, p_include_history);
        WHEN 'HOT WORK' THEN
            RETURN ptw_pro.generate_ptw_hotwork_pdf(p_permit_id, p_include_history);
        WHEN 'LIMITATION OF ACCESS' THEN
            RETURN ptw_pro.generate_ptw_loa_pdf(p_permit_id, p_include_history);
        WHEN 'FIRE SYSTEMS ISOLATION' THEN
            RETURN ptw_pro.generate_ptw_fireisolation_pdf(p_permit_id, p_include_history);
        ELSE
            RETURN '<div class="ptw-lv-report-container">'
                || '<h2 style="color:red;">No PDF template defined for permit type: '
                || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_ptw_type) || '</h2></div>';
    END CASE;
END generate_ptw_permit_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."GENERATE_PTW_WAH_PDF" (
    p_permit_id       IN NUMBER,
    p_include_history IN VARCHAR2 DEFAULT 'N'
) RETURN CLOB
IS
    v_permit_number ptw_pro.ptw_lv_permits.permit_number%TYPE;
    v_specialist_eq ptw_pro.ptw_lv_permits.specialist_equipment_details%TYPE;
    v_company_id    ptw_pro.ptw_lv_permits.company_id%TYPE;
    v_logo_b64      CLOB;
    v_html          CLOB;
BEGIN
    DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

    IF p_permit_id IS NULL THEN
        RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">No Permit Selected</h2></div>';
    END IF;

    BEGIN
        SELECT permit_number, specialist_equipment_details, company_id
        INTO   v_permit_number, v_specialist_eq, v_company_id
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '<div class="ptw-lv-report-container"><h2 style="color:red;">Permit Not Found</h2>'
                || '<p>Permit ID: ' || p_permit_id || '</p></div>';
    END;

    v_logo_b64 := ptw_pro.ptw_pdf_lib_pkg.get_company_logo_b64(v_company_id);

    v_html := ptw_pro.ptw_pdf_lib_pkg.get_document_head(
        'Permit to Work Working at Height - ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number), 'WORKING AT HEIGHT');

    -- ============================================================
    -- HEADER (WAH-specific: no Safety Programme Ref, no Isolation
    -- Diagram Serial - neither field exists on this form. Only
    -- the Permit No. reference, matching what the real form
    -- actually shows.)
    -- ============================================================
    v_html := v_html || '
    <div class="ptw-lv-header">
        <div style="display:flex;justify-content:space-between;
                    align-items:center;margin-bottom:8px;">
            <h1 style="margin:0;">Permit to Work &mdash; Working at Height</h1>';

    IF v_logo_b64 IS NOT NULL THEN
        v_html := v_html || '<img src="data:image/png;base64,';
        DBMS_LOB.APPEND(v_html, v_logo_b64);
        v_html := v_html || '" style="max-height:40px;margin-left:20px;" alt="Company Logo" />';
    END IF;

    v_html := v_html || '
        </div>
        <div class="header-refs">
            <div>Permit to Work No.:<br><strong>'
        || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '</strong></div>
        </div>
    </div>';

    -- ============================================================
    -- SHARED SECTIONS
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_site_work_details_html(p_permit_id);

    -- ============================================================
    -- WAH-SPECIFIC: Specialist Equipment (no equivalent on LV or
    -- General - printed as its own paragraph, not crammed into
    -- the short-reference header-refs box above, since it is
    -- free-text and can run to a few sentences). Position matches
    -- the real form: after Site & Work Details, before Control
    -- Measures - not before Site & Work Details as originally
    -- placed.
    -- ============================================================
    IF v_specialist_eq IS NOT NULL THEN
        v_html := v_html || '
        <div class="section" style="margin:10px 0;padding:10px 15px;
                    border:1px solid #e0e0e0;border-radius:4px;background:#f8f9fa;">
            <strong>Details of Specialist Equipment / Dedicated Access Required
            (Cradle, generator, etc.):</strong><br>'
            || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_specialist_eq) || '
        </div>';
    END IF;

    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_control_measures_html(p_permit_id);
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_ppe_html(p_permit_id);

    -- ============================================================
    -- WAH HAS EQUIPMENT ISOLATION TOO (confirmed from the real
    -- form - same 4-row table as LV, not General-style absence)
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_equipment_isolation_html(p_permit_id);

    -- ============================================================
    -- SHARED SECTIONS
    -- ============================================================
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_authorisation_html(p_permit_id, 'WORKING AT HEIGHT');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_acceptance_html(p_permit_id, 'WORKING AT HEIGHT');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_clearance_html(p_permit_id, 'WORKING AT HEIGHT');
    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_cancellation_html(p_permit_id, 'WORKING AT HEIGHT');

    -- ============================================================
    -- FOOTER (5-year retention - confirmed word-for-word match to
    -- LV's wording, independently verified against the real WAH
    -- PDF, not assumed)
    -- ============================================================
    v_html := v_html || '
    <div class="footer">
        During the works the Original copy shall be retained by the &lsquo;Authorised Person&rsquo;
        and the copy shall be retained by the &lsquo;Person in Charge&rsquo; of the work and must
        have it available at all times for inspection. On completion of the works, the copy must be
        returned and both parts are signed when cancelling this Permit. Retention period 5 years.
        <br>Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') ||
        ' &nbsp;|&nbsp; Permit: ' || ptw_pro.ptw_pdf_lib_pkg.safe_val(v_permit_number) || '
    </div>';

    -- ============================================================
    -- MONITORING PAGES (shared, WAH-flavoured heading - WAH has
    -- monitoring per Phase 3's ptw_type_sections seed). Gated on
    -- PTW_TYPES.HAS_MONITORING for consistency with General/LV, even
    -- though WAH's real form confirms this should currently be Y.
    -- ============================================================
    IF ptw_pro.ptw_pdf_lib_pkg.type_has_monitoring('WORKING AT HEIGHT') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_monitoring_pages_html(
            p_permit_id, 'Working at Height Monitoring');
    END IF;

    -- ============================================================
    -- STAGE HISTORY (shared, only when requested)
    -- ============================================================
    IF NVL(p_include_history, 'N') = 'Y' THEN
        v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_stage_history_html(p_permit_id);
    END IF;

    v_html := v_html || ptw_pro.ptw_pdf_lib_pkg.get_document_close;

    RETURN v_html;

EXCEPTION
    WHEN OTHERS THEN
        RETURN '<html><body>'
            || '<h2 style="color:red;">Error Generating Report</h2>'
            || '<p>' || SQLERRM || '</p>'
            || '<pre>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || '</pre>'
            || '</body></html>';
END generate_ptw_wah_pdf;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."PTW_LV_IS_CONTRACT_SUPPORT"
    (p_username IN VARCHAR2)
RETURN VARCHAR2
IS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO   v_count
    FROM   ptw_pro.ptw_lv_user_roles_v        -- view handles both active flags
    WHERE  UPPER(username) = UPPER(p_username)
    AND    role_name       = 'ADMIN_CONTRACT_SUPPORT'
    AND    is_active       = 'Y';              -- combined effective flag from view

    RETURN CASE WHEN v_count > 0 THEN 'Y' ELSE 'N' END;
EXCEPTION
    WHEN OTHERS THEN RETURN 'N';
END ptw_lv_is_contract_support;
/

CREATE OR REPLACE EDITIONABLE FUNCTION "PTW_PRO"."PTW_LV_PERMIT_VISIBLE" (
    p_permit_id        IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
    p_created_by       IN ptw_pro.ptw_lv_permits.created_by%TYPE,
    p_auth_person_name IN ptw_pro.ptw_lv_permits.auth_person_name%TYPE,
    p_username         IN VARCHAR2
) RETURN VARCHAR2 -- 'Y' or 'N'
IS
    v_is_admin      NUMBER;
    v_is_engineer   NUMBER;
    v_is_authoriser NUMBER;
BEGIN
    -- NOTE: No company_id check here. VPD on ptw_lv_permits guarantees that
    -- p_permit_id (and therefore p_created_by / p_auth_person_name as read
    -- from that row) already belongs to the caller's company, or the caller
    -- is a super user / workspace admin who bypasses VPD entirely.
    -- This function therefore only needs to answer: "within the rows this
    -- user is already permitted to see, does their ROLE entitle them to
    -- see THIS row?"

    SELECT
        SUM(CASE WHEN role_name IN ('ADMIN','ADMIN_USER_SUPPORT',
                                    'ADMIN_CONTRACT_SUPPORT','READONLY')
                 THEN 1 ELSE 0 END),
        SUM(CASE WHEN role_name = 'ENGINEER'   THEN 1 ELSE 0 END),
        SUM(CASE WHEN role_name = 'AUTHORISER' THEN 1 ELSE 0 END)
    INTO v_is_admin, v_is_engineer, v_is_authoriser
    FROM ptw_pro.ptw_lv_user_roles_v
    WHERE UPPER(username) = UPPER(p_username)
    AND   is_active = 'Y';

    -- Admin-class (company admin) or super user: see all (within company,
    -- enforced by VPD already)
    IF v_is_admin > 0 THEN RETURN 'Y'; END IF;

    -- Engineer only: own created
    IF v_is_engineer > 0 AND v_is_authoriser = 0 THEN
        RETURN CASE WHEN UPPER(p_created_by) = UPPER(p_username)
                    THEN 'Y' ELSE 'N' END;
    END IF;

    -- Authoriser only: own authorised
    IF v_is_authoriser > 0 AND v_is_engineer = 0 THEN
        RETURN CASE WHEN UPPER(p_auth_person_name) = UPPER(p_username)
                    THEN 'Y' ELSE 'N' END;
    END IF;

    -- Engineer + Authoriser: created OR authorised
    IF v_is_engineer > 0 AND v_is_authoriser > 0 THEN
        RETURN CASE WHEN UPPER(p_created_by)        = UPPER(p_username)
                      OR UPPER(p_auth_person_name)  = UPPER(p_username)
                    THEN 'Y' ELSE 'N' END;
    END IF;

    RETURN 'N';
EXCEPTION
    WHEN OTHERS THEN RETURN 'N';
END ptw_lv_permit_visible;
/
