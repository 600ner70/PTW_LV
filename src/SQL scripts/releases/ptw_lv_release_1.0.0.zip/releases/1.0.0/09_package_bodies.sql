--------------------------------------------------------------------------------
-- PTW LV release 1.0.0 : Package bodies
-- Run as      : PTW_PRO
-- Generated   : 2026-11-22 13:55 UTC by releases/build_release.py
--------------------------------------------------------------------------------

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_ATW_PKG" AS

    ---------------------------------------------------------------------------
    -- Private types / helpers
    ---------------------------------------------------------------------------
    -- NOTE: private functions (app_user, yn, user_full_name, ...) cannot be
    -- called inside SQL statements (PLS-00231). Every SQL statement below
    -- uses local variables computed beforehand.
    SUBTYPE t_atw IS ptw_pro.ptw_lv_atw%ROWTYPE;

    c_live_statuses CONSTANT VARCHAR2(100) := ':ISSUED:ON_SITE:CHECKED_OUT:';

    FUNCTION app_user RETURN VARCHAR2 IS
    BEGIN
        RETURN UPPER(NVL(V('APP_USER'), USER));
    END app_user;

    FUNCTION is_live (p_status IN VARCHAR2) RETURN BOOLEAN IS
    BEGIN
        RETURN INSTR(c_live_statuses, ':' || p_status || ':') > 0;
    END is_live;

    FUNCTION has_any_role (
        p_username IN VARCHAR2,
        p_roles    IN apex_t_varchar2
    ) RETURN VARCHAR2 IS
        l_count NUMBER;
    BEGIN
        IF p_username IS NULL THEN
            RETURN 'N';
        END IF;
        SELECT COUNT(*)
        INTO   l_count
        FROM   ptw_pro.ptw_lv_user_roles_v
        WHERE  UPPER(username) = UPPER(p_username)
        AND    role_name IN (SELECT column_value FROM TABLE(p_roles))
        AND    is_active = 'Y';
        RETURN CASE WHEN l_count > 0 THEN 'Y' ELSE 'N' END;
    END has_any_role;

    FUNCTION user_full_name (p_username IN VARCHAR2) RETURN VARCHAR2 IS
        l_name VARCHAR2(201);
    BEGIN
        SELECT TRIM(first_name || ' ' || last_name)
        INTO   l_name
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(p_username);
        RETURN NVL(l_name, p_username);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN p_username;
    END user_full_name;

    FUNCTION holder_username (p_user_id IN NUMBER) RETURN VARCHAR2 IS
        l_username ptw_pro.ptw_lv_users.username%TYPE;
    BEGIN
        SELECT UPPER(username) INTO l_username
        FROM   ptw_pro.ptw_lv_users
        WHERE  user_id = p_user_id;
        RETURN l_username;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN NULL;
    END holder_username;

    -- Lock and return the ATW. VPD hides other companies' (and, for
    -- contractors, other holders') rows, so "not found" covers both.
    FUNCTION get_for_update (p_atw_id IN ptw_pro.ptw_lv_atw.atw_id%TYPE) RETURN t_atw IS
        l_row t_atw;
    BEGIN
        SELECT *
        INTO   l_row
        FROM   ptw_pro.ptw_lv_atw
        WHERE  atw_id = p_atw_id
        FOR UPDATE;
        RETURN l_row;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20204,
                'Authority to Work ' || p_atw_id || ' not found or not accessible.');
    END get_for_update;

    PROCEDURE log_event (
        p_atw_id     IN NUMBER,
        p_event_type IN VARCHAR2,
        p_on_behalf  IN VARCHAR2 DEFAULT 'N',
        p_latitude   IN NUMBER   DEFAULT NULL,
        p_longitude  IN NUMBER   DEFAULT NULL,
        p_notes      IN VARCHAR2 DEFAULT NULL
    ) IS
        l_now DATE          := local_now;
        l_by  VARCHAR2(255) := app_user;
    BEGIN
        INSERT INTO ptw_pro.ptw_lv_atw_events
            (atw_id, event_type, event_datetime, event_by, on_behalf,
             latitude, longitude, notes)
        VALUES
            (p_atw_id, p_event_type, l_now, l_by, NVL(p_on_behalf, 'N'),
             p_latitude, p_longitude, SUBSTR(p_notes, 1, 1000));
    END log_event;

    -- Same behaviour as ptw_auth_workflow_pkg.notify: never blocks the workflow.
    PROCEDURE notify (
        p_username IN VARCHAR2,
        p_title    IN VARCHAR2,
        p_body     IN VARCHAR2
    ) IS
    BEGIN
        IF p_username IS NULL THEN
            RETURN;
        END IF;
        apex_pwa.send_push_notification(
            p_application_id => NVL(TO_NUMBER(V('APP_ID')), 105),
            p_user_name      => p_username,
            p_title          => p_title,
            p_body           => p_body
        );
    EXCEPTION
        WHEN OTHERS THEN
            apex_debug.warn('ptw_atw_pkg.notify failed for %s: %s', p_username, SQLERRM);
    END notify;

    PROCEDURE assert_issuer IS
    BEGIN
        IF is_issuer(app_user) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20203,
                'You do not have permission to issue or change an Authority to Work.');
        END IF;
    END assert_issuer;

    -- Holder must be an active CONTRACTOR in the caller's effective company,
    -- and must not be the issuer. Returns the user row for the snapshot.
    FUNCTION get_valid_holder (p_holder_user_id IN NUMBER) RETURN ptw_pro.ptw_lv_users%ROWTYPE IS
        l_user ptw_pro.ptw_lv_users%ROWTYPE;
    BEGIN
        IF p_holder_user_id IS NULL THEN
            RAISE_APPLICATION_ERROR(-20205, 'Select the contractor this Authority to Work is for.');
        END IF;

        BEGIN
            SELECT * INTO l_user
            FROM   ptw_pro.ptw_lv_users
            WHERE  user_id   = p_holder_user_id
            AND    is_active = 'Y'
            AND    company_id = ptw_pro.ptw_sec_pkg.get_effective_company_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20205,
                    'The selected contractor is not an active user in this company.');
        END;

        IF is_contractor(l_user.username) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20205,
                'The selected user does not have the CONTRACTOR role.');
        END IF;
        IF UPPER(l_user.username) = app_user THEN
            RAISE_APPLICATION_ERROR(-20206, 'You cannot issue an Authority to Work to yourself.');
        END IF;
        IF TRIM(l_user.employer_name) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20207,
                'Record the contractor''s employer on their user profile before issuing.');
        END IF;
        RETURN l_user;
    END get_valid_holder;

    PROCEDURE assert_site (p_site_id IN NUMBER) IS
        l_count NUMBER;
    BEGIN
        -- PTW_LV_SITES is VPD-protected: only the caller's company's sites match.
        SELECT COUNT(*) INTO l_count
        FROM   ptw_pro.ptw_lv_sites
        WHERE  site_id   = p_site_id
        AND    is_active = 'Y';
        IF l_count = 0 THEN
            RAISE_APPLICATION_ERROR(-20209, 'Select an active site.');
        END IF;
    END assert_site;

    FUNCTION yn (p_val IN VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE WHEN UPPER(p_val) = 'Y' THEN 'Y' ELSE 'N' END;
    END yn;

    FUNCTION fmt_date (p_date IN DATE) RETURN VARCHAR2 IS
    BEGIN
        RETURN TO_CHAR(p_date, 'DD-MON-YYYY');
    END fmt_date;

    FUNCTION fmt_time (p_date IN DATE) RETURN VARCHAR2 IS
    BEGIN
        RETURN TO_CHAR(p_date, 'HH24:MI');
    END fmt_time;

    -- Internal check-in used by check_in and issue_atw(p_check_in_now => 'Y').
    PROCEDURE do_check_in (
        p_row        IN t_atw,
        p_on_behalf  IN VARCHAR2,
        p_latitude   IN NUMBER,
        p_longitude  IN NUMBER
    ) IS
        l_now DATE := local_now;
    BEGIN
        UPDATE ptw_pro.ptw_lv_atw
        SET    status             = 'ON_SITE',
               check_in_datetime  = l_now,
               check_out_datetime = NULL
        WHERE  atw_id = p_row.atw_id;

        log_event(p_row.atw_id, 'CHECK_IN', p_on_behalf, p_latitude, p_longitude);
    END do_check_in;


    ---------------------------------------------------------------------------
    -- Public: time
    ---------------------------------------------------------------------------
    FUNCTION local_now RETURN DATE IS
    BEGIN
        RETURN CAST(SYSTIMESTAMP AT TIME ZONE c_tz AS DATE);
    END local_now;

    FUNCTION local_today RETURN DATE IS
    BEGIN
        RETURN TRUNC(local_now);
    END local_today;


    ---------------------------------------------------------------------------
    -- Public: roles
    ---------------------------------------------------------------------------
    FUNCTION is_issuer (p_username IN VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN has_any_role(p_username, apex_t_varchar2('ADMIN', 'AUTHORISER', 'ATW_ISSUER'));
    END is_issuer;

    FUNCTION is_contractor (p_username IN VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN has_any_role(p_username, apex_t_varchar2('CONTRACTOR'));
    END is_contractor;

    FUNCTION can_verify (p_username IN VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN has_any_role(p_username,
                            apex_t_varchar2('ADMIN', 'AUTHORISER', 'ATW_ISSUER', 'SECURITY'));
    END can_verify;

    FUNCTION effective_status (
        p_status     IN ptw_pro.ptw_lv_atw.status%TYPE,
        p_valid_date IN ptw_pro.ptw_lv_atw.valid_date%TYPE
    ) RETURN VARCHAR2 IS
    BEGIN
        IF is_live(p_status) AND p_valid_date < local_today THEN
            RETURN 'EXPIRED';
        END IF;
        RETURN p_status;
    END effective_status;


    ---------------------------------------------------------------------------
    -- Public: issuer actions
    ---------------------------------------------------------------------------
    PROCEDURE save_draft (
        p_atw_id            IN OUT ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_site_id           IN     ptw_pro.ptw_lv_atw.site_id%TYPE,
        p_holder_user_id    IN     ptw_pro.ptw_lv_atw.holder_user_id%TYPE,
        p_work_description  IN     ptw_pro.ptw_lv_atw.work_description%TYPE,
        p_rams_reference    IN     ptw_pro.ptw_lv_atw.rams_reference%TYPE,
        p_induction_ok      IN     ptw_pro.ptw_lv_atw.induction_ok%TYPE,
        p_ssow_ok           IN     ptw_pro.ptw_lv_atw.ssow_ok%TYPE,
        p_competence_ok     IN     ptw_pro.ptw_lv_atw.competence_ok%TYPE,
        p_equipment_ppe_ok  IN     ptw_pro.ptw_lv_atw.equipment_ppe_ok%TYPE,
        p_issuer_notes      IN     ptw_pro.ptw_lv_atw.issuer_notes%TYPE
    ) IS
        l_today  DATE        := local_today;
        l_ind    VARCHAR2(1) := yn(p_induction_ok);
        l_ssow   VARCHAR2(1) := yn(p_ssow_ok);
        l_comp   VARCHAR2(1) := yn(p_competence_ok);
        l_ppe    VARCHAR2(1) := yn(p_equipment_ppe_ok);
        l_holder ptw_pro.ptw_lv_users%ROWTYPE;
        l_row    t_atw;
    BEGIN
        assert_issuer;
        assert_site(p_site_id);
        l_holder := get_valid_holder(p_holder_user_id);

        IF p_atw_id IS NULL THEN
            INSERT INTO ptw_pro.ptw_lv_atw (
                site_id, holder_user_id, holder_name, holder_employer, holder_mobile,
                valid_date, work_description, rams_reference,
                induction_ok, ssow_ok, competence_ok, equipment_ppe_ok,
                issuer_notes, status
            ) VALUES (
                p_site_id, l_holder.user_id,
                TRIM(l_holder.first_name || ' ' || l_holder.last_name),
                TRIM(l_holder.employer_name), l_holder.mobile_no,
                l_today, TRIM(p_work_description), TRIM(p_rams_reference),
                l_ind, l_ssow, l_comp, l_ppe,
                TRIM(p_issuer_notes), 'DRAFT'
            )
            RETURNING atw_id INTO p_atw_id;

            log_event(p_atw_id, 'CREATED');
        ELSE
            l_row := get_for_update(p_atw_id);

            IF l_row.status NOT IN ('DRAFT', 'REQUESTED') THEN
                RAISE_APPLICATION_ERROR(-20210,
                    'This Authority to Work is ' || l_row.status || ' and can no longer be edited.');
            END IF;
            IF l_row.valid_date <> l_today THEN
                RAISE_APPLICATION_ERROR(-20211,
                    'This Authority to Work was for ' || fmt_date(l_row.valid_date)
                    || '. Cancel it and start a new one for today.');
            END IF;
            IF l_row.status = 'REQUESTED' AND l_row.holder_user_id <> p_holder_user_id THEN
                RAISE_APPLICATION_ERROR(-20205,
                    'A contractor''s request cannot be moved to a different person.');
            END IF;

            UPDATE ptw_pro.ptw_lv_atw
            SET    site_id          = p_site_id,
                   holder_user_id   = l_holder.user_id,
                   holder_name      = TRIM(l_holder.first_name || ' ' || l_holder.last_name),
                   holder_employer  = TRIM(l_holder.employer_name),
                   holder_mobile    = l_holder.mobile_no,
                   work_description = TRIM(p_work_description),
                   rams_reference   = TRIM(p_rams_reference),
                   induction_ok     = l_ind,
                   ssow_ok          = l_ssow,
                   competence_ok    = l_comp,
                   equipment_ppe_ok = l_ppe,
                   issuer_notes     = TRIM(p_issuer_notes)
            WHERE  atw_id = p_atw_id;

            log_event(p_atw_id, 'UPDATED');
        END IF;

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            RAISE_APPLICATION_ERROR(-20208,
                l_holder.first_name || ' ' || l_holder.last_name
                || ' already has an Authority to Work for today. Open it from the ATW register instead.');
    END save_draft;


    PROCEDURE issue_atw (
        p_atw_id          IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_issuer_sig_b64  IN CLOB,
        p_latitude        IN NUMBER   DEFAULT NULL,
        p_longitude       IN NUMBER   DEFAULT NULL,
        p_check_in_now    IN VARCHAR2 DEFAULT 'N'
    ) IS
        l_user     VARCHAR2(255) := app_user;
        l_now      DATE          := local_now;
        l_name     VARCHAR2(201);
        l_token    ptw_pro.ptw_lv_atw.verify_token%TYPE;
        l_row      t_atw;
        l_holder   ptw_pro.ptw_lv_users%ROWTYPE;
        l_missing  VARCHAR2(400);
        l_number   ptw_pro.ptw_lv_atw.atw_number%TYPE;
        l_site     ptw_pro.ptw_lv_sites.site_name%TYPE;
    BEGIN
        assert_issuer;
        l_row := get_for_update(p_atw_id);

        IF l_row.status NOT IN ('DRAFT', 'REQUESTED') THEN
            RAISE_APPLICATION_ERROR(-20210,
                'This Authority to Work is ' || l_row.status || ' and cannot be issued.');
        END IF;
        IF l_row.valid_date <> local_today THEN
            RAISE_APPLICATION_ERROR(-20211,
                'This Authority to Work was for ' || fmt_date(l_row.valid_date)
                || '. An ATW can only be issued on the day it is valid.');
        END IF;

        IF l_row.induction_ok     = 'N' THEN l_missing := l_missing || ', Site induction';        END IF;
        IF l_row.ssow_ok          = 'N' THEN l_missing := l_missing || ', Safe system of work';   END IF;
        IF l_row.competence_ok    = 'N' THEN l_missing := l_missing || ', Competence';            END IF;
        IF l_row.equipment_ppe_ok = 'N' THEN l_missing := l_missing || ', Equipment and PPE';     END IF;
        IF l_missing IS NOT NULL THEN
            RAISE_APPLICATION_ERROR(-20212,
                'All four checks must be confirmed before issuing. Outstanding: '
                || LTRIM(l_missing, ', ') || '.');
        END IF;

        IF p_issuer_sig_b64 IS NULL OR DBMS_LOB.GETLENGTH(p_issuer_sig_b64) = 0 THEN
            RAISE_APPLICATION_ERROR(-20213, 'Your signature is required to issue.');
        END IF;

        -- Re-validate the holder at the moment of issue (role / active /
        -- employer may have changed since the draft was saved).
        l_holder := get_valid_holder(l_row.holder_user_id);
        l_name   := user_full_name(l_user);
        l_token  := LOWER(RAWTOHEX(SYS.DBMS_CRYPTO.RANDOMBYTES(16)));

        UPDATE ptw_pro.ptw_lv_atw
        SET    status           = 'ISSUED',
               holder_name      = TRIM(l_holder.first_name || ' ' || l_holder.last_name),
               holder_employer  = TRIM(l_holder.employer_name),
               holder_mobile    = l_holder.mobile_no,
               issued_by        = l_user,
               issuer_name      = l_name,
               issued_datetime  = l_now,
               issuer_signature = apex_web_service.clobbase642blob(
                                      REGEXP_REPLACE(p_issuer_sig_b64, '^data:image/[^;]+;base64,', '')),
               issue_latitude   = p_latitude,
               issue_longitude  = p_longitude,
               verify_token     = l_token
        WHERE  atw_id = p_atw_id
        RETURNING atw_number INTO l_number;

        log_event(p_atw_id, 'ISSUED', 'N', p_latitude, p_longitude);

        IF UPPER(p_check_in_now) = 'Y' THEN
            l_row.status := 'ISSUED';
            do_check_in(l_row, 'Y', p_latitude, p_longitude);
        END IF;

        SELECT site_name INTO l_site
        FROM   ptw_pro.ptw_lv_sites
        WHERE  site_id = l_row.site_id;

        notify(
            p_username => UPPER(l_holder.username),
            p_title    => 'Authority to Work issued',
            p_body     => 'Your Authority to Work ' || l_number || ' for ' || l_site
                          || ' is valid today (' || fmt_date(l_row.valid_date) || '). '
                          || 'Open PTW-PRO to show your pass'
                          || CASE WHEN UPPER(p_check_in_now) = 'Y' THEN '.' ELSE ' and check in.' END
        );

    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE BETWEEN -20239 AND -20200 THEN
                RAISE;
            END IF;
            RAISE_APPLICATION_ERROR(-20214, 'Error issuing Authority to Work: ' || SQLERRM);
    END issue_atw;


    PROCEDURE revoke_atw (
        p_atw_id  IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_reason  IN ptw_pro.ptw_lv_atw.revoke_reason%TYPE
    ) IS
        l_row  t_atw;
        l_user VARCHAR2(255) := app_user;
        l_now  DATE          := local_now;
    BEGIN
        assert_issuer;
        l_row := get_for_update(p_atw_id);

        IF NOT is_live(l_row.status) THEN
            RAISE_APPLICATION_ERROR(-20220,
                'Only an issued Authority to Work can be revoked (this one is ' || l_row.status || ').');
        END IF;
        IF TRIM(p_reason) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20221, 'Record the reason for revoking.');
        END IF;

        UPDATE ptw_pro.ptw_lv_atw
        SET    status           = 'REVOKED',
               revoked_by       = l_user,
               revoked_datetime = l_now,
               revoke_reason    = TRIM(p_reason),
               not_checked_out  = CASE WHEN status = 'ON_SITE' THEN 'Y' ELSE 'N' END
        WHERE  atw_id = p_atw_id;

        log_event(p_atw_id, 'REVOKED', 'N', NULL, NULL, p_reason);

        notify(
            p_username => holder_username(l_row.holder_user_id),
            p_title    => 'Authority to Work revoked',
            p_body     => 'Your Authority to Work ' || l_row.atw_number
                          || ' has been revoked. Stop work and speak to the BGIS site contact.'
        );
    END revoke_atw;


    PROCEDURE cancel_atw (
        p_atw_id  IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_reason  IN VARCHAR2 DEFAULT NULL
    ) IS
        l_row t_atw;
    BEGIN
        l_row := get_for_update(p_atw_id);

        IF l_row.status NOT IN ('DRAFT', 'REQUESTED') THEN
            RAISE_APPLICATION_ERROR(-20222,
                'Only a draft or requested Authority to Work can be cancelled. Use Revoke instead.');
        END IF;
        -- Issuers can cancel anything; a contractor can withdraw their own request.
        IF is_issuer(app_user) = 'N'
           AND NOT (l_row.status = 'REQUESTED' AND UPPER(l_row.requested_by) = app_user)
        THEN
            RAISE_APPLICATION_ERROR(-20203,
                'You do not have permission to cancel this Authority to Work.');
        END IF;

        UPDATE ptw_pro.ptw_lv_atw
        SET    status = 'CANCELLED'
        WHERE  atw_id = p_atw_id;

        log_event(p_atw_id, 'CANCELLED', 'N', NULL, NULL, p_reason);
    END cancel_atw;


    ---------------------------------------------------------------------------
    -- Public: holder / on-behalf actions
    ---------------------------------------------------------------------------
    PROCEDURE check_in (
        p_atw_id     IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_latitude   IN NUMBER DEFAULT NULL,
        p_longitude  IN NUMBER DEFAULT NULL
    ) IS
        l_row       t_atw;
        l_is_holder BOOLEAN;
    BEGIN
        l_row := get_for_update(p_atw_id);
        l_is_holder := NVL(holder_username(l_row.holder_user_id), '~') = app_user;

        IF NOT l_is_holder AND is_issuer(app_user) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20215, 'Only the pass holder or BGIS site staff can check in.');
        END IF;
        IF l_row.status = 'ON_SITE' THEN
            RAISE_APPLICATION_ERROR(-20216, 'Already checked in.');
        END IF;
        IF l_row.status NOT IN ('ISSUED', 'CHECKED_OUT') THEN
            RAISE_APPLICATION_ERROR(-20217,
                'This Authority to Work is ' || l_row.status || ' - check in is not possible.');
        END IF;
        IF l_row.valid_date <> local_today THEN
            RAISE_APPLICATION_ERROR(-20218,
                'This Authority to Work was valid for ' || fmt_date(l_row.valid_date)
                || ' only. A new one must be issued.');
        END IF;

        do_check_in(l_row, CASE WHEN l_is_holder THEN 'N' ELSE 'Y' END, p_latitude, p_longitude);
    END check_in;


    PROCEDURE check_out (
        p_atw_id     IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_latitude   IN NUMBER DEFAULT NULL,
        p_longitude  IN NUMBER DEFAULT NULL
    ) IS
        l_row       t_atw;
        l_is_holder BOOLEAN;
        l_now       DATE := local_now;
    BEGIN
        l_row := get_for_update(p_atw_id);
        l_is_holder := NVL(holder_username(l_row.holder_user_id), '~') = app_user;

        IF NOT l_is_holder AND is_issuer(app_user) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20215, 'Only the pass holder or BGIS site staff can check out.');
        END IF;
        -- Deliberately no date check: someone who forgot to check out before
        -- midnight can still record when they actually left.
        IF l_row.status <> 'ON_SITE' THEN
            RAISE_APPLICATION_ERROR(-20219, 'Not currently checked in.');
        END IF;

        UPDATE ptw_pro.ptw_lv_atw
        SET    status             = 'CHECKED_OUT',
               check_out_datetime = l_now
        WHERE  atw_id = p_atw_id;

        log_event(p_atw_id, 'CHECK_OUT', CASE WHEN l_is_holder THEN 'N' ELSE 'Y' END,
                  p_latitude, p_longitude);
    END check_out;


    ---------------------------------------------------------------------------
    -- Public: phase 2 contractor request
    ---------------------------------------------------------------------------
    PROCEDURE save_request (
        p_atw_id            IN OUT ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_site_id           IN     ptw_pro.ptw_lv_atw.site_id%TYPE,
        p_work_description  IN     ptw_pro.ptw_lv_atw.work_description%TYPE,
        p_rams_reference    IN     ptw_pro.ptw_lv_atw.rams_reference%TYPE
    ) IS
        l_user  ptw_pro.ptw_lv_users%ROWTYPE;
        l_row   t_atw;
        l_me    VARCHAR2(255) := app_user;
        l_today DATE          := local_today;
        l_now   DATE          := local_now;
    BEGIN
        IF is_contractor(l_me) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20223, 'Only contractors can request an Authority to Work.');
        END IF;
        assert_site(p_site_id);

        SELECT * INTO l_user
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = l_me;

        IF p_atw_id IS NULL THEN
            INSERT INTO ptw_pro.ptw_lv_atw (
                site_id, holder_user_id, holder_name, holder_employer, holder_mobile,
                valid_date, work_description, rams_reference, status,
                requested_by, requested_datetime
            ) VALUES (
                p_site_id, l_user.user_id,
                TRIM(l_user.first_name || ' ' || l_user.last_name),
                NVL(TRIM(l_user.employer_name), '-'), l_user.mobile_no,
                l_today, TRIM(p_work_description), TRIM(p_rams_reference), 'REQUESTED',
                l_me, l_now
            )
            RETURNING atw_id INTO p_atw_id;

            log_event(p_atw_id, 'REQUESTED');
        ELSE
            l_row := get_for_update(p_atw_id);
            IF l_row.status <> 'REQUESTED' OR UPPER(l_row.requested_by) <> l_me THEN
                RAISE_APPLICATION_ERROR(-20224, 'This request can no longer be changed.');
            END IF;

            UPDATE ptw_pro.ptw_lv_atw
            SET    site_id          = p_site_id,
                   work_description = TRIM(p_work_description),
                   rams_reference   = TRIM(p_rams_reference)
            WHERE  atw_id = p_atw_id;

            log_event(p_atw_id, 'UPDATED');
        END IF;

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            RAISE_APPLICATION_ERROR(-20208,
                'You already have an Authority to Work (or request) for today.');
    END save_request;


    ---------------------------------------------------------------------------
    -- Public: pass / verify
    ---------------------------------------------------------------------------
    FUNCTION get_today_atw_id (p_username IN VARCHAR2) RETURN NUMBER IS
        l_today  DATE := local_today;
        l_atw_id NUMBER;
    BEGIN
        SELECT a.atw_id
        INTO   l_atw_id
        FROM   ptw_pro.ptw_lv_atw   a
        JOIN   ptw_pro.ptw_lv_users u ON u.user_id = a.holder_user_id
        WHERE  UPPER(u.username) = UPPER(p_username)
        AND    a.valid_date      = l_today
        AND    a.status         <> 'CANCELLED'
        -- a live one wins over a revoked one issued earlier the same day
        ORDER  BY CASE WHEN a.status = 'REVOKED' THEN 1 ELSE 0 END, a.atw_id DESC
        FETCH FIRST 1 ROW ONLY;
        RETURN l_atw_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN NULL;
    END get_today_atw_id;


    FUNCTION verify_url (p_token IN VARCHAR2) RETURN VARCHAR2 IS
        l_url VARCHAR2(4000);
    BEGIN
        IF p_token IS NULL THEN
            RETURN NULL;
        END IF;
        -- Absolute friendly URL to the verify page, then strip the session
        -- and checksum so the QR code works in any session (or none - APEX
        -- sends the scanner to login and back via Deep Linking).
        -- REQUIRES on the verify page: Page Access Protection = Unrestricted,
        -- P37_TOKEN Session State Protection = Unrestricted. See spec doc.
        l_url := apex_page.get_url(
                     p_page         => 'ATW-VERIFY',
                     p_items        => 'P37_TOKEN',
                     p_values       => p_token,
                     p_plain_url    => TRUE,
                     p_absolute_url => TRUE);
        l_url := REGEXP_REPLACE(l_url, '([?&])(session|cs|clear)=[^&]*', '\1');
        l_url := REGEXP_REPLACE(l_url, '&{2,}', '&');
        l_url := REGEXP_REPLACE(l_url, '\?&', '?');
        l_url := REGEXP_REPLACE(l_url, '[?&]$', '');
        RETURN l_url;
    END verify_url;


    FUNCTION render_pass (p_atw_id IN ptw_pro.ptw_lv_atw.atw_id%TYPE) RETURN CLOB IS
        l_html       CLOB;
        l_row        t_atw;
        l_site       ptw_pro.ptw_lv_sites.site_name%TYPE;
        l_eff        VARCHAR2(20);
        l_label      VARCHAR2(60);
        l_sub        VARCHAR2(200);
        l_logo       VARCHAR2(500);
        l_logo_count NUMBER;
        l_qr         CLOB;
        l_now        DATE := local_now;
        l_permits    VARCHAR2(4000);

        FUNCTION esc (p IN VARCHAR2) RETURN VARCHAR2 IS
        BEGIN
            RETURN apex_escape.html(p);
        END esc;

        FUNCTION check_li (p_flag IN VARCHAR2, p_text IN VARCHAR2) RETURN VARCHAR2 IS
        BEGIN
            RETURN '<li class="ptw-atw-check' || CASE WHEN p_flag = 'Y' THEN ' is-ok' END || '">'
                || '<span class="fa ' || CASE WHEN p_flag = 'Y' THEN 'fa-check-circle' ELSE 'fa-circle-o' END
                || '" aria-hidden="true"></span><span>' || esc(p_text) || '</span></li>';
        END check_li;

        FUNCTION meta (p_label IN VARCHAR2, p_value IN VARCHAR2) RETURN VARCHAR2 IS
        BEGIN
            RETURN '<div class="ptw-atw-meta-item"><dt>' || esc(p_label) || '</dt><dd>'
                || NVL(esc(p_value), '&ndash;') || '</dd></div>';
        END meta;
    BEGIN
        BEGIN
            SELECT * INTO l_row FROM ptw_pro.ptw_lv_atw WHERE atw_id = p_atw_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RETURN '<div class="ptw-atw-empty"><span class="fa fa-id-card-o" aria-hidden="true"></span>'
                    || '<p>Authority to Work not found.</p></div>';
        END;

        -- Holder, or staff who may verify. (VPD already limits contractors
        -- to their own rows; this is the explicit app-level check.)
        IF NVL(holder_username(l_row.holder_user_id), '~') <> app_user AND can_verify(app_user) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20226, 'You cannot view this Authority to Work.');
        END IF;

        SELECT site_name INTO l_site FROM ptw_pro.ptw_lv_sites WHERE site_id = l_row.site_id;

        l_eff := effective_status(l_row.status, l_row.valid_date);
        l_permits := live_permit_numbers(l_row.atw_id);

        CASE l_eff
            WHEN 'ON_SITE'     THEN l_label := 'On site';
                                    l_sub   := 'Checked in ' || fmt_time(l_row.check_in_datetime);
            WHEN 'ISSUED'      THEN l_label := 'Valid, not checked in';
                                    l_sub   := 'Issued ' || fmt_time(l_row.issued_datetime);
            WHEN 'CHECKED_OUT' THEN l_label := 'Checked out';
                                    l_sub   := 'Left site ' || fmt_time(l_row.check_out_datetime);
            WHEN 'EXPIRED'     THEN l_label := 'Expired';
                                    l_sub   := 'Was valid ' || fmt_date(l_row.valid_date) || ' only';
            WHEN 'REVOKED'     THEN l_label := 'Revoked: stop work';
                                    l_sub   := 'Revoked ' || fmt_time(l_row.revoked_datetime);
            WHEN 'REQUESTED'   THEN l_label := 'Requested';
                                    l_sub   := 'Waiting for BGIS checks';
            WHEN 'DRAFT'       THEN l_label := 'Being prepared';
                                    l_sub   := 'Waiting for BGIS checks';
            ELSE                    l_label := INITCAP(REPLACE(l_eff, '_', ' '));
        END CASE;

        -- Company logo (same convention as the dashboard header: logo_<company_id>.png)
        SELECT COUNT(*) INTO l_logo_count
        FROM   apex_application_static_files
        WHERE  application_id = NVL(TO_NUMBER(V('APP_ID')), 105)
        AND    file_name      = 'logo_' || l_row.company_id || '.png';
        IF l_logo_count > 0 THEN
            l_logo := V('APP_FILES') || 'logo_' || l_row.company_id || '.png';
        END IF;

        IF l_row.verify_token IS NOT NULL THEN
            l_qr := apex_barcode.get_qrcode_svg(
                        p_value            => verify_url(l_row.verify_token),
                        p_size             => 200,
                        p_quiet            => 2,
                        p_foreground_color => '#13294b',
                        p_background_color => '#ffffff');
        END IF;

        l_html := '<article class="ptw-atw-pass ptw-atw--' || LOWER(l_eff) || '"'
            || ' data-status="'     || l_eff || '"'
            || ' data-valid-date="' || TO_CHAR(l_row.valid_date, 'YYYY-MM-DD') || '"'
            || ' data-rendered="'   || TO_CHAR(l_now, 'YYYY-MM-DD"T"HH24:MI:SS') || '"'
            || ' aria-label="Authority to Work ' || esc(l_row.atw_number) || '">'

            -- Header band
            || '<header class="ptw-atw-head">'
            ||   CASE WHEN l_logo IS NOT NULL
                      THEN '<img class="ptw-atw-logo" src="' || l_logo || '" alt="">' END
            ||   '<div class="ptw-atw-head-text">'
            ||     '<span class="ptw-atw-title">Authority to Work</span>'
            ||     '<span class="ptw-atw-number">' || NVL(esc(l_row.atw_number), 'Not yet issued') || '</span>'
            ||   '</div>'
            || '</header>'

            -- Live status band: animated + ticking clock = not a screenshot
            || '<div class="ptw-atw-status" role="status">'
            ||   '<span class="ptw-atw-dot" aria-hidden="true"></span>'
            ||   '<span class="ptw-atw-status-text"><strong>' || esc(l_label) || '</strong>'
            ||     CASE WHEN l_sub IS NOT NULL THEN '<small>' || esc(l_sub) || '</small>' END
            ||   '</span>'
            ||   '<time class="ptw-atw-clock" aria-hidden="true"></time>'
            || '</div>'

            -- Holder
            || '<section class="ptw-atw-body">'
            ||   '<div class="ptw-atw-who">'
            ||     '<div class="ptw-atw-holder">'
            ||       '<div class="ptw-atw-name">'     || esc(l_row.holder_name)     || '</div>'
            ||       '<div class="ptw-atw-employer">' || esc(l_row.holder_employer) || '</div>'
            ||     '</div>'
            -- "Valid for above date only": the date is the thing a checker looks for
            ||     '<div class="ptw-atw-date" title="Valid ' || fmt_date(l_row.valid_date) || ' only">'
            ||       '<span class="ptw-atw-date-dow">' || TO_CHAR(l_row.valid_date, 'Dy', 'NLS_DATE_LANGUAGE=ENGLISH') || '</span>'
            ||       '<span class="ptw-atw-date-day">' || TO_CHAR(l_row.valid_date, 'FMDD') || '</span>'
            ||       '<span class="ptw-atw-date-mon">' || TO_CHAR(l_row.valid_date, 'Mon YYYY', 'NLS_DATE_LANGUAGE=ENGLISH') || '</span>'
            ||     '</div>'
            ||   '</div>'
            ||   '<dl class="ptw-atw-meta">'
            ||     meta('Site', l_site)
            ||     meta('Issued by', l_row.issuer_name)
            ||     CASE WHEN l_permits IS NOT NULL THEN meta('Person in Charge on', l_permits) END
            ||     CASE WHEN l_row.rams_reference IS NOT NULL THEN meta('RAMS ref', l_row.rams_reference) END
            ||   '</dl>'
            ||   '<ul class="ptw-atw-checks">'
            ||     check_li(l_row.induction_ok,     'Site induction completed')
            ||     check_li(l_row.ssow_ok,          'Safe system of work approved')
            ||     check_li(l_row.competence_ok,    'Competence checked')
            ||     check_li(l_row.equipment_ppe_ok, 'Equipment and PPE checked')
            ||   '</ul>'
            || '</section>';

        IF l_qr IS NOT NULL THEN
            l_html := l_html
                || '<section class="ptw-atw-qr" aria-label="Verification QR code">'
                || l_qr
                || '<span class="ptw-atw-qr-hint">Site staff: scan to check live status</span>'
                || '</section>';
        END IF;

        l_html := l_html
            || '<footer class="ptw-atw-foot">'
            ||   '<span>Valid for the date shown only.</span>'
            ||   '<span>Check out when you leave site.</span>'
            ||   '<span class="ptw-atw-offline" hidden>Offline &ndash; showing status as at '
            ||     fmt_time(l_now) || '</span>'
            || '</footer>'
            || '</article>';

        RETURN l_html;
    END render_pass;


    FUNCTION verify_scan (p_token_or_url IN VARCHAR2) RETURN NUMBER IS
        l_token  VARCHAR2(32);
        l_atw_id NUMBER;
    BEGIN
        IF can_verify(app_user) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20225, 'You do not have permission to verify Authority to Work passes.');
        END IF;

        -- Accept either the raw token or the full URL from the QR code.
        l_token := REGEXP_SUBSTR(LOWER(p_token_or_url), '[0-9a-f]{32}');
        IF l_token IS NULL THEN
            RETURN NULL;
        END IF;

        BEGIN
            SELECT atw_id INTO l_atw_id
            FROM   ptw_pro.ptw_lv_atw
            WHERE  verify_token = l_token;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN RETURN NULL;
        END;

        log_event(l_atw_id, 'VERIFIED');
        RETURN l_atw_id;
    END verify_scan;


    ---------------------------------------------------------------------------
    -- Public: PTW integration
    ---------------------------------------------------------------------------
    FUNCTION has_valid_atw (
        p_username IN VARCHAR2,
        p_site_id  IN ptw_pro.ptw_lv_atw.site_id%TYPE
    ) RETURN VARCHAR2 IS
        l_today DATE := local_today;
        l_count NUMBER;
    BEGIN
        IF is_contractor(p_username) = 'N' THEN
            RETURN 'X';
        END IF;
        SELECT COUNT(*)
        INTO   l_count
        FROM   ptw_pro.ptw_lv_atw   a
        JOIN   ptw_pro.ptw_lv_users u ON u.user_id = a.holder_user_id
        WHERE  UPPER(u.username) = UPPER(p_username)
        AND    a.site_id         = p_site_id
        AND    a.valid_date      = l_today
        AND    a.status          = 'ON_SITE';
        RETURN CASE WHEN l_count > 0 THEN 'Y' ELSE 'N' END;
    END has_valid_atw;


    FUNCTION validate_permit_people (
        p_site_id             IN ptw_pro.ptw_lv_permits.site_id%TYPE,
        p_pic_is_bgis         IN VARCHAR2,
        p_atw_id              IN ptw_pro.ptw_lv_atw.atw_id%TYPE,
        p_supervising_company IN ptw_pro.ptw_lv_permits.supervising_company%TYPE,
        p_other_persons_count IN ptw_pro.ptw_lv_permits.other_persons_count%TYPE
    ) RETURN VARCHAR2 IS
        l_today  DATE := local_today;
        l_atw    t_atw;
        l_others NUMBER;
    BEGIN
        IF c_ptw_enforce = 'N' OR UPPER(p_pic_is_bgis) = 'Y' THEN
            RETURN NULL;
        END IF;

        IF p_site_id IS NULL THEN
            RETURN 'Select an existing site. A contractor Person in Charge must be checked in '
                || 'at the site with an Authority to Work.';
        END IF;
        IF p_atw_id IS NULL THEN
            RETURN 'Select the Person in Charge from contractors checked in at this site today, '
                || 'or mark the Person in Charge as BGIS staff.';
        END IF;

        BEGIN
            SELECT * INTO l_atw FROM ptw_pro.ptw_lv_atw WHERE atw_id = p_atw_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RETURN 'The selected Authority to Work could not be found.';
        END;

        IF effective_status(l_atw.status, l_atw.valid_date) <> 'ON_SITE' THEN
            RETURN l_atw.holder_name || ' is not checked in with a valid Authority to Work ('
                || LOWER(REPLACE(effective_status(l_atw.status, l_atw.valid_date), '_', ' ')) || ').';
        END IF;
        IF l_atw.site_id <> p_site_id THEN
            RETURN l_atw.holder_name || '''s Authority to Work is for a different site.';
        END IF;

        IF UPPER(TRIM(p_supervising_company)) <> UPPER(TRIM(l_atw.holder_employer)) THEN
            RETURN 'Company responsible must be ' || l_atw.holder_employer
                || ', the employer on ' || l_atw.holder_name || '''s Authority to Work.';
        END IF;

        -- Everyone working needs their own ATW: other persons from the same
        -- employer checked in at this site today, excluding the PIC.
        IF NVL(p_other_persons_count, 0) > 0 THEN
            SELECT COUNT(*)
            INTO   l_others
            FROM   ptw_pro.ptw_lv_atw a
            WHERE  a.site_id    = p_site_id
            AND    a.valid_date = l_today
            AND    a.status     = 'ON_SITE'
            AND    a.atw_id    <> l_atw.atw_id
            AND    UPPER(TRIM(a.holder_employer)) = UPPER(TRIM(l_atw.holder_employer));

            IF p_other_persons_count > l_others THEN
                RETURN 'The permit lists ' || p_other_persons_count || ' other person(s), but only '
                    || l_others || ' other ' || l_atw.holder_employer
                    || ' staff are checked in at this site with an Authority to Work. '
                    || 'Everyone working must have their own.';
            END IF;
        END IF;

        RETURN NULL;
    END validate_permit_people;


    FUNCTION permit_atw_problem (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    ) RETURN VARCHAR2 IS
        l_site_id  ptw_pro.ptw_lv_permits.site_id%TYPE;
        l_bgis     ptw_pro.ptw_lv_permits.pic_is_bgis%TYPE;
        l_atw_id   ptw_pro.ptw_lv_permits.atw_id%TYPE;
        l_company  ptw_pro.ptw_lv_permits.supervising_company%TYPE;
        l_others   ptw_pro.ptw_lv_permits.other_persons_count%TYPE;
    BEGIN
        SELECT site_id, pic_is_bgis, atw_id, supervising_company, other_persons_count
        INTO   l_site_id, l_bgis, l_atw_id, l_company, l_others
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;

        RETURN validate_permit_people(l_site_id, l_bgis, l_atw_id, l_company, l_others);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 'Permit not found.';
    END permit_atw_problem;


    PROCEDURE assert_permit_atw (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    ) IS
        l_problem VARCHAR2(4000) := permit_atw_problem(p_permit_id);
    BEGIN
        IF l_problem IS NOT NULL THEN
            RAISE_APPLICATION_ERROR(-20230, l_problem);
        END IF;
    END assert_permit_atw;


    PROCEDURE set_permit_pic (
        p_permit_id   IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_pic_is_bgis IN VARCHAR2,
        p_atw_id      IN ptw_pro.ptw_lv_atw.atw_id%TYPE
    ) IS
        l_status  ptw_pro.ptw_lv_permits.workflow_status%TYPE;
        l_old_atw ptw_pro.ptw_lv_permits.atw_id%TYPE;
        l_number  ptw_pro.ptw_lv_permits.permit_number%TYPE;
        l_atw     t_atw;
    BEGIN
        SELECT workflow_status, atw_id, permit_number
        INTO   l_status, l_old_atw, l_number
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id
        FOR UPDATE;

        IF l_status <> 'DRAFT' THEN
            RETURN;                 -- same rule as Page 2: read-only after draft
        END IF;

        IF UPPER(p_pic_is_bgis) = 'Y' OR p_atw_id IS NULL THEN
            UPDATE ptw_pro.ptw_lv_permits
            SET    pic_is_bgis = CASE WHEN UPPER(p_pic_is_bgis) = 'Y' THEN 'Y' ELSE 'N' END,
                   atw_id      = NULL
            WHERE  permit_id = p_permit_id;
            RETURN;
        END IF;

        SELECT * INTO l_atw FROM ptw_pro.ptw_lv_atw WHERE atw_id = p_atw_id;

        UPDATE ptw_pro.ptw_lv_permits
        SET    pic_is_bgis           = 'N',
               atw_id                = l_atw.atw_id,
               person_in_charge_name = l_atw.holder_name,
               supervising_company   = l_atw.holder_employer
        WHERE  permit_id = p_permit_id;

        IF NVL(l_old_atw, -1) <> l_atw.atw_id THEN
            log_event(l_atw.atw_id, 'PERMIT_LINKED', 'N', NULL, NULL,
                      'Person in Charge on permit ' || l_number);
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20204, 'Permit or Authority to Work not found or not accessible.');
    END set_permit_pic;


    FUNCTION live_permit_numbers (
        p_atw_id IN ptw_pro.ptw_lv_atw.atw_id%TYPE
    ) RETURN VARCHAR2 IS
        l_list VARCHAR2(4000);
    BEGIN
        SELECT LISTAGG(permit_number, ', ') WITHIN GROUP (ORDER BY permit_number)
        INTO   l_list
        FROM   ptw_pro.ptw_lv_permits
        WHERE  atw_id = p_atw_id
        AND    workflow_status IN ('AWAITING_AUTH', 'AUTHORISED', 'STARTED', 'SUSPENDED');
        RETURN l_list;
    END live_permit_numbers;


    ---------------------------------------------------------------------------
    -- Public: automation
    ---------------------------------------------------------------------------
    PROCEDURE expire_atws (p_expired OUT NUMBER, p_cancelled OUT NUMBER) IS
        TYPE t_ids IS TABLE OF ptw_pro.ptw_lv_atw.atw_id%TYPE;
        l_today   DATE          := local_today;
        l_now     DATE          := local_now;
        l_by      VARCHAR2(255) := app_user;
        l_expired t_ids;
        l_cancel  t_ids;
    BEGIN
        UPDATE ptw_pro.ptw_lv_atw
        SET    status           = 'EXPIRED',
               expired_datetime = l_now,
               not_checked_out  = CASE WHEN status = 'ON_SITE' THEN 'Y' ELSE 'N' END
        WHERE  status IN ('ISSUED', 'ON_SITE', 'CHECKED_OUT')
        AND    valid_date < l_today
        RETURNING atw_id BULK COLLECT INTO l_expired;

        FORALL i IN 1 .. l_expired.COUNT
            INSERT INTO ptw_pro.ptw_lv_atw_events
                (atw_id, event_type, event_datetime, event_by)
            VALUES
                (l_expired(i), 'EXPIRED', l_now, l_by);

        UPDATE ptw_pro.ptw_lv_atw
        SET    status = 'CANCELLED'
        WHERE  status IN ('DRAFT', 'REQUESTED')
        AND    valid_date < l_today
        RETURNING atw_id BULK COLLECT INTO l_cancel;

        FORALL i IN 1 .. l_cancel.COUNT
            INSERT INTO ptw_pro.ptw_lv_atw_events
                (atw_id, event_type, event_datetime, event_by, notes)
            VALUES
                (l_cancel(i), 'CANCELLED', l_now, l_by, 'Not issued on the day - auto cancelled');

        p_expired   := l_expired.COUNT;
        p_cancelled := l_cancel.COUNT;
    END expire_atws;


    ---------------------------------------------------------------------------
    -- VPD holder policy
    ---------------------------------------------------------------------------
    FUNCTION holder_policy (
        p_schema IN VARCHAR2,
        p_object IN VARCHAR2
    ) RETURN VARCHAR2 IS
        l_app_user  VARCHAR2(255) := V('APP_USER');
        l_user_id   ptw_pro.ptw_lv_users.user_id%TYPE;
        l_super     ptw_pro.ptw_lv_users.is_super_user%TYPE;
        l_contract  NUMBER;
        l_other     NUMBER;
    BEGIN
        -- No APEX session: PTW_COMPANY_POLICY already fails closed.
        IF l_app_user IS NULL THEN
            RETURN NULL;
        END IF;

        SELECT user_id, is_super_user
        INTO   l_user_id, l_super
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(l_app_user)
        AND    is_active = 'Y';

        IF l_super = 'Y' THEN
            RETURN NULL;
        END IF;

        SELECT COUNT(CASE WHEN r.role_name  = 'CONTRACTOR' THEN 1 END),
               COUNT(CASE WHEN r.role_name <> 'CONTRACTOR' THEN 1 END)
        INTO   l_contract, l_other
        FROM   ptw_pro.ptw_lv_user_role_assignments ur
        JOIN   ptw_pro.ptw_lv_roles r ON r.role_id = ur.role_id
        WHERE  ur.user_id   = l_user_id
        AND    ur.is_active = 'Y'
        AND    r.is_active  = 'Y';

        IF l_contract = 0 OR l_other > 0 THEN
            RETURN NULL;              -- staff: company policy only
        END IF;

        IF UPPER(p_object) = 'PTW_LV_ATW' THEN
            RETURN 'holder_user_id = ' || l_user_id;
        ELSE
            RETURN 'atw_id IN (SELECT a.atw_id FROM ptw_pro.ptw_lv_atw a WHERE a.holder_user_id = '
                   || l_user_id || ')';
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '1=2';             -- unknown / inactive user: fail closed
    END holder_policy;

END ptw_atw_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_AUTH_WORKFLOW_PKG" AS

    ---------------------------------------------------------------------------
    -- Private helpers
    ---------------------------------------------------------------------------
    FUNCTION current_user_name RETURN VARCHAR2 IS
    BEGIN
        RETURN UPPER(NVL(V('APP_USER'), USER));
    END current_user_name;

    FUNCTION b64_to_blob (p_b64 IN CLOB) RETURN BLOB IS
    BEGIN
        IF p_b64 IS NULL OR DBMS_LOB.GETLENGTH(p_b64) = 0 THEN
            RETURN NULL;
        END IF;
        RETURN apex_web_service.clobbase642blob(
                   REGEXP_REPLACE(p_b64, '^data:image/[^;]+;base64,', ''));
    END b64_to_blob;

    FUNCTION user_full_name (p_username IN VARCHAR2) RETURN VARCHAR2 IS
        l_name VARCHAR2(201);
    BEGIN
        SELECT TRIM(first_name || ' ' || last_name)
        INTO   l_name
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(p_username);
        RETURN NVL(l_name, p_username);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN p_username;
    END user_full_name;

    PROCEDURE notify (
        p_username IN VARCHAR2,
        p_title    IN VARCHAR2,
        p_body     IN VARCHAR2
    ) IS
    BEGIN
        IF p_username IS NULL THEN
            RETURN;
        END IF;
        apex_pwa.send_push_notification(
            p_application_id => NVL(TO_NUMBER(V('APP_ID')), 105),
            p_user_name      => p_username,
            p_title          => p_title,
            p_body           => p_body
        );
    EXCEPTION
        -- User not subscribed / push not configured: never block the workflow.
        WHEN OTHERS THEN
            apex_debug.warn('ptw_auth_workflow_pkg.notify failed for %s: %s',
                            p_username, SQLERRM);
    END notify;

    ---------------------------------------------------------------------------
    -- Public
    ---------------------------------------------------------------------------
    FUNCTION is_authoriser (p_username IN VARCHAR2) RETURN VARCHAR2 IS
        l_count NUMBER;
    BEGIN
        SELECT COUNT(*)
        INTO   l_count
        FROM   ptw_pro.ptw_lv_user_roles_v
        WHERE  UPPER(username) = UPPER(p_username)
        AND    role_name IN ('AUTHORISER', 'ADMIN')
        AND    is_active = 'Y';
        RETURN CASE WHEN l_count > 0 THEN 'Y' ELSE 'N' END;
    END is_authoriser;

    FUNCTION can_authorise (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_username  IN VARCHAR2
    ) RETURN VARCHAR2 IS
        l_status     ptw_pro.ptw_lv_permits.workflow_status%TYPE;
        l_created_by ptw_pro.ptw_lv_permits.created_by%TYPE;
    BEGIN
        SELECT workflow_status, created_by
        INTO   l_status, l_created_by
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;   -- VPD scopes to the caller's company

        IF l_status <> c_awaiting_auth THEN
            RETURN 'N';
        END IF;
        IF UPPER(l_created_by) = UPPER(p_username) THEN
            RETURN 'N';                   -- no self-authorisation
        END IF;
        RETURN is_authoriser(p_username);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN 'N';
    END can_authorise;


    PROCEDURE submit_for_authorisation (
        p_permit_id       IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_requested_auth  IN VARCHAR2,
        p_accept_name     IN ptw_pro.ptw_signatures.person_name%TYPE,
        p_accept_mobile   IN ptw_pro.ptw_signatures.mobile_no%TYPE,
        p_accept_company  IN ptw_pro.ptw_signatures.company_name%TYPE,
        p_accept_sig_b64  IN CLOB,
        p_latitude        IN NUMBER,
        p_longitude       IN NUMBER
    ) IS
        l_user        VARCHAR2(100) := current_user_name;
        l_now         DATE          := SYSDATE;
        l_permit_no   ptw_pro.ptw_lv_permits.permit_number%TYPE;
        l_req_company NUMBER;
        l_permit_co   NUMBER;
    BEGIN
        IF p_requested_auth IS NULL THEN
            RAISE_APPLICATION_ERROR(-20101, 'Select the authoriser to send this permit to.');
        END IF;
        IF UPPER(p_requested_auth) = l_user THEN
            RAISE_APPLICATION_ERROR(-20102, 'You cannot send a permit to yourself for authorisation.');
        END IF;
        IF is_authoriser(p_requested_auth) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20103, 'The selected person is not an active authoriser.');
        END IF;
        IF p_accept_sig_b64 IS NULL THEN
            RAISE_APPLICATION_ERROR(-20104, 'The person in charge must sign the acceptance.');
        END IF;

        SELECT permit_number, company_id
        INTO   l_permit_no, l_permit_co
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;

        -- Requested authoriser must belong to the permit's company
        -- (super users acting for another company included).
        SELECT MAX(company_id)
        INTO   l_req_company
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(p_requested_auth);
        IF NVL(l_req_company, -1) <> l_permit_co THEN
            RAISE_APPLICATION_ERROR(-20105, 'The selected authoriser does not belong to this company.');
        END IF;

        UPDATE ptw_pro.ptw_lv_permits
        SET    workflow_status         = c_awaiting_auth,
               current_step            = 'AUTHORISATION',
               auth_requested_user     = UPPER(p_requested_auth),
               submitted_for_auth_by   = l_user,
               submitted_for_auth_date = l_now,
               accept_latitude         = p_latitude,
               accept_longitude        = p_longitude,
               modified_by             = l_user,
               modified_date           = CURRENT_TIMESTAMP
        WHERE  permit_id       = p_permit_id
        AND    workflow_status = 'DRAFT';

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20106,
                'Permit ' || l_permit_no || ' is no longer a draft and cannot be submitted.');
        END IF;

        ptw_pro.ptw_signature_pkg.save_signature(
            p_permit_id      => p_permit_id,
            p_stage          => 'ACCEPT',
            p_person_name    => p_accept_name,
            p_signature_blob => b64_to_blob(p_accept_sig_b64),
            p_mobile_no      => p_accept_mobile,
            p_company_name   => p_accept_company,
            p_event_datetime => l_now,
            p_latitude       => p_latitude,
            p_longitude      => p_longitude
        );

        notify(
            p_username => UPPER(p_requested_auth),
            p_title    => 'Permit awaiting your authorisation',
            p_body     => 'Permit ' || l_permit_no || ' has been submitted by '
                          || user_full_name(l_user) || ' and is waiting for you to authorise it.'
        );
    END submit_for_authorisation;


    PROCEDURE authorise (
        p_permit_id     IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_auth_sig_b64  IN CLOB,
        p_latitude      IN NUMBER,
        p_longitude     IN NUMBER
    ) IS
        l_user       VARCHAR2(100) := current_user_name;
        l_now        DATE          := SYSDATE;
        l_mobile     ptw_pro.ptw_lv_users.mobile_no%TYPE;
        l_permit_no  ptw_pro.ptw_lv_permits.permit_number%TYPE;
        l_created_by ptw_pro.ptw_lv_permits.created_by%TYPE;
    BEGIN
        IF can_authorise(p_permit_id, l_user) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20111,
                'You are not able to authorise this permit. It may already have been '
                || 'authorised or rejected, or you created it.');
        END IF;
        IF p_auth_sig_b64 IS NULL THEN
            RAISE_APPLICATION_ERROR(-20112, 'Your signature is required to authorise.');
        END IF;

        BEGIN
            SELECT mobile_no INTO l_mobile
            FROM   ptw_pro.ptw_lv_users
            WHERE  UPPER(username) = l_user;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN l_mobile := NULL;
        END;

        UPDATE ptw_pro.ptw_lv_permits
        SET    workflow_status  = 'AUTHORISED',
               current_step     = 'AUTHORISATION',
               auth_person_name = l_user,      -- legacy column still read by
                                               -- dashboard/visibility filters
               auth_latitude    = p_latitude,
               auth_longitude   = p_longitude,
               modified_by      = l_user,
               modified_date    = CURRENT_TIMESTAMP
        WHERE  permit_id       = p_permit_id
        AND    workflow_status = c_awaiting_auth
        RETURNING permit_number, created_by INTO l_permit_no, l_created_by;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20113,
                'This permit is no longer awaiting authorisation. Please refresh.');
        END IF;

        ptw_pro.ptw_signature_pkg.save_signature(
            p_permit_id      => p_permit_id,
            p_stage          => 'AUTH',
            p_person_name    => l_user,
            p_signature_blob => b64_to_blob(p_auth_sig_b64),
            p_mobile_no      => l_mobile,
            p_event_datetime => l_now,
            p_latitude       => p_latitude,
            p_longitude      => p_longitude
        );

        notify(
            p_username => UPPER(l_created_by),
            p_title    => 'Permit authorised',
            p_body     => 'Permit ' || l_permit_no || ' has been authorised by '
                          || user_full_name(l_user) || '. You can now start it.'
        );
    END authorise;


    PROCEDURE reject (
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_reason    IN VARCHAR2
    ) IS
        l_user       VARCHAR2(100) := current_user_name;
        l_permit_no  ptw_pro.ptw_lv_permits.permit_number%TYPE;
        l_created_by ptw_pro.ptw_lv_permits.created_by%TYPE;
    BEGIN
        IF TRIM(p_reason) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20121, 'A reason is required to reject a permit.');
        END IF;
        IF can_authorise(p_permit_id, l_user) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20122,
                'You are not able to reject this permit. It may already have been '
                || 'authorised or rejected, or you created it.');
        END IF;

        UPDATE ptw_pro.ptw_lv_permits
        SET    workflow_status    = 'DRAFT',
               current_step       = 'AUTHORISATION',
               auth_rejected_by   = l_user,
               auth_rejected_date = SYSDATE,
               auth_reject_reason = SUBSTR(TRIM(p_reason), 1, 1000),
               modified_by        = l_user,
               modified_date      = CURRENT_TIMESTAMP
        WHERE  permit_id       = p_permit_id
        AND    workflow_status = c_awaiting_auth
        RETURNING permit_number, created_by INTO l_permit_no, l_created_by;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE_APPLICATION_ERROR(-20123,
                'This permit is no longer awaiting authorisation. Please refresh.');
        END IF;

        -- Force a fresh acceptance signature on resubmission.
        DELETE FROM ptw_pro.ptw_signatures
        WHERE  permit_id = p_permit_id
        AND    stage     = 'ACCEPT';

        notify(
            p_username => UPPER(l_created_by),
            p_title    => 'Permit returned',
            p_body     => 'Permit ' || l_permit_no || ' was returned by '
                          || user_full_name(l_user) || ': ' || SUBSTR(TRIM(p_reason), 1, 150)
        );
    END reject;

END ptw_auth_workflow_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_CHECKLIST_PKG" AS

    FUNCTION get_checklist_json(p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE)
        RETURN CLOB
    IS
        l_type_id ptw_pro.ptw_types.type_id%TYPE;
        l_clob    CLOB;
    BEGIN
        -- Subject to VPD on PTW_LV_PERMITS: a permit outside the caller's
        -- company simply won't be found here.
        SELECT t.type_id
        INTO   l_type_id
        FROM   ptw_pro.ptw_lv_permits p
        JOIN   ptw_pro.ptw_types t ON t.ptw_type = p.ptw_type
        WHERE  p.permit_id = p_permit_id;

        apex_json.initialize_clob_output;
        apex_json.open_array;

        FOR r IN (
            SELECT ci.checklist_item_id, ci.item_code, ci.section_code,
                   ci.item_seq, ci.question_text, ci.help_text,
                   ci.response_type, cr.response
            FROM   ptw_pro.ptw_checklist_items ci
            LEFT JOIN ptw_pro.ptw_checklist_responses cr
                   ON cr.checklist_item_id = ci.checklist_item_id
                  AND cr.permit_id = p_permit_id
            WHERE  ci.type_id = l_type_id
            AND    ci.is_active = 'Y'
            ORDER BY ci.section_code, ci.item_seq
        ) LOOP
            apex_json.open_object;
            apex_json.write('checklist_item_id', r.checklist_item_id);
            apex_json.write('item_code', r.item_code);
            apex_json.write('section', r.section_code);
            apex_json.write('seq', r.item_seq);
            apex_json.write('question', r.question_text);
            apex_json.write('help', r.help_text);
            apex_json.write('response_type', r.response_type);
            apex_json.write('response', r.response);
            apex_json.close_object;
        END LOOP;

        apex_json.close_array;
        l_clob := apex_json.get_clob_output;
        apex_json.free_output;
        RETURN l_clob;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            apex_json.free_output;
            RETURN '[]';
        WHEN OTHERS THEN
            apex_json.free_output;
            RAISE_APPLICATION_ERROR(-20051, 'Error loading checklist for permit '
                || p_permit_id || ': ' || SQLERRM);
    END get_checklist_json;


    PROCEDURE save_checklist_responses(
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_json      IN CLOB,
        p_latitude  IN NUMBER DEFAULT NULL,
        p_longitude IN NUMBER DEFAULT NULL
    )
    IS
        l_company_id ptw_pro.ptw_lv_permits.company_id%TYPE;
    BEGIN
        -- Same VPD-backed lookup as above — also doubles as existence check.
        SELECT company_id
        INTO   l_company_id
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;

        MERGE INTO ptw_pro.ptw_checklist_responses cr
        USING (
            SELECT jt.checklist_item_id, jt.response
            FROM   JSON_TABLE(
                       p_json, '$[*]'
                       COLUMNS (
                           checklist_item_id NUMBER       PATH '$.checklist_item_id',
                           response          VARCHAR2(2)  PATH '$.response'
                       )
                   ) jt
            WHERE  jt.response IS NOT NULL
        ) src
        ON (cr.permit_id = p_permit_id AND cr.checklist_item_id = src.checklist_item_id)
        WHEN MATCHED THEN
            UPDATE SET cr.response      = src.response,
                       cr.modified_date = CURRENT_TIMESTAMP,
                       cr.modified_by   = NVL(V('APP_USER'), USER)
        WHEN NOT MATCHED THEN
            INSERT (permit_id, checklist_item_id, response, company_id, created_by)
            VALUES (p_permit_id, src.checklist_item_id, src.response, l_company_id,
                     NVL(V('APP_USER'), USER));

        -- Stage-location logging, moved here from ptw_lv_control_measures_
        -- stage_loc_trg. That trigger fires on ptw_lv_control_measures, the
        -- old fixed-column table this checklist refactor stopped writing
        -- to — a table trigger can't watch a table nothing writes to, so
        -- it's been permanently dormant and CONTROL_MEASURES has never
        -- appeared in permit history since this refactor shipped. Only log
        -- when the MERGE actually changed something, same "real changes
        -- only" rule the other stage triggers already follow.
        IF SQL%ROWCOUNT > 0 THEN
            INSERT INTO ptw_pro.ptw_stage_locations (
                permit_id, permit_stage, latitude, longitude,
                created_date, created_by, company_id
            ) VALUES (
                p_permit_id, 'CONTROL_MEASURES', p_latitude, p_longitude,
                SYSDATE, NVL(V('APP_USER'), USER), l_company_id
            );
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20052, 'Permit ' || p_permit_id
                || ' not found or not accessible.');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20053, 'Error saving checklist for permit '
                || p_permit_id || ': ' || SQLERRM);
    END save_checklist_responses;

END ptw_checklist_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_DRA_PKG" AS

    ---------------------------------------------------------------------------
    -- Private helpers
    ---------------------------------------------------------------------------
    FUNCTION app_user RETURN VARCHAR2 IS
    BEGIN
        RETURN UPPER(NVL(V('APP_USER'), USER));
    END app_user;

    -- Same roles as the APP_IS_ADMIN application computation.
    FUNCTION is_admin RETURN BOOLEAN IS
        l_count NUMBER;
        l_user  VARCHAR2(255) := app_user;   -- private functions can't be used inside SQL
    BEGIN
        SELECT COUNT(*)
        INTO   l_count
        FROM   ptw_pro.ptw_lv_user_roles_v
        WHERE  UPPER(username) = l_user
        AND    role_name IN ('ADMIN', 'ADMIN_CONTRACT_SUPPORT')
        AND    is_active = 'Y';
        RETURN l_count > 0;
    END is_admin;

    -- Locks the row and returns status + creator. Raises if not found
    -- (VPD hides other companies' rows, so "not found" covers both).
    PROCEDURE get_dra_for_update(
        p_dra_id     IN  ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_status     OUT ptw_pro.ptw_lv_dra_assessments.workflow_status%TYPE,
        p_created_by OUT ptw_pro.ptw_lv_dra_assessments.created_by%TYPE
    ) IS
    BEGIN
        SELECT workflow_status, created_by
        INTO   p_status, p_created_by
        FROM   ptw_pro.ptw_lv_dra_assessments
        WHERE  dra_id = p_dra_id
        FOR UPDATE;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20070, 'DRA ' || p_dra_id || ' not found or not accessible.');
    END get_dra_for_update;

    PROCEDURE assert_can_edit(
        p_dra_id IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE
    ) IS
        l_status     ptw_pro.ptw_lv_dra_assessments.workflow_status%TYPE;
        l_created_by ptw_pro.ptw_lv_dra_assessments.created_by%TYPE;
    BEGIN
        get_dra_for_update(p_dra_id, l_status, l_created_by);
        IF l_status <> 'DRAFT' THEN
            RAISE_APPLICATION_ERROR(-20069, 'This DRA is ' || l_status || ' and can no longer be edited.');
        END IF;
        IF UPPER(l_created_by) <> app_user AND NOT is_admin THEN
            RAISE_APPLICATION_ERROR(-20084, 'Only the person who started this DRA can change it.');
        END IF;
    END assert_can_edit;

    ---------------------------------------------------------------------------
    -- save_dra_header
    ---------------------------------------------------------------------------
    PROCEDURE save_dra_header(
        p_dra_id              IN OUT ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_dra_type            IN     ptw_pro.ptw_lv_dra_assessments.dra_type%TYPE,
        p_workflow_status     IN     ptw_pro.ptw_lv_dra_assessments.workflow_status%TYPE,
        p_site_id             IN     ptw_pro.ptw_lv_dra_assessments.site_id%TYPE,
        p_site_details        IN     ptw_pro.ptw_lv_dra_assessments.site_details%TYPE,
        p_job_number          IN     ptw_pro.ptw_lv_dra_assessments.job_number%TYPE,
        p_engineer_name       IN     ptw_pro.ptw_lv_dra_assessments.engineer_name%TYPE,
        p_supervising_company IN     ptw_pro.ptw_lv_dra_assessments.supervising_company%TYPE,
        p_permit_id           IN     ptw_pro.ptw_lv_dra_assessments.permit_id%TYPE,
        p_latitude            IN     NUMBER,
        p_longitude           IN     NUMBER,
        p_dra_number          OUT    ptw_pro.ptw_lv_dra_assessments.dra_number%TYPE,
        p_saved               OUT    BOOLEAN,
        p_message             OUT    VARCHAR2
    ) IS
        l_supervising ptw_pro.ptw_lv_dra_assessments.supervising_company%TYPE;
    BEGIN
        p_saved := FALSE;

        IF NVL(p_dra_type, 'x') NOT IN ('ENGINEER', 'SUBCONTRACTOR') THEN
            p_message := 'Choose the type of DRA.';
            RETURN;
        END IF;
        IF TRIM(p_site_details) IS NULL THEN
            p_message := 'Task and Work Location Details is required.';
            RETURN;
        END IF;
        IF TRIM(p_engineer_name) IS NULL THEN
            p_message := 'Engineer name is required.';
            RETURN;
        END IF;

        -- Subcontractor company only applies to a Subcontractor DRA.
        l_supervising := CASE WHEN p_dra_type = 'SUBCONTRACTOR' THEN p_supervising_company END;

        IF p_dra_id IS NULL THEN
            INSERT INTO ptw_pro.ptw_lv_dra_assessments (
                dra_type, site_id, site_details, job_number, engineer_name,
                supervising_company, permit_id, started_latitude, started_longitude
            ) VALUES (
                p_dra_type, p_site_id, p_site_details, p_job_number, p_engineer_name,
                l_supervising, p_permit_id, p_latitude, p_longitude
            ) RETURNING dra_id, dra_number
              INTO p_dra_id, p_dra_number;

            p_saved   := TRUE;
            p_message := 'DRA ' || p_dra_number || ' created.';
        ELSE
            assert_can_edit(p_dra_id);   -- status from the table, not the page

            UPDATE ptw_pro.ptw_lv_dra_assessments
            SET    site_id             = p_site_id,     -- dra_type is fixed after creation
                   site_details        = p_site_details,
                   job_number          = p_job_number,
                   engineer_name       = p_engineer_name,
                   supervising_company = CASE WHEN dra_type = 'SUBCONTRACTOR'
                                              THEN p_supervising_company END,
                   permit_id           = p_permit_id
            WHERE  dra_id = p_dra_id
            RETURNING dra_number INTO p_dra_number;

            p_saved   := TRUE;
            p_message := 'DRA ' || p_dra_number || ' saved.';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_saved   := FALSE;
            p_message := REGEXP_REPLACE(SQLERRM, '^ORA-\d+: ');
    END save_dra_header;

    ---------------------------------------------------------------------------
    -- get_dra_json (unchanged)
    ---------------------------------------------------------------------------
    FUNCTION get_dra_json(p_dra_id IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE)
        RETURN CLOB
    IS
        l_exists PLS_INTEGER;
        l_clob   CLOB;
    BEGIN
        SELECT 1 INTO l_exists
        FROM   ptw_pro.ptw_lv_dra_assessments
        WHERE  dra_id = p_dra_id;

        apex_json.initialize_clob_output;
        apex_json.open_array;

        FOR r IN (
            SELECT di.dra_item_id, di.item_code, di.section_code,
                   di.category_no, di.category_label, di.item_seq,
                   di.question_text, di.response_type, dr.response
            FROM   ptw_pro.ptw_dra_items di
            LEFT JOIN ptw_pro.ptw_dra_responses dr
                   ON dr.dra_item_id = di.dra_item_id
                  AND dr.dra_id = p_dra_id
            WHERE  di.is_active = 'Y'
            ORDER BY DECODE(di.section_code, 'STAGE1', 1, 'HAZARDS', 2, 'CONTROLS', 3),
                     di.item_seq
        ) LOOP
            apex_json.open_object;
            apex_json.write('dra_item_id', r.dra_item_id);
            apex_json.write('item_code', r.item_code);
            apex_json.write('section', r.section_code);
            apex_json.write('category_no', r.category_no);
            apex_json.write('category_label', r.category_label);
            apex_json.write('seq', r.item_seq);
            apex_json.write('question', r.question_text);
            apex_json.write('response_type', r.response_type);
            apex_json.write('response', r.response);
            apex_json.close_object;
        END LOOP;

        apex_json.close_array;
        l_clob := apex_json.get_clob_output;
        apex_json.free_output;
        RETURN l_clob;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            apex_json.free_output;
            RETURN '[]';
        WHEN OTHERS THEN
            apex_json.free_output;
            RAISE_APPLICATION_ERROR(-20068, 'Error loading DRA ' || p_dra_id || ': ' || SQLERRM);
    END get_dra_json;

    ---------------------------------------------------------------------------
    -- save_dra_responses
    ---------------------------------------------------------------------------
    PROCEDURE save_dra_responses(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_json      IN CLOB
    )
    IS
        l_company_id ptw_pro.ptw_lv_dra_assessments.company_id%TYPE;
        l_user       VARCHAR2(255) := app_user;   -- private functions can't be used inside SQL
    BEGIN
        assert_can_edit(p_dra_id);

        SELECT company_id INTO l_company_id
        FROM   ptw_pro.ptw_lv_dra_assessments
        WHERE  dra_id = p_dra_id;

        IF p_json IS NULL THEN
            RETURN;   -- nothing posted (e.g. page loaded read-only)
        END IF;

        MERGE INTO ptw_pro.ptw_dra_responses dr
        USING (
            SELECT jt.dra_item_id, jt.response
            FROM   JSON_TABLE(
                       p_json, '$[*]'
                       COLUMNS (
                           dra_item_id NUMBER      PATH '$.dra_item_id',
                           response    VARCHAR2(3) PATH '$.response'
                       )
                   ) jt
            WHERE  jt.response IS NOT NULL
        ) src
        ON (dr.dra_id = p_dra_id AND dr.dra_item_id = src.dra_item_id)
        WHEN MATCHED THEN
            UPDATE SET dr.response      = src.response,
                       dr.modified_date = CURRENT_TIMESTAMP,
                       dr.modified_by   = l_user
        WHEN NOT MATCHED THEN
            INSERT (dra_id, dra_item_id, response, company_id, created_by)
            VALUES (p_dra_id, src.dra_item_id, src.response, l_company_id, l_user);

        -- A TICK item left out of the payload was unticked - remove it.
        DELETE FROM ptw_pro.ptw_dra_responses dr
        WHERE  dr.dra_id = p_dra_id
        AND    dr.dra_item_id IN (
                   SELECT dra_item_id FROM ptw_pro.ptw_dra_items WHERE response_type = 'TICK'
               )
        AND    dr.dra_item_id NOT IN (
                   SELECT jt.dra_item_id
                   FROM   JSON_TABLE(
                              p_json, '$[*]'
                              COLUMNS (dra_item_id NUMBER PATH '$.dra_item_id')
                          ) jt
                   WHERE  jt.dra_item_id IS NOT NULL
               );

    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE BETWEEN -20099 AND -20060 THEN
                RAISE;
            END IF;
            RAISE_APPLICATION_ERROR(-20071, 'Error saving DRA responses: ' || SQLERRM);
    END save_dra_responses;

    ---------------------------------------------------------------------------
    -- save_dra_details (NEW)
    ---------------------------------------------------------------------------
    PROCEDURE save_dra_details(
        p_dra_id          IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_hazard_details  IN ptw_pro.ptw_lv_dra_assessments.hazard_details%TYPE,
        p_control_details IN ptw_pro.ptw_lv_dra_assessments.control_details%TYPE
    ) IS
    BEGIN
        assert_can_edit(p_dra_id);

        UPDATE ptw_pro.ptw_lv_dra_assessments
        SET    hazard_details  = TRIM(p_hazard_details),
               control_details = TRIM(p_control_details)
        WHERE  dra_id = p_dra_id;
    END save_dra_details;

    ---------------------------------------------------------------------------
    -- complete_dra
    ---------------------------------------------------------------------------
    PROCEDURE complete_dra(
        p_dra_id            IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_can_proceed       IN ptw_pro.ptw_lv_dra_assessments.stage3_can_proceed%TYPE,
        p_no_reason         IN ptw_pro.ptw_lv_dra_assessments.stage3_no_reason%TYPE DEFAULT NULL,
        p_signature_name    IN ptw_pro.ptw_lv_dra_assessments.signature_person_name%TYPE,
        p_signature_b64     IN CLOB,
        p_latitude          IN NUMBER DEFAULT NULL,
        p_longitude         IN NUMBER DEFAULT NULL
    )
    IS
        l_status         ptw_pro.ptw_lv_dra_assessments.workflow_status%TYPE;
        l_created_by     ptw_pro.ptw_lv_dra_assessments.created_by%TYPE;
        l_unanswered     PLS_INTEGER;
        l_hazards        PLS_INTEGER;
        l_controls       PLS_INTEGER;
        l_hazard_txt     ptw_pro.ptw_lv_dra_assessments.hazard_details%TYPE;
        l_control_txt    ptw_pro.ptw_lv_dra_assessments.control_details%TYPE;
    BEGIN
        get_dra_for_update(p_dra_id, l_status, l_created_by);

        IF l_status <> 'DRAFT' THEN
            RAISE_APPLICATION_ERROR(-20072, 'This DRA is ' || l_status || ' and cannot be completed again.');
        END IF;
        IF UPPER(l_created_by) <> app_user THEN
            RAISE_APPLICATION_ERROR(-20085,
                'Only the person who carried out this DRA can sign it off.');
        END IF;
        IF NVL(p_can_proceed, 'x') NOT IN ('YES','NO') THEN
            RAISE_APPLICATION_ERROR(-20073, 'Please answer the Stage 3 question.');
        END IF;
        IF p_can_proceed = 'NO' AND TRIM(p_no_reason) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20074, 'Please record your reasons - work must not proceed.');
        END IF;
        IF TRIM(p_signature_name) IS NULL OR p_signature_b64 IS NULL THEN
            RAISE_APPLICATION_ERROR(-20075, 'A signature is required to complete this DRA.');
        END IF;

        SELECT COUNT(*)
        INTO   l_unanswered
        FROM   ptw_pro.ptw_dra_items di
        LEFT JOIN ptw_pro.ptw_dra_responses dr
               ON dr.dra_item_id = di.dra_item_id AND dr.dra_id = p_dra_id
        WHERE  di.section_code = 'STAGE1'
        AND    di.is_active = 'Y'
        AND    dr.response IS NULL;

        IF l_unanswered > 0 THEN
            RAISE_APPLICATION_ERROR(-20076,
                l_unanswered || ' Stage 1 question(s) still need an answer.');
        END IF;

        SELECT COUNT(CASE WHEN di.section_code = 'HAZARDS'  THEN 1 END),
               COUNT(CASE WHEN di.section_code = 'CONTROLS' THEN 1 END)
        INTO   l_hazards, l_controls
        FROM   ptw_pro.ptw_dra_responses dr
        JOIN   ptw_pro.ptw_dra_items di ON di.dra_item_id = dr.dra_item_id
        WHERE  dr.dra_id = p_dra_id
        AND    dr.response = 'Y';

        SELECT hazard_details, control_details
        INTO   l_hazard_txt, l_control_txt
        FROM   ptw_pro.ptw_lv_dra_assessments
        WHERE  dra_id = p_dra_id;

        IF l_hazards = 0 AND TRIM(l_hazard_txt) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20086, 'Identify at least one hazard (Stage 2A).');
        END IF;
        IF l_controls = 0 AND TRIM(l_control_txt) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20087, 'Identify at least one control measure (Stage 2B).');
        END IF;

        UPDATE ptw_pro.ptw_lv_dra_assessments
        SET    stage3_can_proceed    = p_can_proceed,
               stage3_no_reason      = CASE WHEN p_can_proceed = 'NO' THEN TRIM(p_no_reason) END,
               signature_person_name = TRIM(p_signature_name),
               signature             = apex_web_service.clobbase642blob(
                                           REGEXP_REPLACE(p_signature_b64, '^data:image/[^;]+;base64,', '')),
               signed_datetime       = SYSDATE,
               signature_latitude    = p_latitude,
               signature_longitude   = p_longitude,
               workflow_status       = 'COMPLETED'
        WHERE  dra_id = p_dra_id;

    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE BETWEEN -20099 AND -20060 THEN
                RAISE;
            END IF;
            RAISE_APPLICATION_ERROR(-20078, 'Error completing DRA: ' || SQLERRM);
    END complete_dra;

    ---------------------------------------------------------------------------
    -- cancel_dra
    ---------------------------------------------------------------------------
    PROCEDURE cancel_dra(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_reason    IN ptw_pro.ptw_lv_dra_assessments.cancel_reason%TYPE
    )
    IS
        l_status     ptw_pro.ptw_lv_dra_assessments.workflow_status%TYPE;
        l_created_by ptw_pro.ptw_lv_dra_assessments.created_by%TYPE;
    BEGIN
        get_dra_for_update(p_dra_id, l_status, l_created_by);

        IF l_status <> 'DRAFT' THEN
            RAISE_APPLICATION_ERROR(-20079, 'Only a Draft DRA can be cancelled.');
        END IF;
        IF UPPER(l_created_by) <> app_user AND NOT is_admin THEN
            RAISE_APPLICATION_ERROR(-20088, 'Only the person who started this DRA, or an admin, can cancel it.');
        END IF;
        IF TRIM(p_reason) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20080, 'Please give a reason for cancelling this DRA.');
        END IF;

        UPDATE ptw_pro.ptw_lv_dra_assessments
        SET    workflow_status = 'CANCELLED',
               cancel_reason   = TRIM(p_reason),
               cancel_datetime = SYSDATE
        WHERE  dra_id = p_dra_id;

    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE BETWEEN -20099 AND -20060 THEN
                RAISE;
            END IF;
            RAISE_APPLICATION_ERROR(-20082, 'Error cancelling DRA: ' || SQLERRM);
    END cancel_dra;

    ---------------------------------------------------------------------------
    -- Permit link (Page 9 gate)
    ---------------------------------------------------------------------------
    FUNCTION can_use_for_permit(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    ) RETURN VARCHAR2 IS
        l_count NUMBER;
    BEGIN
        SELECT COUNT(*)
        INTO   l_count
        FROM   ptw_pro.ptw_lv_dra_assessments
        WHERE  dra_id             = p_dra_id
        AND    workflow_status    = 'COMPLETED'
        AND    stage3_can_proceed = 'YES'
        AND    (permit_id IS NULL OR permit_id = p_permit_id);
        RETURN CASE WHEN l_count > 0 THEN 'Y' ELSE 'N' END;
    END can_use_for_permit;

    PROCEDURE link_to_permit(
        p_dra_id    IN ptw_pro.ptw_lv_dra_assessments.dra_id%TYPE,
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE
    ) IS
    BEGIN
        IF can_use_for_permit(p_dra_id, p_permit_id) = 'N' THEN
            RAISE_APPLICATION_ERROR(-20089,
                'That DRA cannot be used: it must be completed, say work can proceed, '
                || 'and not already belong to another permit.');
        END IF;

        -- Bypasses the DRAFT-only edit rule deliberately: linking a
        -- completed DRA to the permit it was done for is not an edit
        -- of the assessment itself.
        UPDATE ptw_pro.ptw_lv_dra_assessments
        SET    permit_id = p_permit_id
        WHERE  dra_id    = p_dra_id;
    END link_to_permit;

END ptw_dra_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_GEOCODE_PKG" AS

    FUNCTION get_place_name(
        p_latitude  IN NUMBER,
        p_longitude IN NUMBER
    ) RETURN VARCHAR2
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;

        l_lat        NUMBER(9,4);
        l_lng        NUMBER(9,4);
        l_place      VARCHAR2(500);
        l_response   CLOB;

    BEGIN
        IF p_latitude IS NULL OR p_longitude IS NULL THEN
            RETURN NULL;
        END IF;

        l_lat := ROUND(p_latitude, 4);
        l_lng := ROUND(p_longitude, 4);

        -- Cache check
        BEGIN
            SELECT place_name INTO l_place
            FROM   ptw_pro.ptw_geocode_cache
            WHERE  latitude = l_lat
            AND    longitude = l_lng;

            RETURN l_place;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                NULL; -- fall through to the live lookup below
        END;

        -- Live lookup — OpenStreetMap Nominatim. User-Agent is required by
        -- Nominatim's usage policy; update the contact address if this ever
        -- moves to a different domain/team.
        --
        -- MAKE_REST_REQUEST has no header parameters of its own - custom
        -- headers must be set via SET_REQUEST_HEADERS first, which applies
        -- to whatever MAKE_REST_REQUEST call follows it. p_reset defaults
        -- to TRUE, which clears any headers left over from a previous call
        -- in this session - exactly what you want here, so a stale header
        -- from an unrelated web service call earlier in the same session
        -- can't leak into this request.
        BEGIN
            apex_web_service.set_request_headers(
                p_name_01  => 'User-Agent',
                p_value_01 => 'PTW-PRO PermitApp/1.0 (safety@yourcompany.com)'
            );

            l_response := apex_web_service.make_rest_request(
                p_url         => 'https://nominatim.openstreetmap.org/reverse'
                                  || '?format=jsonv2&lat=' || l_lat
                                  || '&lon=' || l_lng,
                p_http_method => 'GET'
            );

            SELECT jt.display_name
            INTO   l_place
            FROM   JSON_TABLE(l_response, '$'
                       COLUMNS (display_name VARCHAR2(500) PATH '$.display_name')
                   ) jt;

        EXCEPTION
            WHEN OTHERS THEN
                -- Bad coordinates, network failure, rate limit, malformed
                -- response, no display_name in the payload — all treated
                -- the same: no place name this time, nothing cached, try
                -- again on the next request rather than caching a failure.
                RETURN NULL;
        END;

        IF l_place IS NOT NULL THEN
            BEGIN
                INSERT INTO ptw_pro.ptw_geocode_cache (latitude, longitude, place_name)
                VALUES (l_lat, l_lng, l_place);
                COMMIT;
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    -- Another session cached this exact rounded coordinate
                    -- pair between our SELECT and our INSERT — harmless,
                    -- our result is still correct to return either way.
                    NULL;
            END;
        END IF;

        RETURN l_place;

    END get_place_name;

END ptw_geocode_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_MONITORING_PKG" AS

    PROCEDURE save_check(
        p_monitoring_id IN ptw_pro.ptw_lv_monitoring.monitoring_id%TYPE,
        p_check_seq     IN ptw_pro.ptw_monitoring_checks.check_seq%TYPE,
        p_detail        IN ptw_pro.ptw_monitoring_checks.detail%TYPE,
        p_check_time    IN ptw_pro.ptw_monitoring_checks.check_time%TYPE,
        p_in_order      IN ptw_pro.ptw_monitoring_checks.in_order%TYPE,
        p_comments      IN ptw_pro.ptw_monitoring_checks.comments%TYPE DEFAULT NULL
    ) IS
        l_company_id ptw_pro.ptw_lv_monitoring.company_id%TYPE;
    BEGIN
        SELECT company_id INTO l_company_id
        FROM   ptw_pro.ptw_lv_monitoring
        WHERE  monitoring_id = p_monitoring_id;

        MERGE INTO ptw_pro.ptw_monitoring_checks mc
        USING (SELECT p_monitoring_id AS monitoring_id, p_check_seq AS check_seq FROM dual) src
        ON (mc.monitoring_id = src.monitoring_id AND mc.check_seq = src.check_seq)
        WHEN MATCHED THEN
            UPDATE SET detail        = p_detail,
                       check_time    = p_check_time,
                       in_order      = p_in_order,
                       comments      = p_comments,
                       modified_date = CURRENT_TIMESTAMP,
                       modified_by   = NVL(V('APP_USER'), USER)
        WHEN NOT MATCHED THEN
            INSERT (monitoring_id, check_seq, detail, check_time, in_order,
                    comments, company_id, created_by)
            VALUES (p_monitoring_id, p_check_seq, p_detail, p_check_time, p_in_order,
                    p_comments, l_company_id, NVL(V('APP_USER'), USER));

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20070, 'Monitoring record ' || p_monitoring_id
                || ' not found or not accessible.');
        WHEN OTHERS THEN
            IF SQLCODE = -20070 THEN
                RAISE;
            END IF;
            RAISE_APPLICATION_ERROR(-20071, 'Error saving check ' || p_check_seq
                || ' for monitoring ' || p_monitoring_id || ': ' || SQLERRM);
    END save_check;

END ptw_monitoring_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_PDF_LIB_PKG" AS

    --------------------------------------------------------------------------
    -- FORMATTING HELPERS
    --------------------------------------------------------------------------

    FUNCTION safe_val (p_text VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN NVL(REPLACE(REPLACE(SUBSTR(p_text, 1, 4000), '<', '&lt;'), '>', '&gt;'), '-');
    END;

    FUNCTION safe_num (p_num NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN NVL(TO_CHAR(p_num), '-');
    END;

    FUNCTION get_yn (p_value VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE p_value
            WHEN 'Y'  THEN '<span class="status-badge status-yes">Yes</span>'
            WHEN 'N'  THEN '<span class="status-badge status-no">No</span>'
            WHEN 'NA' THEN '<span class="status-badge status-na">N/A</span>'
            ELSE '-'
        END;
    END;

    FUNCTION get_yn_label (p_value VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE p_value
            WHEN 'Y' THEN 'completed'
            WHEN 'N' THEN 'not complete'
            ELSE '(not recorded)'
        END;
    END;

    FUNCTION get_safe_label (p_value VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE p_value
            WHEN 'Y' THEN 'safe'
            WHEN 'N' THEN 'not safe'
            ELSE '(not recorded)'
        END;
    END;

    FUNCTION get_checked (p_value VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE WHEN p_value = 'Y' THEN '&#9745;' ELSE '&#9744;' END;
    END;

    FUNCTION get_cm_tick (p_value VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE p_value WHEN 'Y'  THEN '<span class="tick-mark">&#10003;</span>' ELSE '' END;
    END;

    FUNCTION get_cm_na (p_value VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE p_value WHEN 'NA' THEN '<span class="na-mark">N/A</span>' ELSE '' END;
    END;

    FUNCTION get_cm_no (p_value VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE p_value WHEN 'N'  THEN '<span class="no-mark">&#10007;</span>' ELSE '' END;
    END;

    FUNCTION fmt_datetime (p_date DATE) RETURN VARCHAR2 IS
    BEGIN
        RETURN NVL(TO_CHAR(p_date, 'DD-MON-YYYY HH24:MI'), '-');
    END;

    FUNCTION fmt_date (p_date DATE) RETURN VARCHAR2 IS
    BEGIN
        RETURN NVL(TO_CHAR(p_date, 'DD-MON-YYYY'), '-');
    END;

    FUNCTION get_signature_img (p_blob BLOB) RETURN CLOB IS
        v_base64 CLOB;
        v_result CLOB;
    BEGIN
        IF p_blob IS NULL OR DBMS_LOB.GETLENGTH(p_blob) = 0 THEN
            RETURN TO_CLOB('<p style="color:#999;font-style:italic;text-align:center;'
                        || 'margin:0;padding:15px 0;">No signature captured</p>');
        END IF;
        BEGIN
            v_base64 := APEX_WEB_SERVICE.BLOB2CLOBBASE64(p_blob);
            v_result := TO_CLOB('<img src="data:image/png;base64,');
            DBMS_LOB.APPEND(v_result, v_base64);
            DBMS_LOB.APPEND(v_result, TO_CLOB('" class="signature-image" alt="Signature" />'));
            RETURN v_result;
        EXCEPTION
            WHEN OTHERS THEN
                DECLARE
                    v_chunk    VARCHAR2(32767);
                    v_pos      NUMBER := 1;
                    v_length   NUMBER := DBMS_LOB.GETLENGTH(p_blob);
                    v_chunk_sz NUMBER := 12000;
                BEGIN
                    v_result := TO_CLOB('<img src="data:image/png;base64,');
                    WHILE v_pos <= v_length LOOP
                        v_chunk := UTL_RAW.CAST_TO_VARCHAR2(
                            UTL_ENCODE.BASE64_ENCODE(
                                DBMS_LOB.SUBSTR(p_blob, LEAST(v_chunk_sz, v_length - v_pos + 1), v_pos)
                            )
                        );
                        v_chunk := REPLACE(REPLACE(v_chunk, CHR(10), ''), CHR(13), '');
                        DBMS_LOB.APPEND(v_result, TO_CLOB(v_chunk));
                        v_pos := v_pos + v_chunk_sz;
                    END LOOP;
                    DBMS_LOB.APPEND(v_result, TO_CLOB('" class="signature-image" alt="Signature" />'));
                    RETURN v_result;
                END;
        END;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN TO_CLOB('<p style="color:#c0392b;font-style:italic;text-align:center;'
                        || 'margin:0;font-size:8pt;">Error loading signature</p>');
    END;

    --------------------------------------------------------------------------
    -- DOCUMENT CHROME
    --------------------------------------------------------------------------

    FUNCTION get_document_head (p_document_title VARCHAR2, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB IS
        -- Per-type theme colours, sampled directly from each source form:
        --   LV ISOLATION: pale blue-grey (BGIS form) - also used by FIRE
        --     SYSTEMS ISOLATION, another BGIS-format form (falls into the
        --     ELSE branch - no separate CASE needed, same source brand).
        --   WORKING AT HEIGHT: pale mint (Vantage form)
        --   GENERAL: plain white/grey (Smart form has no wash)
        -- All three real forms use dark text on white/pale sections, never
        -- white-on-solid-colour bars - so header/section text is dark here
        -- too, not the previous white-on-navy treatment.
        --
        -- v_page_bg was previously used as a saturated full-page wash
        -- behind the document (e.g. #789abd, a fairly strong blue) - on a
        -- printed/PDF page that reads as a loud app-generated background
        -- rather than an official form, so it's now only used for border/
        -- accent colour, not filled behind the whole page. The page
        -- background itself is a single, muted neutral grey for every
        -- type - closer to what an actual printed form sits on.
        v_page_bg    VARCHAR2(10);   -- border/accent colour (was: page wash fill)
        v_tint       VARCHAR2(10);   -- pale fill for section/table headers
        v_accent     VARCHAR2(10);   -- stronger accent for the declaration-box stripe
        v_text       VARCHAR2(10) := '#1a1a1a';
        c_page_bg    CONSTANT VARCHAR2(10) := '#eef0f2'; -- neutral, same for every type
    BEGIN
        CASE p_ptw_type
            WHEN 'WORKING AT HEIGHT' THEN
                v_page_bg := '#c9ece5';
                v_tint    := '#e7f6f3';
                v_accent  := '#5fa89c'; -- page wash alone is too pale to read as a border stripe
            WHEN 'GENERAL' THEN
                v_page_bg := '#ffffff';
                v_tint    := '#f0f0f0';
                v_accent  := '#444444'; -- no wash colour exists to reuse; real form's rules are plain dark grey/black
            ELSE -- LV ISOLATION / FIRE SYSTEMS ISOLATION (default - both BGIS-format forms)
                v_page_bg := '#789abd';
                v_tint    := '#c9d7e5';
                v_accent  := v_page_bg;
        END CASE;

        RETURN '<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>' || safe_val(p_document_title) || '</title>
<style>
    @page { size: A4; margin: 12mm; }
    body {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 9pt; color: #333; margin: 0; padding: 0;
        background: ' || c_page_bg || ';
    }
    .ptw-lv-report-container {
        max-width: 780px; margin: 0 auto; background: #fff;
        border: 1px solid #aab4bf;
    }

    .ptw-lv-header {
        background: ' || v_tint || '; color: ' || v_text || ';
        padding: 12px 16px;
        border-bottom: 2px solid ' || v_page_bg || ';
    }
    .ptw-lv-header h1 {
        margin: 0 0 6px 0; font-size: 13pt;
        letter-spacing: 0.5px; text-transform: uppercase;
    }
    .header-refs {
        display: flex; gap: 10px; font-size: 8pt;
        border-top: 1px solid rgba(0,0,0,0.25);
        padding-top: 6px; margin-top: 4px;
    }
    .header-refs div { flex: 1; }

    .ptw-lv-section { border: 1px solid #99a4b0; border-top: none; }
    .ptw-lv-section-title {
        background: ' || v_tint || '; color: ' || v_text || ';
        padding: 5px 12px; font-weight: 700; font-size: 8.5pt;
        text-transform: uppercase; letter-spacing: 0.3px;
        border-bottom: 1px solid #99a4b0;
    }
    .ptw-lv-section-subtitle {
        background: ' || v_tint || '; color: ' || v_text || ';
        padding: 4px 12px; font-weight: 700; font-size: 8pt;
        border-bottom: 1px solid #99a4b0;
    }

    .ptw-lv-row {
        display: flex; padding: 4px 12px;
        border-bottom: 1px solid #d7dce2; font-size: 8.5pt;
        align-items: flex-start;
    }
    .ptw-lv-row:last-child { border-bottom: none; }
    .ptw-lv-label { width: 42%; font-weight: 600; color: #333; padding-right: 8px; }
    .ptw-lv-value { width: 58%; }

    /* Bordered 2-field-pair grid - matches the layout used on the source
       paper form itself (e.g. "Site details..." | value | "Name of person..."
       | value, all four cells fully bordered). Used by
       GET_SITE_WORK_DETAILS_HTML and, in FIRE SYSTEMS ISOLATION, the
       Client Permission section - not a drop-in replacement for
       .ptw-lv-row everywhere, just where the source form itself uses a
       real grid rather than a single-column list of questions. */
    .ptw-lv-detail-grid { width: 100%; border-collapse: collapse; font-size: 8.5pt; table-layout: fixed; }
    .ptw-lv-detail-grid td {
        border: 1px solid #99a4b0; padding: 5px 10px; vertical-align: top;
    }
    .ptw-lv-detail-grid td.g-label {
        background: ' || v_tint || '; color: ' || v_text || ';
        font-weight: 700; width: 23%;
    }
    .ptw-lv-detail-grid td.g-value { width: 27%; }
    .ptw-lv-detail-grid td.g-value-wide { width: 77%; }
    .ptw-lv-detail-grid td.g-label-wide { width: 23%; }

    .ptw-lv-table { width: 100%; border-collapse: collapse; font-size: 8.5pt; }
    .ptw-lv-table th {
        background: ' || v_tint || '; color: ' || v_text || ';
        padding: 5px 8px; text-align: left; font-weight: 700;
        border: 1px solid #c0c0c0; font-size: 8pt;
    }
    .ptw-lv-table td {
        padding: 4px 8px; border: 1px solid #c0c0c0; vertical-align: middle;
    }
    .cm-number { width: 28px; text-align: center; font-weight: 700; background: #f5f5f5; }
    .cm-tick   { width: 55px; text-align: center; }

    .ppe-grid { display: flex; flex-wrap: wrap; padding: 6px 12px; }
    .ppe-item { width: 50%; padding: 2px 0; font-size: 8.5pt; }

    .status-badge {
        display: inline-block; padding: 1px 7px; border-radius: 8px;
        font-size: 7.5pt; font-weight: 700;
    }
    .status-yes { background: #d4edda; color: #155724; }
    .status-no  { background: #f8d7da; color: #721c24; }
    .status-na  { background: #e2e3e5; color: #383d41; }

    .tick-mark { color: #155724; font-weight: bold; font-size: 11pt; }
    .na-mark   { color: #666; font-style: italic; font-size: 8pt; }
    .no-mark   { color: #dc3545; font-weight: 700; font-size: 11pt; }

    .declaration-box {
        padding: 7px 12px; background: #f8f9fa;
        border-left: 3px solid ' || v_accent || ';
        font-size: 8pt; line-height: 1.6; margin: 0; font-style: italic;
    }

    .signature-box {
        border: 1px solid #bbb; min-height: 55px;
        padding: 4px; text-align: center;
        background: #fff; margin: 3px 0;
    }
    .signature-image { max-width: 100%; max-height: 75px; display: block; margin: 0 auto; }

    .page-break { page-break-before: always; }

    .footer {
        border-top: 1px solid #ddd; margin-top: 6px;
        padding: 6px 12px; font-size: 7pt; color: #888; text-align: center;
    }

    .history-section { border: 1px solid #c0c0c0; border-top: none; margin-top: 0; }
    .history-section .ptw-lv-section-title { background: #e0e0e0; color: #1a1a1a; }
    .history-table { width: 100%; border-collapse: collapse; font-size: 8.5pt; }
    .history-table th {
        background: #e8e8e8; color: #1a1a1a;
        padding: 5px 8px; text-align: left; font-weight: 700;
        border: 1px solid #c0c0c0; font-size: 8pt;
    }
    .history-table td {
        padding: 5px 8px; border: 1px solid #c0c0c0; vertical-align: middle;
    }
    .history-table tr:nth-child(even) td { background: #f7f9fc; }
    .history-step-badge {
        display: inline-block; background: #555; color: #fff;
        padding: 2px 8px; border-radius: 10px;
        font-size: 7.5pt; font-weight: 700; white-space: nowrap;
    }
    .history-no-data {
        padding: 12px; font-style: italic; color: #888;
        font-size: 8pt; text-align: center;
    }

    @media print {
        body { font-size: 8pt; }
        .ptw-lv-section { page-break-inside: avoid; }
        .history-section { page-break-inside: avoid; }
        /* Long table sections (Control Measures, PPE, Equipment Isolation,
           Monitoring) are allowed to split across a page boundary instead
           of being pushed whole onto the next page, avoiding the large
           blank gap that "avoid" causes when a tall section does not fit in
           the remaining space. Table rows paginate cleanly on their own. */
        .ptw-lv-section.section-flow { page-break-inside: auto; }
        .ptw-lv-table thead { display: table-header-group; }
    }
</style>
</head>
<body>
<div class="ptw-lv-report-container">';
    END get_document_head;

    FUNCTION get_document_close RETURN CLOB IS
    BEGIN
        RETURN '</div></body></html>';
    END get_document_close;

    FUNCTION get_company_logo_b64 (p_company_id NUMBER) RETURN CLOB IS
        v_logo_blob BLOB;
        v_logo_b64  CLOB;
    BEGIN
        SELECT file_content
        INTO   v_logo_blob
        FROM   apex_application_static_files
        WHERE  application_id = (
                SELECT application_id FROM apex_applications WHERE alias = 'PTW-PRO'
            )
        AND    file_name = 'logo_' || p_company_id || '.png';

        v_logo_b64 := apex_web_service.blob2clobbase64(v_logo_blob);
        RETURN REPLACE(REPLACE(v_logo_b64, CHR(10), ''), CHR(13), '');
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL; -- no logo for this company - render PDF without one
    END get_company_logo_b64;

    FUNCTION type_has_monitoring (p_ptw_type VARCHAR2) RETURN VARCHAR2 IS
        l_has_monitoring ptw_pro.ptw_types.has_monitoring%TYPE;
    BEGIN
        SELECT has_monitoring INTO l_has_monitoring
        FROM   ptw_pro.ptw_types
        WHERE  ptw_type = p_ptw_type;
        RETURN NVL(l_has_monitoring, 'Y');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 'Y'; -- unrecognised type - fail open, don't hide a section that should show
    END type_has_monitoring;

    --------------------------------------------------------------------------
    -- SECTIONS IDENTICAL ACROSS PERMIT TYPES
    --------------------------------------------------------------------------

    FUNCTION get_site_work_details_html (p_permit_id NUMBER) RETURN CLOB IS
        v_area_of_works     ptw_pro.ptw_lv_permits.area_of_works%TYPE;
        v_work_description  ptw_pro.ptw_lv_permits.work_description%TYPE;
        v_pic_name          ptw_pro.ptw_lv_permits.person_in_charge_name%TYPE;
        v_company           ptw_pro.ptw_lv_permits.supervising_company%TYPE;
        v_other_persons     ptw_pro.ptw_lv_permits.other_persons_count%TYPE;
        v_site_id           ptw_pro.ptw_lv_permits.site_id%TYPE;
        v_site_details_txt  ptw_pro.ptw_lv_permits.site_details%TYPE;
        v_site_name         VARCHAR2(500);
    BEGIN
        SELECT area_of_works, work_description, person_in_charge_name,
               supervising_company, other_persons_count, site_id, site_details
        INTO   v_area_of_works, v_work_description, v_pic_name,
               v_company, v_other_persons, v_site_id, v_site_details_txt
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;

        BEGIN
            SELECT site_name INTO v_site_name
            FROM   ptw_pro.ptw_lv_sites WHERE site_id = v_site_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN v_site_name := v_site_details_txt;
        END;

        -- Rendered as a bordered 2-field-pair grid, matching the source
        -- form's own table layout - and, on the source form, "Name of
        -- person" and "company responsible for supervising the works"
        -- are ONE field, not two, so that pairing is reproduced here by
        -- displaying both values in a single cell (two lines) rather
        -- than splitting the grid into a 3rd row. No schema/data change -
        -- PERSON_IN_CHARGE_NAME and SUPERVISING_COMPANY are still two
        -- separate columns underneath, just presented together here.
        RETURN '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Site &amp; Work Details</div>
        <table class="ptw-lv-detail-grid">
            <tr>
                <td class="g-label">Site details and area of works:</td>
                <td class="g-value">' || safe_val(v_site_name || ' - ' || v_area_of_works) || '</td>
                <td class="g-label">Name of person and company responsible for supervising the works:</td>
                <td class="g-value">' || safe_val(v_pic_name) ||
                    CASE WHEN v_company IS NOT NULL THEN '<br>' || safe_val(v_company) ELSE '' END || '</td>
            </tr>
            <tr>
                <td class="g-label">Description of work activity:</td>
                <td class="g-value">' || safe_val(v_work_description) || '</td>
                <td class="g-label">Number of other persons working under this Permit:</td>
                <td class="g-value">' || safe_num(v_other_persons) || '</td>
            </tr>
        </table>
    </div>';
    END get_site_work_details_html;


    FUNCTION get_control_measures_html (p_permit_id NUMBER) RETURN CLOB IS
        v_html    CLOB;
        v_row_num NUMBER := 0;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);
        v_html := '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Control Measures</div>
        <table class="ptw-lv-table">
            <thead>
                <tr>
                    <th class="cm-number">No.</th>
                    <th>Control Measure</th>
                    <th class="cm-tick">&#10003; Yes</th>
                    <th class="cm-tick">&#10007; No</th>
                    <th class="cm-tick">N/A</th>
                </tr>
            </thead>
            <tbody>';

        FOR cm_item IN (
            SELECT ci.item_seq, ci.question_text, cr.response
            FROM   ptw_pro.ptw_checklist_items ci
            JOIN   ptw_pro.ptw_lv_permits p ON p.permit_id = p_permit_id
            JOIN   ptw_pro.ptw_types t       ON t.ptw_type = p.ptw_type AND t.type_id = ci.type_id
            LEFT JOIN ptw_pro.ptw_checklist_responses cr
                   ON cr.checklist_item_id = ci.checklist_item_id AND cr.permit_id = p_permit_id
            WHERE  ci.section_code = 'CONTROL_MEASURES'
            AND    ci.is_active = 'Y'
            ORDER BY ci.item_seq
        ) LOOP
            v_row_num := v_row_num + 1;
            DBMS_LOB.APPEND(v_html, TO_CLOB('
                <tr><td class="cm-number">' || v_row_num || '</td>
                    <td>' || safe_val(cm_item.question_text) || '</td>
                    <td class="cm-tick">' || get_cm_tick(cm_item.response) || '</td>
                    <td class="cm-tick">' || get_cm_no(cm_item.response)   || '</td>
                    <td class="cm-tick">' || get_cm_na(cm_item.response)   || '</td></tr>'));
        END LOOP;

        v_html := v_html || '
            </tbody>
        </table>
    </div>';
        RETURN v_html;
    END get_control_measures_html;


    FUNCTION get_ppe_html (p_permit_id NUMBER) RETURN CLOB IS
        v_html    CLOB;
        v_ppe_col NUMBER := 0;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);
        v_html := '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Identify Essential PPE Required To Be Worn</div>
        <div style="font-size:7.5pt;color:#555;padding:4px 12px;font-style:italic;
                    border-bottom:1px solid #eee;">
            This list is not exhaustive &mdash; please refer to risk assessment.
            This Permit MUST be issued for the SHORTEST reasonable period of TIME
            (never usually longer than 12 Hours).
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:8.5pt;">';

        FOR ppe_item IN (
            SELECT ci.item_seq, ci.question_text, cr.response
            FROM   ptw_pro.ptw_checklist_items ci
            JOIN   ptw_pro.ptw_lv_permits p ON p.permit_id = p_permit_id
            JOIN   ptw_pro.ptw_types t       ON t.ptw_type = p.ptw_type AND t.type_id = ci.type_id
            LEFT JOIN ptw_pro.ptw_checklist_responses cr
                   ON cr.checklist_item_id = ci.checklist_item_id AND cr.permit_id = p_permit_id
            WHERE  ci.section_code = 'PPE'
            AND    ci.is_active = 'Y'
            ORDER BY ci.item_seq
        ) LOOP
            IF MOD(v_ppe_col, 2) = 0 THEN
                DBMS_LOB.APPEND(v_html, TO_CLOB('<tr>'));
            END IF;
            DBMS_LOB.APPEND(v_html, TO_CLOB(
                '<td style="width:50%;padding:3px 12px;">'
                || get_checked(ppe_item.response) || ' ' || safe_val(ppe_item.question_text) || '</td>'));
            IF MOD(v_ppe_col, 2) = 1 THEN
                DBMS_LOB.APPEND(v_html, TO_CLOB('</tr>'));
            END IF;
            v_ppe_col := v_ppe_col + 1;
        END LOOP;
        IF MOD(v_ppe_col, 2) = 1 THEN
            DBMS_LOB.APPEND(v_html, TO_CLOB('<td>&nbsp;</td></tr>'));
        END IF;

        v_html := v_html || '
        </table>
    </div>';
        RETURN v_html;
    END get_ppe_html;


    FUNCTION get_equipment_isolation_html (
        p_permit_id NUMBER,
        p_ptw_type  VARCHAR2 DEFAULT 'LV ISOLATION'
    ) RETURN CLOB IS
        v_html      CLOB;
        v_col1      VARCHAR2(40);
        v_col2      VARCHAR2(40);
        v_col3      VARCHAR2(40);
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

        -- Column headings only - every other type keeps the original
        -- "Equipment isolated / Means of isolation / Safety lock no."
        -- wording exactly as before.
        IF p_ptw_type = 'FIRE SYSTEMS ISOLATION' THEN
            v_col1 := 'System isolated';
            v_col2 := 'Panel';
            v_col3 := 'Safety lock nos.';
        ELSE
            v_col1 := 'Equipment isolated';
            v_col2 := 'Means of isolation';
            v_col3 := 'Safety lock no.';
        END IF;

        v_html := '
    <div class="ptw-lv-section section-flow">
        <div class="ptw-lv-section-title">Equipment Isolation</div>
        <table class="ptw-lv-table">
            <thead>
                <tr>
                    <th style="width:28px;">No.</th>
                    <th>' || v_col1 || '</th>
                    <th>' || v_col2 || '</th>
                    <th style="width:95px;">' || v_col3 || '</th>
                </tr>
            </thead>
            <tbody>';

        FOR iso IN (
            SELECT row_number, equipment_isolated, means_of_isolation, safety_lock_no
            FROM   ptw_pro.ptw_lv_equipment_isolation
            WHERE  permit_id = p_permit_id
            ORDER  BY row_number
        ) LOOP
            DBMS_LOB.APPEND(v_html, TO_CLOB('
                <tr>
                    <td style="text-align:center;font-weight:700;">' || iso.row_number || '</td>
                    <td>' || safe_val(iso.equipment_isolated) || '</td>
                    <td>' || safe_val(iso.means_of_isolation)  || '</td>
                    <td>' || safe_val(iso.safety_lock_no)      || '</td>
                </tr>'));
        END LOOP;

        FOR i IN (
            SELECT LEVEL AS rn FROM DUAL CONNECT BY LEVEL <= 4
            MINUS
            SELECT row_number FROM ptw_pro.ptw_lv_equipment_isolation WHERE permit_id = p_permit_id
        ) LOOP
            DBMS_LOB.APPEND(v_html, TO_CLOB('
                <tr>
                    <td style="text-align:center;font-weight:700;">' || i.rn || '</td>
                    <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                </tr>'));
        END LOOP;

        v_html := v_html || '
            </tbody>
        </table>
    </div>';
        RETURN v_html;
    END get_equipment_isolation_html;


    FUNCTION get_authorisation_html (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB IS
        v_auth_name    ptw_pro.ptw_signatures.person_name%TYPE;
        v_auth_sig     ptw_pro.ptw_signatures.signature_blob%TYPE;
        v_auth_mobile  ptw_pro.ptw_signatures.mobile_no%TYPE;
        v_auth_dt      ptw_pro.ptw_signatures.event_datetime%TYPE;
        v_na_company   ptw_pro.ptw_signatures.company_name%TYPE;
        v_na_lat       ptw_pro.ptw_signatures.latitude%TYPE;
        v_na_lng       ptw_pro.ptw_signatures.longitude%TYPE;
        v_fullname     VARCHAR2(200);
        v_started      DATE;
        v_ended        DATE;
        v_declaration  VARCHAR2(1000);
        v_auth_to_dt   ptw_pro.ptw_signatures.auth_to_datetime%TYPE;
    BEGIN
        ptw_pro.ptw_signature_pkg.get_signature(p_permit_id, 'AUTH',
            v_auth_name, v_auth_sig, v_auth_mobile, v_na_company, v_auth_dt, v_na_lat, v_na_lng, v_auth_to_dt);

        SELECT started_datetime, ended_datetime INTO v_started, v_ended
        FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_permit_id;

        BEGIN
            SELECT first_name || ' ' || last_name INTO v_fullname
            FROM   ptw_pro.ptw_lv_users WHERE UPPER(username) = UPPER(v_auth_name);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN v_fullname := v_auth_name;
            WHEN OTHERS THEN v_fullname := v_auth_name;
        END;

        -- Declaration text verified verbatim against each type's source form.
        -- LV Isolation and General genuinely say different things here.
        IF p_ptw_type = 'GENERAL' THEN
            v_declaration :=
                'I am satisfied that those involved in the activity are competent and a safe
                system of work, including controls, is sufficient and adequate. The
                authorising person is responsible for monitoring the work/activity to ensure,
                so far as reasonable practicable, that safe working practices are adhered to.';
        ELSE
            v_declaration :=
                'I have reviewed all aspects of the task/activity and I am satisfied with the
                arrangements as detailed within the relevant risk assessment and method statement
                that have been put in place and certify that this activity detailed is authorised
                to proceed.';
        END IF;

        RETURN '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Authorisation of this Permit to Work</div>
        <div class="declaration-box">' || v_declaration || '</div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Authorised Person:</div>
            <div class="ptw-lv-value">' || safe_val(v_fullname) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Mobile Tel No.:</div>
            <div class="ptw-lv-value">' || safe_val(v_auth_mobile) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">FROM:</div>
            <div class="ptw-lv-value">' || fmt_datetime(v_started) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">TO:</div>
            <div class="ptw-lv-value">' || fmt_datetime(v_ended) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Signature:</div>
            <div class="ptw-lv-value">
                <div class="signature-box">' || get_signature_img(v_auth_sig) || '</div>
            </div>
        </div>
    </div>';
    END get_authorisation_html;


    FUNCTION get_acceptance_html (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB IS
        v_name    ptw_pro.ptw_signatures.person_name%TYPE;
        v_sig     ptw_pro.ptw_signatures.signature_blob%TYPE;
        v_mobile  ptw_pro.ptw_signatures.mobile_no%TYPE;
        v_company ptw_pro.ptw_signatures.company_name%TYPE;
        v_dt      ptw_pro.ptw_signatures.event_datetime%TYPE;
        v_na_lat  ptw_pro.ptw_signatures.latitude%TYPE;
        v_na_lng  ptw_pro.ptw_signatures.longitude%TYPE;
        v_declaration VARCHAR2(1000);
        v_person_label VARCHAR2(100);
        v_na_auth_to_dt ptw_pro.ptw_signatures.auth_to_datetime%TYPE;
    BEGIN
        ptw_pro.ptw_signature_pkg.get_signature(p_permit_id, 'ACCEPT',
            v_name, v_sig, v_mobile, v_company, v_dt, v_na_lat, v_na_lng, v_na_auth_to_dt);

        -- General's real form labels this signatory "Competent Person" (and also
        -- has a separate "Engineer" signatory the app does not currently capture
        -- at this stage - flagging, not fabricating, that second signature).
        IF p_ptw_type = 'GENERAL' THEN
            v_declaration :=
                'I have had this document explained to me and accept responsibility for
                ensuring that each person under my control understands its conditions. I
                accept responsibility for the safety of the work, personnel and equipment. I
                confirm that all personnel are adequately trained and will access/work only
                on/in the area/job/equipment specified. This permit is not transferrable and
                must be cancelled on completion of the works.';
            v_person_label := 'Competent Person:';
        ELSE
            v_declaration :=
                'I certify that I am competent to supervise and undertake the works detailed within
                this Permit to Work and have read and fully understand the documentation associated
                with this work activity.';
            v_person_label := 'Person in Charge of Works:';
        END IF;

        RETURN '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Acceptance of this Permit to Work</div>
        <div class="declaration-box">' || v_declaration || '</div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">' || v_person_label || '</div>
            <div class="ptw-lv-value">' || safe_val(v_name) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Mobile Tel. No.:</div>
            <div class="ptw-lv-value">' || safe_val(v_mobile) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Company:</div>
            <div class="ptw-lv-value">' || safe_val(v_company) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Date &amp; Time:</div>
            <div class="ptw-lv-value">' || fmt_datetime(v_dt) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Signature:</div>
            <div class="ptw-lv-value">
                <div class="signature-box">' || get_signature_img(v_sig) || '</div>
            </div>
        </div>
    </div>';
    END get_acceptance_html;


    FUNCTION get_clearance_html (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB IS
        v_name    ptw_pro.ptw_signatures.person_name%TYPE;
        v_sig     ptw_pro.ptw_signatures.signature_blob%TYPE;
        v_mobile  ptw_pro.ptw_signatures.mobile_no%TYPE;
        v_company ptw_pro.ptw_signatures.company_name%TYPE;
        v_dt      ptw_pro.ptw_signatures.event_datetime%TYPE;
        v_na_lat  ptw_pro.ptw_signatures.latitude%TYPE;
        v_na_lng  ptw_pro.ptw_signatures.longitude%TYPE;
        v_work_complete ptw_pro.ptw_lv_permits.clear_work_complete%TYPE;
        v_area_safe     ptw_pro.ptw_lv_permits.clear_area_safe%TYPE;
        v_cleared_late  ptw_pro.ptw_lv_permits.cleared_late%TYPE;
        v_late_reason   ptw_pro.ptw_lv_permits.late_clear_reason%TYPE;
        v_ended         ptw_pro.ptw_lv_permits.ended_datetime%TYPE;
        v_section_title VARCHAR2(100);
        v_declaration   VARCHAR2(1500);
        v_person_label  VARCHAR2(100);
        v_na_auth_to_dt ptw_pro.ptw_signatures.auth_to_datetime%TYPE;
    BEGIN
        ptw_pro.ptw_signature_pkg.get_signature(p_permit_id, 'CLEAR',
            v_name, v_sig, v_mobile, v_company, v_dt, v_na_lat, v_na_lng, v_na_auth_to_dt);

        SELECT clear_work_complete, clear_area_safe,
               cleared_late, late_clear_reason, ended_datetime
        INTO   v_work_complete, v_area_safe,
               v_cleared_late, v_late_reason, v_ended
        FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_permit_id;

        -- General's real form calls this stage "Completion of Works" and talks
        -- about reinstating "the system", not "the plant and equipment". It also
        -- asserts personal isolations were removed - the app has no field for
        -- that today, so that clause is deliberately omitted rather than
        -- asserted without data behind it.
        IF p_ptw_type = 'GENERAL' THEN
            v_section_title := 'Completion of Works';
            v_declaration :=
                'I confirm that all personnel and equipment have been withdrawn from the area,
                which is tidy, and that the work/activity is <strong>' || get_yn_label(v_work_complete) || '</strong>.
                I confirm it is <strong>' || get_safe_label(v_area_safe) || '</strong> to reinstate the system.';
            v_person_label := 'Competent Person:';
        ELSE
            -- Verified word-for-word identical on both the LV and Working at
            -- Height source forms. The previous version here dropped "which
            -- has been worked on under this Permit to Work and that all
            -- personnel have vacated the place of works" and reordered the
            -- remaining sentences - a pre-existing bug, not something WAH
            -- introduced; it just surfaced when WAH's real form was checked
            -- against this same shared branch.
            v_section_title := 'Clearance of this Permit to Work';
            v_declaration :=
                'I certify that the works detailed within this Permit to Work are
                <strong>' || get_yn_label(v_work_complete) || '</strong>.
                I certify that it is <strong>' || get_safe_label(v_area_safe) || '</strong>
                to reinstate the plant and equipment which has been worked on under this
                Permit to Work and that all personnel have vacated the place of works.
                The area [has]/[has not] been left in a safe and tidy condition and all
                waste has been removed from site.';
            v_person_label := 'Person in Charge of Works:';
        END IF;

        RETURN '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">' || v_section_title || '</div>
        <div class="declaration-box">' || v_declaration || '</div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Works complete:</div>
            <div class="ptw-lv-value">' || get_yn(v_work_complete) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Area left safe and tidy:</div>
            <div class="ptw-lv-value">' ||
                CASE v_area_safe
                    WHEN 'Y' THEN '<span class="status-badge status-yes">Yes</span>'
                    WHEN 'N' THEN '<span class="status-badge status-no">No</span>'
                    ELSE '-'
                END || '
            </div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">' || v_person_label || '</div>
            <div class="ptw-lv-value">' || safe_val(v_name) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Mobile Tel. No.:</div>
            <div class="ptw-lv-value">' || safe_val(v_mobile) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Company:</div>
            <div class="ptw-lv-value">' || safe_val(v_company) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Date &amp; Time:</div>
            <div class="ptw-lv-value">' || fmt_datetime(v_dt) || '</div>
        </div>
        ' || CASE WHEN v_cleared_late = 'Y' THEN '
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Cleared after expiry:</div>
            <div class="ptw-lv-value"><span class="status-badge status-no">Yes</span>
                (permit expired ' || fmt_datetime(v_ended) || ')</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Reason:</div>
            <div class="ptw-lv-value">' || safe_val(v_late_reason) || '</div>
        </div>' END || '
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Signature:</div>
            <div class="ptw-lv-value">
                <div class="signature-box">' || get_signature_img(v_sig) || '</div>
            </div>
        </div>
    </div>';
    END get_clearance_html;


    FUNCTION get_cancellation_html (p_permit_id NUMBER, p_ptw_type VARCHAR2 DEFAULT 'LV ISOLATION') RETURN CLOB IS
        v_name    ptw_pro.ptw_signatures.person_name%TYPE;
        v_sig     ptw_pro.ptw_signatures.signature_blob%TYPE;
        v_na_mobile  ptw_pro.ptw_signatures.mobile_no%TYPE;
        v_na_company ptw_pro.ptw_signatures.company_name%TYPE;
        v_dt      ptw_pro.ptw_signatures.event_datetime%TYPE;
        v_na_lat  ptw_pro.ptw_signatures.latitude%TYPE;
        v_na_lng  ptw_pro.ptw_signatures.longitude%TYPE;
        v_work_complete ptw_pro.ptw_lv_permits.cancel_work_complete%TYPE;
        v_html    CLOB;
        r         ptw_pro.ptw_lv_cancellation_reason_v%ROWTYPE;
        v_na_auth_to_dt ptw_pro.ptw_signatures.auth_to_datetime%TYPE;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

        ptw_pro.ptw_signature_pkg.get_signature(p_permit_id, 'CANCEL',
            v_name, v_sig, v_na_mobile, v_na_company, v_dt, v_na_lat, v_na_lng, v_na_auth_to_dt);

        SELECT cancel_work_complete INTO v_work_complete
        FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_permit_id;

        -- Reason for cancellation (only when the cancellation traces back
        -- to a failed monitoring check with a concern raised)
        BEGIN
            SELECT * INTO r FROM ptw_pro.ptw_lv_cancellation_reason_v WHERE permit_id = p_permit_id;
            IF r.is_concern_cancellation = 'Y' THEN
                v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Reason for Cancellation</div>
        <div class="ptw-lv-row"><div class="ptw-lv-label">Check failed:</div>
            <div class="ptw-lv-value">' || safe_val(r.check_label) || '</div></div>
        <div class="ptw-lv-row"><div class="ptw-lv-label">Concern raised:</div>
            <div class="ptw-lv-value">' || safe_val(r.concern_description) || '</div></div>
        <div class="ptw-lv-row"><div class="ptw-lv-label">Action taken:</div>
            <div class="ptw-lv-value">' || safe_val(r.actions_taken) || '</div></div>
        <div class="ptw-lv-row"><div class="ptw-lv-label">Reported by:</div>
            <div class="ptw-lv-value">' || safe_val(r.concern_person_name) || '</div></div>
        <div class="ptw-lv-row"><div class="ptw-lv-label">Date &amp; Time:</div>
            <div class="ptw-lv-value">' || fmt_datetime(r.concern_datetime) || '</div></div>
        <div class="ptw-lv-row"><div class="ptw-lv-label">Signature:</div>
            <div class="ptw-lv-value"><div class="signature-box">'
            || get_signature_img(r.concern_signature) || '</div></div></div>
    </div>';
            END IF;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN NULL;
        END;

        -- General's real form has no certification paragraph at this final
        -- stage at all - it's titled "Permit Closure" and is just a plain
        -- signature block (Authorising Person + From + Signature). Rather
        -- than invent legal text that was never on the form, this branch
        -- drops the declaration-box and the "Works complete" row (that
        -- question was already asked one stage earlier, at Completion of
        -- Works) and keeps only what the real form actually asks for here.
        IF p_ptw_type = 'GENERAL' THEN
            v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Permit Closure</div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Authorising Person:</div>
            <div class="ptw-lv-value">' || safe_val(v_name) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Date &amp; Time:</div>
            <div class="ptw-lv-value">' || fmt_datetime(v_dt) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Signature:</div>
            <div class="ptw-lv-value">
                <div class="signature-box">' || get_signature_img(v_sig) || '</div>
            </div>
        </div>
    </div>';
            RETURN v_html;
        END IF;

        -- Working at Height's real form has a genuinely shorter Cancellation
        -- clause than LV's - no [completed]/[not complete] bracket, and no
        -- "further Permit may be required" sentence. Verified by rasterizing
        -- the source form directly, not assumed from the shared LV wording.
        IF p_ptw_type = 'WORKING AT HEIGHT' THEN
            v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Cancellation of this Permit to Work</div>
        <div class="declaration-box">
            I confirm that these works have been
            <strong>' || get_yn_label(v_work_complete) || '</strong>
            and that I have checked that the place of works has been left in a safe and
            tidy condition.
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Works complete:</div>
            <div class="ptw-lv-value">' || get_yn(v_work_complete) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Authorised Person:</div>
            <div class="ptw-lv-value">' || safe_val(v_name) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Date &amp; Time:</div>
            <div class="ptw-lv-value">' || fmt_datetime(v_dt) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Signature:</div>
            <div class="ptw-lv-value">
                <div class="signature-box">' || get_signature_img(v_sig) || '</div>
            </div>
        </div>
    </div>';
            RETURN v_html;
        END IF;

        v_html := v_html || '
    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Cancellation of this Permit to Work</div>
        <div class="declaration-box">
            I confirm that these works have been
            <strong>' || get_yn_label(v_work_complete) || '</strong>
            and that I have checked that the place of work has been left in a safe and tidy
            condition. Where the work is not complete a further Permit may be required.
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Works complete:</div>
            <div class="ptw-lv-value">' || get_yn(v_work_complete) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Authorised Person:</div>
            <div class="ptw-lv-value">' || safe_val(v_name) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Date &amp; Time:</div>
            <div class="ptw-lv-value">' || fmt_datetime(v_dt) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Signature:</div>
            <div class="ptw-lv-value">
                <div class="signature-box">' || get_signature_img(v_sig) || '</div>
            </div>
        </div>
    </div>';
        RETURN v_html;
    END get_cancellation_html;


    FUNCTION get_monitoring_pages_html (
        p_permit_id    NUMBER,
        p_page_heading VARCHAR2 DEFAULT 'Site Monitoring',
        p_ptw_type     VARCHAR2 DEFAULT 'LV ISOLATION'
    ) RETURN CLOB IS
        v_html      CLOB;
        v_mon_count NUMBER := 0;
        v_mon_num   NUMBER := 0;
        v_permit_number ptw_pro.ptw_lv_permits.permit_number%TYPE;
        v_issuer_label  VARCHAR2(20);
        v_display_label VARCHAR2(40);
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

        -- Wording only - the underlying data/table is identical for every
        -- type. Source form for FIRE SYSTEMS ISOLATION says "Isolation"
        -- throughout where every other type's form says "Permit".
        IF p_ptw_type = 'FIRE SYSTEMS ISOLATION' THEN
            v_issuer_label  := 'isolation';
            v_display_label := 'Is Isolation on display?';
        ELSE
            v_issuer_label  := 'permit';
            v_display_label := 'Is Permit on display?';
        END IF;

        SELECT permit_number INTO v_permit_number
        FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_permit_id;

        SELECT COUNT(*) INTO v_mon_count
        FROM   ptw_pro.ptw_lv_monitoring WHERE permit_id = p_permit_id;

        FOR v_mon IN (
            SELECT * FROM ptw_pro.ptw_lv_monitoring
            WHERE  permit_id = p_permit_id
            ORDER  BY created_date ASC
        ) LOOP
            v_mon_num := v_mon_num + 1;

            v_html := v_html || '<div class="page-break"></div><div class="ptw-lv-report-container">';
            v_html := v_html || '<div class="ptw-lv-header"><h1>' || safe_val(p_page_heading) || '</h1>'
                             || '<div class="header-refs">';
            v_html := v_html || '<div>Permit No.: <strong>' || safe_val(v_permit_number) || '</strong></div>';
            v_html := v_html || '<div>Check: <strong>' || TO_CHAR(v_mon_num) || ' of ' || TO_CHAR(v_mon_count) || '</strong></div>';
            v_html := v_html || '<div>Date: <strong>' || NVL(TO_CHAR(v_mon.monitor_date, 'DD-MON-YYYY'), '-') || '</strong></div>';
            v_html := v_html || '</div></div>';

            v_html := v_html || '<div class="ptw-lv-section">'
                             || '<div class="declaration-box" style="padding:6px 12px;">'
                             || 'The following checks are to be undertaken by the issuer of this ' || v_issuer_label || '.'
                             || '</div></div>';

            v_html := v_html || '<div class="ptw-lv-section section-flow">'
                             || '<div class="ptw-lv-section-title">Site Monitoring Checks</div>'
                             || '<table class="ptw-lv-table"><thead><tr>'
                             || '<th>Check</th>'
                             || '<th style="width:55px;text-align:center;">Yes</th>'
                             || '<th style="width:55px;text-align:center;">No</th>'
                             || '<th style="width:55px;text-align:center;">N/A</th>'
                             || '<th style="width:90px;">Time of check</th>'
                             || '</tr></thead><tbody>';

            v_html := v_html || '<tr><td>' || v_display_label || '</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_permit_on_display WHEN 'Y'  THEN '<span class="tick-mark">&#10003;</span>' ELSE '' END || '</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_permit_on_display WHEN 'N'  THEN '<span class="tick-mark" style="color:#c0392b;">&#10003;</span>' ELSE '' END || '</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_permit_on_display WHEN 'NA' THEN '<span class="na-mark">N/A</span>' ELSE '' END || '</td>'
                || '<td>' || NVL(v_mon.chk_permit_time, '') || '</td></tr>';

            v_html := v_html || '<tr><td>Is Access / Egress clear?</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_access_egress WHEN 'Y'  THEN '<span class="tick-mark">&#10003;</span>' ELSE '' END || '</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_access_egress WHEN 'N'  THEN '<span class="tick-mark" style="color:#c0392b;">&#10003;</span>' ELSE '' END || '</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_access_egress WHEN 'NA' THEN '<span class="na-mark">N/A</span>' ELSE '' END || '</td>'
                || '<td>' || NVL(v_mon.chk_access_time, '') || '</td></tr>';

            v_html := v_html || '<tr><td>Are warning signs in place?</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_warning_signs WHEN 'Y'  THEN '<span class="tick-mark">&#10003;</span>' ELSE '' END || '</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_warning_signs WHEN 'N'  THEN '<span class="tick-mark" style="color:#c0392b;">&#10003;</span>' ELSE '' END || '</td>'
                || '<td style="text-align:center;">' || CASE v_mon.chk_warning_signs WHEN 'NA' THEN '<span class="na-mark">N/A</span>' ELSE '' END || '</td>'
                || '<td>' || NVL(v_mon.chk_warning_time, '') || '</td></tr>';

            v_html := v_html || '</tbody></table></div>';

            v_html := v_html || '<div class="ptw-lv-section section-flow">'
                             || '<div class="ptw-lv-section-title">Checks Against Work Processes &amp; Method Statement</div>'
                             || '<div style="font-size:7.5pt;color:#555;padding:5px 12px;'
                             || 'font-style:italic;border-bottom:1px solid #eee;">'
                             || 'Considering the work involved under this ' || INITCAP(v_issuer_label) || ', on reading the method '
                             || 'statement detail below an element you wish to check for compliance. '
                             || 'Note: the minimum is one check per task carried out under each ' || INITCAP(v_issuer_label) || ', '
                             || 'but more are recommended dependent on activity complexity.</div>'
                             || '<table class="ptw-lv-table"><thead><tr>'
                             || '<th style="width:50%;">Column A &mdash; Detail the item or part of the '
                             || 'method statement you decide to check</th>'
                             || '<th style="width:50%;">Column B &mdash; Detail if all works are being '
                             || 'carried out correctly, or what was found to be non-conforming</th>'
                             || '</tr></thead><tbody>';

            FOR chk IN (
                SELECT check_seq, detail, check_time, in_order, comments
                FROM   ptw_pro.ptw_monitoring_checks
                WHERE  monitoring_id = v_mon.monitoring_id
                ORDER  BY check_seq
            ) LOOP
                DBMS_LOB.APPEND(v_html, TO_CLOB('
                <tr>
                    <td style="vertical-align:top;">
                        <div style="font-size:8pt;font-weight:700;margin-bottom:3px;">
                            Check ' || chk.check_seq || ') Detail of check made:</div>
                        <div>' || NVL(safe_val(chk.detail), '&nbsp;') || '</div>
                        <div style="margin-top:6px;font-size:8pt;">
                            <strong>Enter time of check:</strong> '
                            || NVL(chk.check_time, '-') || '</div>
                    </td>
                    <td style="vertical-align:top;">
                        <div><strong>All in order:</strong>&nbsp;&nbsp;' ||
                        CASE chk.in_order
                            WHEN 'Y' THEN 'YES &nbsp;/&nbsp; <span style="color:#aaa;">NO</span>'
                            WHEN 'N' THEN '<span style="color:#aaa;">YES</span> &nbsp;/&nbsp; NO'
                            ELSE 'YES &nbsp;/&nbsp; NO'
                        END || '</div>
                        <div style="margin-top:6px;font-size:8pt;"><strong>Comments:</strong><br>'
                            || NVL(safe_val(chk.comments), '&nbsp;') || '</div>
                    </td>
                </tr>'));
            END LOOP;

            v_html := v_html || '
            </tbody>
        </table>
    </div>

    <div class="ptw-lv-section">
        <div class="ptw-lv-section-title">Monitoring Sign-Off</div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Monitoring carried out by (Name):</div>
            <div class="ptw-lv-value">' || safe_val(v_mon.monitor_name) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">Date:</div>
            <div class="ptw-lv-value">' || fmt_date(v_mon.monitor_date) || '</div>
        </div>
        <div class="ptw-lv-row">
            <div class="ptw-lv-label">(Print) Signature:</div>
            <div class="ptw-lv-value">
                <div class="signature-box">' || get_signature_img(v_mon.monitor_signature) || '</div>
            </div>
        </div>
    </div>

    <div class="footer">
        Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') ||
        ' &nbsp;|&nbsp; Permit: ' || safe_val(v_permit_number) || '
    </div>
    </div>';
        END LOOP;

        IF v_mon_count = 0 THEN
            v_html := v_html || '
    <div style="font-size:7pt;color:#aaa;text-align:right;padding:4px 0;">
        Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') || '
    </div>';
        END IF;

        RETURN v_html;
    END get_monitoring_pages_html;


    FUNCTION get_stage_history_html (p_permit_id NUMBER) RETURN CLOB IS
        v_html       CLOB;
        v_hist_count NUMBER := 0;
        v_permit_number ptw_pro.ptw_lv_permits.permit_number%TYPE;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(v_html, TRUE, DBMS_LOB.CALL);

        SELECT permit_number INTO v_permit_number
        FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_permit_id;

        v_html := '<div class="page-break"></div>
    <div class="ptw-lv-report-container">
    <div class="history-section">
        <div class="ptw-lv-section-title">&#128203; Permit Stage History</div>';

        SELECT COUNT(*) INTO v_hist_count
        FROM (
            WITH max_row AS (
                SELECT MAX(created_date) AS max_date, permit_id, permit_stage
                FROM   ptw_pro.ptw_stage_locations
                GROUP  BY permit_id, permit_stage
            )
            SELECT sl.permit_stage
            FROM   ptw_pro.ptw_stage_locations sl
            JOIN   max_row mr ON mr.permit_id = sl.permit_id
                             AND mr.permit_stage = sl.permit_stage
                             AND mr.max_date = sl.created_date
            WHERE  sl.permit_id = p_permit_id
        );

        IF v_hist_count = 0 THEN
            v_html := v_html || '
        <div class="history-no-data">No stage history recorded for this permit.</div>';
        ELSE
            v_html := v_html || '
        <table class="history-table">
            <thead>
                <tr>
                    <th style="width:32%;">Stage</th>
                    <th style="width:22%;">Date / Time</th>
                    <th style="width:22%;">Recorded By</th>
                    <th style="width:24%;">GPS Location</th>
                </tr>
            </thead>
            <tbody>';

            FOR r IN (
                WITH max_row AS (
                    SELECT MAX(created_date) AS max_date, permit_id, permit_stage
                    FROM   ptw_pro.ptw_stage_locations
                    GROUP  BY permit_id, permit_stage
                )
                SELECT CASE sl.permit_stage
                           WHEN 'SITE_WORK_DETAILS'   THEN 'Step 1: Site &amp; Work Details'
                           WHEN 'CONTROL_MEASURES'    THEN 'Step 2: Control Measures'
                           WHEN 'EQUIP_ISOLATION'     THEN 'Step 3: Equipment Isolation'
                           WHEN 'AUTHORISATION'       THEN 'Step 4: Authorisation'
                           WHEN 'LIVE'                THEN 'Step 5: Live'
                           WHEN 'MONITORING_CONCERN'  THEN 'Monitoring Concern Raised'
                           ELSE NVL(SUBSTR(sl.permit_stage, 1, 100), '-')
                       END AS step_display,
                       TO_CHAR(sl.created_date, 'DD-MON-YYYY HH24:MI') AS created_date,
                       NVL(REPLACE(REPLACE(SUBSTR(sl.created_by, 1, 200), '<', '&lt;'), '>', '&gt;'), '-') AS created_by,
                       sl.latitude,
                       sl.longitude
                FROM   ptw_pro.ptw_stage_locations sl
                JOIN   max_row mr ON mr.permit_id = sl.permit_id
                                 AND mr.permit_stage = sl.permit_stage
                                 AND mr.max_date = sl.created_date
                WHERE  sl.permit_id = p_permit_id
                ORDER  BY sl.created_date ASC
            ) LOOP
                DECLARE
                    l_location_display VARCHAR2(500);
                    l_place            VARCHAR2(500);
                BEGIN
                    IF r.latitude IS NOT NULL AND r.longitude IS NOT NULL THEN
                        -- Reverse-geocode for the PDF history table specifically
                        -- (not used on Page 7's live map). Falls back to raw
                        -- coordinates if the lookup fails or returns nothing -
                        -- get_place_name never raises, so this is just a NULL
                        -- check, not exception handling.
                        l_place := ptw_pro.ptw_geocode_pkg.get_place_name(r.latitude, r.longitude);
                        IF l_place IS NOT NULL THEN
                            l_location_display := safe_val(l_place);
                        ELSE
                            l_location_display := TO_CHAR(ROUND(r.latitude, 5)) || ', ' || TO_CHAR(ROUND(r.longitude, 5));
                        END IF;
                    ELSE
                        l_location_display := 'Not recorded';
                    END IF;

                    v_html := v_html || '
                <tr>
                    <td><span class="history-step-badge">' || r.step_display || '</span></td>
                    <td>' || r.created_date  || '</td>
                    <td>' || r.created_by    || '</td>
                    <td>' || l_location_display || '</td>
                </tr>';
                END;
            END LOOP;

            v_html := v_html || '
            </tbody>
        </table>';
        END IF;

        v_html := v_html || '
    <div class="footer">
        Audit History &nbsp;|&nbsp; Permit: ' || safe_val(v_permit_number) ||
        ' &nbsp;|&nbsp; Generated: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI') || '
    </div>
    </div>
    </div>';
        RETURN v_html;
    END get_stage_history_html;

END ptw_pdf_lib_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_PERMIT_LINK_PKG" AS

    FUNCTION get_link_count(p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE) RETURN NUMBER IS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count
        FROM   ptw_pro.ptw_permit_links_v
        WHERE  permit_id = p_permit_id;
        RETURN v_count;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
    END get_link_count;


    PROCEDURE add_link(
        p_permit_id        IN  ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_linked_permit_id IN  ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_link_note        IN  ptw_pro.ptw_permit_links.link_note%TYPE DEFAULT NULL,
        p_added            OUT BOOLEAN,
        p_message          OUT VARCHAR2
    ) IS
        v_company_id       ptw_pro.ptw_lv_permits.company_id%TYPE;
        v_linked_company_id ptw_pro.ptw_lv_permits.company_id%TYPE;
        v_permit_number    ptw_pro.ptw_lv_permits.permit_number%TYPE;
        v_linked_number    ptw_pro.ptw_lv_permits.permit_number%TYPE;
        v_existing         NUMBER;
    BEGIN
        p_added := FALSE;

        IF p_permit_id IS NULL OR p_linked_permit_id IS NULL THEN
            p_message := 'Both permits are required.';
            RETURN;
        END IF;

        IF p_permit_id = p_linked_permit_id THEN
            p_message := 'A permit cannot be linked to itself.';
            RETURN;
        END IF;

        BEGIN
            SELECT company_id, permit_number INTO v_company_id, v_permit_number
            FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_permit_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                p_message := 'Permit not found.';
                RETURN;
        END;

        BEGIN
            SELECT company_id, permit_number INTO v_linked_company_id, v_linked_number
            FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_linked_permit_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                p_message := 'The permit you selected to link was not found.';
                RETURN;
        END;

        IF v_company_id != v_linked_company_id THEN
            p_message := 'Permits can only be linked within the same company.';
            RETURN;
        END IF;

        SELECT COUNT(*) INTO v_existing
        FROM   ptw_pro.ptw_permit_links
        WHERE  (permit_id = p_permit_id AND linked_permit_id = p_linked_permit_id)
        OR     (permit_id = p_linked_permit_id AND linked_permit_id = p_permit_id);

        IF v_existing > 0 THEN
            p_message := 'Permit ' || v_permit_number || ' is already linked to ' || v_linked_number || '.';
            RETURN;
        END IF;

        INSERT INTO ptw_pro.ptw_permit_links (
            permit_id, linked_permit_id, link_note, company_id, created_by, created_date
        ) VALUES (
            p_permit_id, p_linked_permit_id, p_link_note, v_company_id, NVL(V('APP_USER'), USER), SYSDATE
        );

        COMMIT;

        p_added   := TRUE;
        p_message := 'Linked to ' || v_linked_number || '.';

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_added   := FALSE;
            p_message := 'Error creating link: ' || SQLERRM;
    END add_link;


    PROCEDURE remove_link(
        p_link_id  IN  ptw_pro.ptw_permit_links.link_id%TYPE,
        p_removed  OUT BOOLEAN,
        p_message  OUT VARCHAR2
    ) IS
    BEGIN
        p_removed := FALSE;

        DELETE FROM ptw_pro.ptw_permit_links WHERE link_id = p_link_id;

        IF SQL%ROWCOUNT > 0 THEN
            COMMIT;
            p_removed := TRUE;
            p_message := 'Link removed.';
        ELSE
            p_message := 'Link not found.';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_removed := FALSE;
            p_message := 'Error removing link: ' || SQLERRM;
    END remove_link;

END ptw_permit_link_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_PERMIT_SAVE_PKG" AS

    PROCEDURE save_permit_header(
        p_permit_id                    IN OUT ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_ptw_type                     IN     ptw_pro.ptw_lv_permits.ptw_type%TYPE,
        p_workflow_status               IN     ptw_pro.ptw_lv_permits.workflow_status%TYPE,
        p_safety_programme_ref_no      IN     ptw_pro.ptw_lv_permits.safety_programme_ref_no%TYPE,
        p_isolation_diagram_serial_no  IN     ptw_pro.ptw_lv_permits.isolation_diagram_serial_no%TYPE,
        p_site_id                      IN     ptw_pro.ptw_lv_permits.site_id%TYPE,
        p_site_new_name                IN     ptw_pro.ptw_lv_sites.site_name%TYPE,
        p_area_of_works                IN     ptw_pro.ptw_lv_permits.area_of_works%TYPE,
        p_work_description             IN     ptw_pro.ptw_lv_permits.work_description%TYPE,
        p_person_in_charge_name        IN     ptw_pro.ptw_lv_permits.person_in_charge_name%TYPE,
        p_supervising_company          IN     ptw_pro.ptw_lv_permits.supervising_company%TYPE,
        p_other_persons_count          IN     ptw_pro.ptw_lv_permits.other_persons_count%TYPE,
        p_client_permission_granted    IN     ptw_pro.ptw_lv_permits.client_permission_granted%TYPE,
        p_affects_it_systems           IN     ptw_pro.ptw_lv_permits.affects_it_systems%TYPE,
        p_it_permission_granted        IN     ptw_pro.ptw_lv_permits.it_permission_granted%TYPE,
        p_specialist_equipment_details IN     ptw_pro.ptw_lv_permits.specialist_equipment_details%TYPE,
        p_fire_systems_affected        IN     ptw_pro.ptw_lv_permits.fire_systems_affected%TYPE       DEFAULT NULL,
        p_fire_systems_isolated        IN     ptw_pro.ptw_lv_permits.fire_systems_isolated%TYPE       DEFAULT NULL,
        p_insurer_informed_datetime    IN     ptw_pro.ptw_lv_permits.insurer_informed_datetime%TYPE   DEFAULT NULL,
        p_isolation_comments           IN     ptw_pro.ptw_lv_permits.isolation_comments%TYPE          DEFAULT NULL,
        p_fire_precautions_details     IN     ptw_pro.ptw_lv_permits.fire_precautions_details%TYPE    DEFAULT NULL,
        p_fire_alarm_arrangements      IN     ptw_pro.ptw_lv_permits.fire_alarm_arrangements%TYPE     DEFAULT NULL,
        p_insurance_necessary          IN     ptw_pro.ptw_lv_permits.insurance_necessary%TYPE         DEFAULT NULL,
        p_latitude                     IN     ptw_pro.ptw_lv_permits.site_work_latitude%TYPE,
        p_longitude                    IN     ptw_pro.ptw_lv_permits.site_work_longitude%TYPE,
        p_resolved_site_id             OUT    ptw_pro.ptw_lv_sites.site_id%TYPE,
        p_permit_number                OUT    ptw_pro.ptw_lv_permits.permit_number%TYPE,
        p_saved                        OUT    BOOLEAN,
        p_message                      OUT    VARCHAR2
    ) IS
        v_site_id    ptw_pro.ptw_lv_sites.site_id%TYPE;
        v_company_id NUMBER;
    BEGIN
        p_saved := FALSE;

        -- GUARD (previously online-only - now enforced for both
        -- callers): don't touch header fields once the permit
        -- has moved past DRAFT.
        IF p_permit_id IS NOT NULL AND p_workflow_status != 'DRAFT' THEN
            p_message := 'Permit is no longer in draft - no changes saved.';
            RETURN;
        END IF;

        -- SITE RESOLUTION (same find-or-create logic for both
        -- callers, including the race-condition handler that
        -- was previously online-only).
        IF p_site_id IS NOT NULL THEN
            v_site_id := p_site_id;
        ELSIF p_site_new_name IS NOT NULL THEN
            v_company_id := ptw_pro.ptw_sec_pkg.get_effective_company_id;
            IF v_company_id IS NULL THEN
                p_message := 'Unable to determine company for this site.';
                RETURN;
            END IF;

            BEGIN
                SELECT site_id INTO v_site_id
                FROM   ptw_pro.ptw_lv_sites
                WHERE  UPPER(site_name) = UPPER(p_site_new_name)
                AND    company_id = v_company_id;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    BEGIN
                        INSERT INTO ptw_pro.ptw_lv_sites (company_id, site_name, created_by)
                        VALUES (v_company_id, p_site_new_name, NVL(V('APP_USER'), USER))
                        RETURNING site_id INTO v_site_id;
                    EXCEPTION
                        WHEN DUP_VAL_ON_INDEX THEN
                            -- Race: another session created the same site name for
                            -- this company between our SELECT and our INSERT.
                            -- Re-select rather than fail the whole save.
                            SELECT site_id INTO v_site_id
                            FROM   ptw_pro.ptw_lv_sites
                            WHERE  UPPER(site_name) = UPPER(p_site_new_name)
                            AND    company_id = v_company_id;
                    END;
            END;
        END IF;
        p_resolved_site_id := v_site_id;

        IF p_permit_id IS NULL THEN
            -- INSERT NEW PERMIT
            INSERT INTO ptw_pro.ptw_lv_permits (
                ptw_type,
                safety_programme_ref_no,
                isolation_diagram_serial_no,
                site_id,
                area_of_works,
                work_description,
                person_in_charge_name,
                supervising_company,
                other_persons_count,
                client_permission_granted,
                affects_it_systems,
                it_permission_granted,
                specialist_equipment_details,
                fire_systems_affected,
                fire_systems_isolated,
                insurer_informed_datetime,
                isolation_comments,
                fire_precautions_details,
                fire_alarm_arrangements,
                insurance_necessary,
                current_step,
                workflow_status,
                site_work_latitude,
                site_work_longitude,
                created_by,
                created_date
            ) VALUES (
                NVL(p_ptw_type, 'LV ISOLATION'),
                p_safety_programme_ref_no,
                p_isolation_diagram_serial_no,
                v_site_id,
                p_area_of_works,
                p_work_description,
                p_person_in_charge_name,
                p_supervising_company,
                p_other_persons_count,
                p_client_permission_granted,
                p_affects_it_systems,
                p_it_permission_granted,
                p_specialist_equipment_details,
                p_fire_systems_affected,
                p_fire_systems_isolated,
                p_insurer_informed_datetime,
                p_isolation_comments,
                p_fire_precautions_details,
                p_fire_alarm_arrangements,
                p_insurance_necessary,
                'SITE_WORK_DETAILS',
                'DRAFT',
                p_latitude,
                p_longitude,
                NVL(V('APP_USER'), USER),
                SYSDATE
            ) RETURNING permit_id, permit_number
              INTO p_permit_id, p_permit_number;

            p_saved   := TRUE;
            p_message := 'Permit ' || p_permit_number || ' created successfully.';

        ELSE
            -- UPDATE EXISTING PERMIT (only if something has changed)
            UPDATE ptw_pro.ptw_lv_permits
            SET ptw_type                     = NVL(p_ptw_type, ptw_type),
                safety_programme_ref_no      = p_safety_programme_ref_no,
                isolation_diagram_serial_no  = p_isolation_diagram_serial_no,
                site_id                      = v_site_id,
                area_of_works                = p_area_of_works,
                work_description             = p_work_description,
                person_in_charge_name        = p_person_in_charge_name,
                supervising_company          = p_supervising_company,
                other_persons_count          = p_other_persons_count,
                client_permission_granted    = p_client_permission_granted,
                affects_it_systems           = p_affects_it_systems,
                it_permission_granted        = p_it_permission_granted,
                specialist_equipment_details = p_specialist_equipment_details,
                fire_systems_affected        = p_fire_systems_affected,
                fire_systems_isolated        = p_fire_systems_isolated,
                insurer_informed_datetime    = p_insurer_informed_datetime,
                isolation_comments           = p_isolation_comments,
                fire_precautions_details     = p_fire_precautions_details,
                fire_alarm_arrangements      = p_fire_alarm_arrangements,
                insurance_necessary          = p_insurance_necessary,
                site_work_latitude           = p_latitude,
                site_work_longitude          = p_longitude,
                modified_by                  = NVL(V('APP_USER'), USER),
                modified_date                = CURRENT_TIMESTAMP
            WHERE permit_id = p_permit_id
            AND (
                NVL(ptw_type,                          'x') != NVL(p_ptw_type,                          ptw_type)         OR
                NVL(safety_programme_ref_no,           'x') != NVL(p_safety_programme_ref_no,            'x')             OR
                NVL(isolation_diagram_serial_no,       'x') != NVL(p_isolation_diagram_serial_no,        'x')             OR
                NVL(site_id,                            -1) != NVL(v_site_id,                             -1)            OR
                NVL(area_of_works,                     'x') != NVL(p_area_of_works,                      'x')             OR
                NVL(work_description,                  'x') != NVL(p_work_description,                   'x')             OR
                NVL(person_in_charge_name,             'x') != NVL(p_person_in_charge_name,               'x')            OR
                NVL(supervising_company,               'x') != NVL(p_supervising_company,                 'x')            OR
                NVL(TO_CHAR(other_persons_count),      'x') != NVL(TO_CHAR(p_other_persons_count),        'x')            OR
                NVL(client_permission_granted,         'x') != NVL(p_client_permission_granted,           'x')            OR
                NVL(affects_it_systems,                'x') != NVL(p_affects_it_systems,                  'x')            OR
                NVL(it_permission_granted,             'x') != NVL(p_it_permission_granted,               'x')            OR
                NVL(specialist_equipment_details,      'x') != NVL(p_specialist_equipment_details,        'x')            OR
                NVL(fire_systems_affected,             'x') != NVL(p_fire_systems_affected,               'x')            OR
                NVL(fire_systems_isolated,             'x') != NVL(p_fire_systems_isolated,               'x')            OR
                NVL(insurer_informed_datetime,  DATE '0001-01-01') != NVL(p_insurer_informed_datetime,  DATE '0001-01-01') OR
                NVL(isolation_comments,                'x') != NVL(p_isolation_comments,                 'x')            OR
                NVL(fire_precautions_details,          'x') != NVL(p_fire_precautions_details,            'x')            OR
                NVL(fire_alarm_arrangements,           'x') != NVL(p_fire_alarm_arrangements,             'x')            OR
                NVL(insurance_necessary,               'x') != NVL(p_insurance_necessary,                 'x')
            )
            RETURNING permit_number INTO p_permit_number;

            IF SQL%ROWCOUNT > 0 THEN
                p_saved   := TRUE;
                p_message := 'Permit ' || p_permit_number || ' updated successfully.';
            ELSE
                -- Nothing changed - not an error, just nothing to do.
                SELECT permit_number INTO p_permit_number
                FROM   ptw_pro.ptw_lv_permits WHERE permit_id = p_permit_id;
                p_saved   := TRUE;
                p_message := 'No changes to save.';
            END IF;
        END IF;

        COMMIT;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_saved   := FALSE;
            p_message := 'Error saving permit: ' || SQLERRM;
    END save_permit_header;

END ptw_permit_save_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_SEC_PKG" AS

    PROCEDURE set_session_context(p_username IN VARCHAR2) IS
    BEGIN
        -- No longer used: DBMS_SESSION.SET_CONTEXT is unreliable under ORDS
        -- connection pooling. company_policy now does a direct V('APP_USER')
        -- lookup instead. Stub kept for reference/rollback script compatibility.
        NULL;
    END set_session_context;


    FUNCTION company_policy(
        p_schema IN VARCHAR2,
        p_object IN VARCHAR2
    ) RETURN VARCHAR2 IS
        v_app_user      VARCHAR2(255);
        v_company_id    VARCHAR2(50);
        v_is_super_user VARCHAR2(1);
        v_override      VARCHAR2(50);
    BEGIN
        -- No APEX session = fail closed (e.g. direct SQL Developer access)
        v_app_user := V('APP_USER');
        IF v_app_user IS NULL OR v_app_user = '' THEN
            RETURN '1=2';
        END IF;

        -- Look up this user's company and super-user flag directly
        SELECT TO_CHAR(company_id), is_super_user
        INTO   v_company_id, v_is_super_user
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(v_app_user)
        AND    is_active = 'Y';

        -- Super user: check for a company override (set via G_OVERRIDE_COMPANY_ID
        -- application item when super user picks a company on Page 14).
        -- If override set, scope to that company; otherwise see all.
        IF v_is_super_user = 'Y' THEN
            v_override := V('G_OVERRIDE_COMPANY_ID');
            IF v_override IS NULL OR v_override = '' THEN
                RETURN NULL; -- no restriction, see all companies
            ELSE
                RETURN 'company_id = ' || TO_NUMBER(v_override);
            END IF;
        END IF;

        -- Normal user: scope to their assigned company
        IF v_company_id IS NULL THEN
            RETURN '1=2'; -- no company assigned, deny all
        END IF;

        RETURN 'company_id = ' || v_company_id;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN RETURN '1=2'; -- unknown/inactive user
        WHEN OTHERS        THEN RETURN '1=2'; -- fail closed
    END company_policy;


    PROCEDURE check_user_in_company(p_username IN VARCHAR2) IS
        v_target_company NUMBER;
        v_caller_company NUMBER;
        v_caller_super   VARCHAR2(1);
        v_override       VARCHAR2(50);
    BEGIN
        -- Workspace admins always allowed
        IF APEX_UTIL.CURRENT_USER_IN_GROUP('Administrators') THEN
            RETURN;
        END IF;

        SELECT company_id, is_super_user
        INTO   v_caller_company, v_caller_super
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(SYS_CONTEXT('APEX$SESSION', 'APP_USER'));

        IF v_caller_super = 'Y' THEN
            v_override := V('G_OVERRIDE_COMPANY_ID');
            IF v_override IS NULL OR v_override = '' THEN
                RETURN; -- super user, no override: unrestricted
            END IF;
            v_caller_company := TO_NUMBER(v_override);
        END IF;

        SELECT company_id
        INTO   v_target_company
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(p_username);

        IF v_target_company IS NULL OR v_target_company != v_caller_company THEN
            RAISE_APPLICATION_ERROR(-20002,
                'Access denied: this user does not belong to your company.');
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20002,
                'Access denied: user not found or not permitted.');
        WHEN OTHERS THEN
            IF SQLCODE = -20002 THEN
                RAISE;
            END IF;
            RAISE_APPLICATION_ERROR(-20002,
                'Access denied: unable to verify user company.');
    END check_user_in_company;

    FUNCTION get_effective_company_id
    RETURN NUMBER
    IS
        v_app_user      VARCHAR2(255);
        v_company_id    ptw_pro.ptw_lv_users.company_id%TYPE;
        v_is_super_user ptw_pro.ptw_lv_users.is_super_user%TYPE;
        v_override      VARCHAR2(50);
    BEGIN
        v_app_user := SYS_CONTEXT('APEX$SESSION', 'APP_USER');

        SELECT company_id, is_super_user
        INTO   v_company_id, v_is_super_user
        FROM   ptw_pro.ptw_lv_users
        WHERE  UPPER(username) = UPPER(v_app_user)
        AND    is_active = 'Y';

        IF v_is_super_user = 'Y' THEN
            v_override := V('G_OVERRIDE_COMPANY_ID');
            IF v_override IS NULL OR v_override = '' THEN
                RETURN NULL;  -- caller decides how to handle "no company selected"
            END IF;
            RETURN TO_NUMBER(v_override);
        ELSE
            RETURN v_company_id;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END;

END ptw_sec_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_SIGNATURE_PKG" AS

    PROCEDURE save_signature(
        p_permit_id        IN ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_stage            IN ptw_pro.ptw_signatures.stage%TYPE,
        p_person_name      IN ptw_pro.ptw_signatures.person_name%TYPE,
        p_signature_blob   IN ptw_pro.ptw_signatures.signature_blob%TYPE,
        p_mobile_no        IN ptw_pro.ptw_signatures.mobile_no%TYPE      DEFAULT NULL,
        p_company_name     IN ptw_pro.ptw_signatures.company_name%TYPE   DEFAULT NULL,
        p_event_datetime   IN ptw_pro.ptw_signatures.event_datetime%TYPE DEFAULT SYSDATE,
        p_latitude         IN ptw_pro.ptw_signatures.latitude%TYPE       DEFAULT NULL,
        p_longitude        IN ptw_pro.ptw_signatures.longitude%TYPE      DEFAULT NULL,
        p_auth_to_datetime IN ptw_pro.ptw_signatures.auth_to_datetime%TYPE DEFAULT NULL
    ) IS
        l_company_id ptw_pro.ptw_lv_permits.company_id%TYPE;
    BEGIN
        IF p_stage NOT IN ('AUTH','ACCEPT','CLEAR','CANCEL','CLOSE','CLR_ENG') THEN
            RAISE_APPLICATION_ERROR(-20060, 'Invalid signature stage: ' || p_stage);
        END IF;

        SELECT company_id INTO l_company_id
        FROM   ptw_pro.ptw_lv_permits
        WHERE  permit_id = p_permit_id;

        MERGE INTO ptw_pro.ptw_signatures sig
        USING (SELECT p_permit_id AS permit_id, p_stage AS stage FROM dual) src
        ON (sig.permit_id = src.permit_id AND sig.stage = src.stage)
        WHEN MATCHED THEN
            UPDATE SET person_name      = p_person_name,
                       signature_blob   = p_signature_blob,
                       mobile_no        = p_mobile_no,
                       company_name     = p_company_name,
                       event_datetime   = p_event_datetime,
                       latitude         = p_latitude,
                       longitude        = p_longitude,
                       auth_to_datetime = p_auth_to_datetime,
                       modified_date    = CURRENT_TIMESTAMP,
                       modified_by      = NVL(V('APP_USER'), USER)
        WHEN NOT MATCHED THEN
            INSERT (permit_id, stage, person_name, signature_blob, mobile_no,
                    company_name, event_datetime, latitude, longitude,
                    auth_to_datetime, company_id, created_by)
            VALUES (p_permit_id, p_stage, p_person_name, p_signature_blob, p_mobile_no,
                    p_company_name, p_event_datetime, p_latitude, p_longitude,
                    p_auth_to_datetime, l_company_id, NVL(V('APP_USER'), USER));

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20061, 'Permit ' || p_permit_id
                || ' not found or not accessible.');
        WHEN OTHERS THEN
            IF SQLCODE IN (-20060, -20061) THEN
                RAISE;
            END IF;
            RAISE_APPLICATION_ERROR(-20062, 'Error saving ' || p_stage
                || ' signature for permit ' || p_permit_id || ': ' || SQLERRM);
    END save_signature;


    PROCEDURE get_signature(
        p_permit_id        IN  ptw_pro.ptw_lv_permits.permit_id%TYPE,
        p_stage            IN  ptw_pro.ptw_signatures.stage%TYPE,
        p_person_name      OUT ptw_pro.ptw_signatures.person_name%TYPE,
        p_signature_blob   OUT ptw_pro.ptw_signatures.signature_blob%TYPE,
        p_mobile_no        OUT ptw_pro.ptw_signatures.mobile_no%TYPE,
        p_company_name     OUT ptw_pro.ptw_signatures.company_name%TYPE,
        p_event_datetime   OUT ptw_pro.ptw_signatures.event_datetime%TYPE,
        p_latitude         OUT ptw_pro.ptw_signatures.latitude%TYPE,
        p_longitude        OUT ptw_pro.ptw_signatures.longitude%TYPE,
        p_auth_to_datetime OUT ptw_pro.ptw_signatures.auth_to_datetime%TYPE
    ) IS
    BEGIN
        SELECT person_name, signature_blob, mobile_no, company_name, event_datetime,
               latitude, longitude, auth_to_datetime
        INTO   p_person_name, p_signature_blob, p_mobile_no, p_company_name, p_event_datetime,
               p_latitude, p_longitude, p_auth_to_datetime
        FROM   ptw_pro.ptw_signatures
        WHERE  permit_id = p_permit_id
        AND    stage     = p_stage;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_person_name      := NULL;
            p_signature_blob   := NULL;
            p_mobile_no        := NULL;
            p_company_name     := NULL;
            p_event_datetime   := NULL;
            p_latitude         := NULL;
            p_longitude        := NULL;
            p_auth_to_datetime := NULL;
    END get_signature;

END ptw_signature_pkg;
/

CREATE OR REPLACE EDITIONABLE PACKAGE BODY "PTW_PRO"."PTW_UI_PKG" AS

    FUNCTION get_workflow_steps_html(
        p_permit_id    IN ptw_pro.ptw_lv_permits.permit_id%TYPE    DEFAULT NULL,
        p_ptw_type     IN ptw_pro.ptw_lv_permits.ptw_type%TYPE     DEFAULT NULL,
        p_current_step IN ptw_pro.ptw_lv_permits.current_step%TYPE DEFAULT NULL
    ) RETURN CLOB IS

        TYPE t_step_rec IS RECORD (
            step_code  VARCHAR2(30),
            step_label VARCHAR2(50)
        );
        TYPE t_step_tab IS TABLE OF t_step_rec INDEX BY PLS_INTEGER;

        l_steps         t_step_tab;
        l_ptw_type      ptw_pro.ptw_lv_permits.ptw_type%TYPE := p_ptw_type;
        l_furthest_step ptw_pro.ptw_lv_permits.current_step%TYPE;  -- DB progress only
        l_active_step   ptw_pro.ptw_lv_permits.current_step%TYPE;  -- page being viewed
        l_active_idx    PLS_INTEGER := 0;
        l_furthest_idx  PLS_INTEGER := 0;
        l_html          CLOB := '<div class="ptw-workflow-progress">';
        l_class         VARCHAR2(30);
        l_icon          VARCHAR2(20);
        l_has_equip_iso PLS_INTEGER := 0;

    BEGIN
        -- Existing permit: DB values win for type + furthest progress.
        -- New/unsaved permit (permit_id NULL, or not yet inserted): fall
        -- back to what was passed in.
        IF p_permit_id IS NOT NULL THEN
            BEGIN
                SELECT ptw_type, current_step
                INTO   l_ptw_type, l_furthest_step
                FROM   ptw_pro.ptw_lv_permits
                WHERE  permit_id = p_permit_id;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    l_ptw_type      := p_ptw_type;
                    l_furthest_step := p_current_step;
            END;
        ELSE
            l_furthest_step := p_current_step;
        END IF;

        -- The step actually being viewed comes from the caller (each page
        -- passes its own literal via P{n}_CURRENT_STEP), falling back to
        -- furthest progress, then to step 1, if the caller didn't supply one.
        l_active_step   := NVL(p_current_step, NVL(l_furthest_step, 'SITE_WORK_DETAILS'));
        l_furthest_step := NVL(l_furthest_step, l_active_step);

        IF l_ptw_type IS NULL THEN
            RETURN NULL;   -- genuinely nothing to render (no type chosen at all)
        END IF;

        -- Does this permit type include the Equipment Isolation section?
        -- Driven by ptw_type_sections (the real source of truth), not a
        -- hardcoded ptw_type string — matches the branch logic Page 3
        -- already uses to decide whether to route to Page 4.
        BEGIN
            SELECT 1
            INTO   l_has_equip_iso
            FROM   ptw_pro.ptw_types t
            JOIN   ptw_pro.ptw_type_sections ts ON ts.type_id = t.type_id
            WHERE  t.ptw_type      = l_ptw_type
            AND    ts.section_code = 'EQUIPMENT_ISOLATION'
            AND    ROWNUM = 1;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                l_has_equip_iso := 0;
        END;

        IF l_has_equip_iso = 1 THEN
            l_steps(1).step_code := 'SITE_WORK_DETAILS'; l_steps(1).step_label := 'Site & Work Details';
            l_steps(2).step_code := 'CONTROL_MEASURES';  l_steps(2).step_label := 'Control Measures';
            l_steps(3).step_code := 'EQUIP_ISOLATION';   l_steps(3).step_label := 'Equipment Isolation';
            l_steps(4).step_code := 'AUTHORISATION';     l_steps(4).step_label := 'Authorisation';
            l_steps(5).step_code := 'CLEARANCE';         l_steps(5).step_label := 'Clearance';
        ELSE
            l_steps(1).step_code := 'SITE_WORK_DETAILS'; l_steps(1).step_label := 'Site & Work Details';
            l_steps(2).step_code := 'CONTROL_MEASURES';  l_steps(2).step_label := 'Control Measures';
            l_steps(3).step_code := 'AUTHORISATION';     l_steps(3).step_label := 'Authorisation';
            l_steps(4).step_code := 'CLEARANCE';         l_steps(4).step_label := 'Clearance';
        END IF;

        FOR i IN 1 .. l_steps.COUNT LOOP
            IF l_steps(i).step_code = l_active_step THEN
                l_active_idx := i;
            END IF;
            IF l_steps(i).step_code = l_furthest_step THEN
                l_furthest_idx := i;
            END IF;
        END LOOP;

        -- Active step is whichever page rendered this call (blue).
        -- Completed = reached before either the active step or the
        -- furthest DB progress, whichever index is greater — so
        -- navigating back to review an earlier page doesn't wipe the
        -- checkmarks off later, already-completed steps. Everything else
        -- is upcoming.
        FOR i IN 1 .. l_steps.COUNT LOOP
            IF i = l_active_idx THEN
                l_class := 'active';
                l_icon  := TO_CHAR(i);
            ELSIF i < GREATEST(l_active_idx, l_furthest_idx) THEN
                l_class := 'completed';
                l_icon  := '&#10003;';
            ELSE
                l_class := NULL;
                l_icon  := TO_CHAR(i);
            END IF;

            l_html := l_html
                || '<div class="workflow-step' || CASE WHEN l_class IS NOT NULL THEN ' ' || l_class END
                || '" data-step="' || i || '">'
                || '<span class="step-icon">' || l_icon || '</span>'
                || '<span class="step-text">' || APEX_ESCAPE.HTML(l_steps(i).step_label) || '</span>'
                || '</div>';
        END LOOP;

        RETURN l_html || '</div>';
    END get_workflow_steps_html;


    FUNCTION get_permit_type_badge_html(
        p_permit_id IN ptw_pro.ptw_lv_permits.permit_id%TYPE DEFAULT NULL,
        p_ptw_type  IN ptw_pro.ptw_lv_permits.ptw_type%TYPE  DEFAULT NULL
    ) RETURN CLOB IS
        l_ptw_type  ptw_pro.ptw_lv_permits.ptw_type%TYPE := p_ptw_type;
        l_type_desc ptw_pro.ptw_types.type_desc%TYPE;
    BEGIN
        IF p_permit_id IS NOT NULL THEN
            BEGIN
                SELECT ptw_type INTO l_ptw_type
                FROM   ptw_pro.ptw_lv_permits
                WHERE  permit_id = p_permit_id;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    l_ptw_type := p_ptw_type;
            END;
        END IF;

        IF l_ptw_type IS NULL THEN
            RETURN NULL;
        END IF;

        SELECT type_desc INTO l_type_desc
        FROM   ptw_pro.ptw_types
        WHERE  ptw_type = l_ptw_type;

        RETURN '<div class="ptw-permit-type-badge" style="margin-bottom:12px;">'
            || '<span class="apex-badge" style="background-color:#5a6b7a;color:white;'
            || 'padding:4px 14px;border-radius:14px;font-weight:600;font-size:0.85rem;">'
            || APEX_ESCAPE.HTML(l_type_desc)
            || '</span></div>';

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END get_permit_type_badge_html;

END ptw_ui_pkg;
/
