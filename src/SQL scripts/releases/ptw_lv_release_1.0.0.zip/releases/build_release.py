#!/usr/bin/env python3
"""
Build a full PTW LV release bundle from the repo sources.

Usage (from the repo root):
    python3 releases/build_release.py 1.0.0

Reads:
    src/SQL scripts/run_ddl_export.sql   -> authoritative list of DEV objects
    src/SQL scripts/<type>/*.sql         -> DBMS_METADATA DDL per object
    src/SQL scripts/packages/*.pks.sql   -> package spec + body (DBMS_METADATA)
    application/export/f105.sql          -> APEX single-file export
    releases/templates/*.sql             -> hand-written scripts (admin, data, checks)

Writes:
    releases/<version>/...               -> ordered install scripts + MANIFEST
"""
import hashlib
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SRC = REPO / "src" / "SQL scripts"
APEX_EXPORT = REPO / "application" / "export" / "f105.sql"
TEMPLATES = REPO / "releases" / "templates"

# Objects deliberately left out of a fresh install, with the reason.
EXCLUDE = {
    "tables/ptw_lv_user_roles_old.sql": "legacy table, not referenced by any code (replaced by ptw_lv_roles + ptw_lv_user_role_assignments)",
    "indexes/idx_ptw_lv_ur_username.sql": "index on the legacy table ptw_lv_user_roles_old",
    "tables/debug_messages.sql": "debugging table, not referenced by the app or any package",
}

FK_RE = re.compile(r"\bFOREIGN\s+KEY\b", re.I)
KU_INSERT_RE = re.compile(r"^\s*INSERT\s+/\*\+\s*APPEND\s+NESTED_TABLE_SET_REFS", re.I)
BODY_RE = re.compile(r"^\s*CREATE\s+OR\s+REPLACE\s+(EDITIONABLE\s+)?PACKAGE\s+BODY\b", re.I | re.M)


def manifest_files():
    """Object files in the order and set produced by run_ddl_export.sql against DEV."""
    text = (SRC / "run_ddl_export.sql").read_text()
    seen, out = set(), []
    for m in re.finditer(r"SPOOL\s+([a-z]+/[A-Za-z0-9_]+\.sql)", text):
        rel = m.group(1)
        key = rel.lower()
        if key in seen:
            continue
        seen.add(key)
        # file names on disk may differ in case
        folder, name = rel.split("/")
        match = [p for p in (SRC / folder).glob("*.sql") if p.name.lower() == name.lower()]
        if not match:
            raise SystemExit(f"Manifest lists {rel} but no file exists")
        out.append((folder, match[0]))
    return out


def split_sql(text):
    """Split DBMS_METADATA output into ';'-terminated statements (tables, indexes, sequences)."""
    stmts, buf = [], []
    for line in text.splitlines():
        buf.append(line)
        if line.rstrip().endswith(";"):
            s = "\n".join(buf).strip()
            if s:
                stmts.append(s)
            buf = []
    tail = "\n".join(buf).strip()
    if tail:
        stmts.append(tail + ";")
    return stmts


def plsql_unit(text):
    """Normalise one PL/SQL unit so it ends with a single '/' line."""
    t = text.strip()
    t = re.sub(r"\n\s*/\s*$", "", t).rstrip()
    return t + "\n/\n"


def header(title, run_as, notes=""):
    return (
        "--------------------------------------------------------------------------------\n"
        f"-- PTW LV release {VERSION} : {title}\n"
        f"-- Run as      : {run_as}\n"
        f"-- Generated   : {BUILT} by releases/build_release.py\n"
        + (f"-- Notes       : {notes}\n" if notes else "")
        + "--------------------------------------------------------------------------------\n\n"
    )


def main():
    global VERSION, BUILT
    VERSION = sys.argv[1] if len(sys.argv) > 1 else "1.0.0"
    BUILT = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    out = REPO / "releases" / VERSION
    if out.exists():
        shutil.rmtree(out)
    (out / "apex").mkdir(parents=True)
    (out / "tools").mkdir()

    groups = {k: [] for k in ["sequences", "tables", "fks", "indexes", "views", "functions", "triggers", "policies"]}
    report = {"included": [], "excluded": [], "dropped_stmts": 0}

    for folder, path in manifest_files():
        rel = f"{folder}/{path.name.lower()}"
        if rel in EXCLUDE:
            report["excluded"].append((rel, EXCLUDE[rel]))
            continue
        report["included"].append(rel)
        text = path.read_text(errors="strict")
        if folder == "tables":
            for s in split_sql(text):
                if KU_INSERT_RE.match(s):
                    report["dropped_stmts"] += 1  # DBMS_METADATA network-link artefact, not real DDL
                    continue
                s = re.sub(r"(AS IDENTITY.*?)START WITH \d+", r"\1START WITH 1", s, flags=re.S)
                (groups["fks"] if FK_RE.search(s) else groups["tables"]).append(s)
        elif folder == "sequences":
            for s in split_sql(text):
                groups["sequences"].append(re.sub(r"START WITH \d+", "START WITH 1", s))
        elif folder == "indexes":
            groups["indexes"].extend(split_sql(text))
        elif folder in ("views",):
            groups["views"].append(text.strip().rstrip(";") + ";")
        elif folder in ("functions", "policies"):
            groups[folder].append(plsql_unit(text))
        elif folder == "triggers":
            # CREATE TRIGGER ... END; /  ALTER TRIGGER ... ENABLE;
            parts = re.split(r"\n\s*/\s*\n", text.strip(), maxsplit=1)
            groups["triggers"].append(plsql_unit(parts[0]))
            if len(parts) > 1 and parts[1].strip():
                groups["triggers"].append(parts[1].strip().rstrip(";") + ";\n")
        else:
            raise SystemExit(f"Unhandled folder {folder}")

    # Packages: *.pks.sql hold spec + body (DBMS_METADATA GET_DDL('PACKAGE')).
    specs, bodies = [], []
    for p in sorted((SRC / "packages").glob("*.pks.sql")):
        text = p.read_text()
        m = BODY_RE.search(text)
        if not m:
            raise SystemExit(f"{p.name}: no package body found")
        specs.append(plsql_unit(text[: m.start()]))
        bodies.append(plsql_unit(text[m.start():]))
        report["included"].append(f"packages/{p.name}")

    def write(name, title, run_as, body, notes=""):
        (out / name).write_text(header(title, run_as, notes) + body)

    write("02_sequences.sql", "Sequences", "PTW_PRO", "\n\n".join(groups["sequences"]) + "\n",
          "START WITH reset to 1 for a clean install.")
    write("03_tables.sql", "Tables, primary/unique keys and check constraints", "PTW_PRO",
          "\n\n".join(groups["tables"]) + "\n", "Foreign keys are in 04 so table order does not matter.")
    write("04_foreign_keys.sql", "Foreign keys", "PTW_PRO", "\n\n".join(groups["fks"]) + "\n")
    write("05_indexes.sql", "Indexes (non-constraint)", "PTW_PRO", "\n\n".join(groups["indexes"]) + "\n")
    write("06_package_specs.sql", "Package specifications", "PTW_PRO", "\n".join(specs))
    write("07_views.sql", "Views", "PTW_PRO", "\n\n".join(groups["views"]) + "\n")
    write("08_functions.sql", "Standalone functions", "PTW_PRO", "\n".join(groups["functions"]))
    write("09_package_bodies.sql", "Package bodies", "PTW_PRO", "\n".join(bodies))
    write("10_triggers.sql", "Triggers", "PTW_PRO", "\n".join(groups["triggers"]))
    write("14_vpd_policies.sql", "VPD (row-level security) policies", "PTW_PRO", "\n".join(groups["policies"]),
          "Applied AFTER seed data, because the policy function blocks access outside an APEX session.")

    for t in sorted(TEMPLATES.glob("*")):
        dest = out / ("tools" if t.name.startswith("tool_") else ".") / t.name.replace("tool_", "")
        dest.write_text(t.read_text().replace("{{VERSION}}", VERSION).replace("{{BUILT}}", BUILT))

    shutil.copy2(APEX_EXPORT, out / "apex" / "f105.sql")

    # Object list for the drift check (tables with column counts).
    table_cols = {}
    for s in groups["tables"]:
        m = re.match(r'\s*CREATE TABLE "PTW_PRO"\."([A-Z0-9_]+)"\s*\((.*)\)\s*;?\s*$', s, re.S)
        if m:
            cols = re.findall(r'^\s*\(?\s*"([A-Z0-9_]+)"\s', m.group(2), re.M)
            table_cols[m.group(1)] = len(cols)
    names = {
        "TABLE": sorted(table_cols),
        "SEQUENCE": sorted(re.search(r'SEQUENCE\s+"PTW_PRO"\."([A-Z0-9_]+)"', s).group(1) for s in groups["sequences"]),
        "INDEX": sorted(re.search(r'INDEX\s+"PTW_PRO"\."([A-Z0-9_]+)"', s).group(1) for s in groups["indexes"]),
        "VIEW": sorted(re.search(r'VIEW\s+"PTW_PRO"\."([A-Z0-9_]+)"', s).group(1) for s in groups["views"]),
        "FUNCTION": sorted(re.search(r'FUNCTION\s+"PTW_PRO"\."([A-Z0-9_]+)"', s).group(1) for s in groups["functions"]),
        "PACKAGE": sorted(re.search(r'PACKAGE\s+"PTW_PRO"\."([A-Z0-9_]+)"', s).group(1) for s in specs),
        "TRIGGER": sorted(re.search(r'TRIGGER\s+"PTW_PRO"\."([A-Z0-9_]+)"', s, re.I).group(1)
                          for s in groups["triggers"] if s.lstrip().upper().startswith("CREATE")),
    }
    rows = []
    for typ, lst in names.items():
        for n in lst:
            rows.append(f"    SELECT '{typ}' t, '{n}' n, {table_cols.get(n, 'NULL') if typ == 'TABLE' else 'NULL'} c FROM dual")
    drift = (out / "tools" / "check_dev_drift.sql")
    drift.write_text(drift.read_text().replace("{{EXPECTED_OBJECTS}}", "\n    UNION ALL\n".join(rows)))
    smoke = out / "15_smoke_test.sql"
    smoke.write_text(smoke.read_text()
                     .replace("{{N_TABLES}}", str(len(names["TABLE"])))
                     .replace("{{N_POLICIES}}", str(len(groups["policies"]))))

    # MANIFEST with checksums
    lines = [f"PTW LV release {VERSION}", f"Built {BUILT}", "",
             f"Source APEX export : application/export/f105.sql (sha256 {hashlib.sha256(APEX_EXPORT.read_bytes()).hexdigest()})",
             f"Objects            : " + ", ".join(f"{len(v)} {k.lower()}" for k, v in names.items()),
             f"Policies           : {len(groups['policies'])}",
             f"Foreign keys       : {len(groups['fks'])}",
             f"DBMS_METADATA network-link INSERTs removed: {report['dropped_stmts']}", "",
             "Excluded from the install:"]
    lines += [f"  - {r}: {why}" for r, why in report["excluded"]]
    lines += ["", "Files (sha256):"]
    for f in sorted(out.rglob("*")):
        if f.is_file() and f.name != "MANIFEST.txt":
            lines.append(f"  {hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(out)}")
    (out / "MANIFEST.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines[:12]))


if __name__ == "__main__":
    main()
